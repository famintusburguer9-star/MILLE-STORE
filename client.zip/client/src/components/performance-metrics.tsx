import { BarChart3, Clock, Cpu, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { SystemPerformance } from "@/lib/types";

interface PerformanceMetricsProps {
  performance?: SystemPerformance;
}

export default function PerformanceMetrics({ performance }: PerformanceMetricsProps) {
  const getPerformanceColor = (value: number, type: 'latency' | 'accuracy' | 'cpu' | 'memory') => {
    switch (type) {
      case 'latency':
        return value <= 5 ? 'text-green-500' : value <= 10 ? 'text-yellow-500' : 'text-red-500';
      case 'accuracy':
        return value >= 95 ? 'text-green-500' : value >= 90 ? 'text-yellow-500' : 'text-red-500';
      case 'cpu':
      case 'memory':
        return value <= 50 ? 'text-green-500' : value <= 80 ? 'text-yellow-500' : 'text-red-500';
      default:
        return 'text-foreground';
    }
  };

  const getCpuProgressColor = (value: number) => {
    if (value <= 50) return 'bg-green-500';
    if (value <= 80) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <BarChart3 className="text-primary mr-2" />
            System Performance
          </CardTitle>
          <Select defaultValue="1h">
            <SelectTrigger className="w-32" data-testid="select-performance-timerange">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">Last Hour</SelectItem>
              <SelectItem value="6h">Last 6h</SelectItem>
              <SelectItem value="24h">Last 24h</SelectItem>
              <SelectItem value="7d">Last Week</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card className="bg-muted">
            <CardContent className="p-3 text-center">
              <div className="text-xs text-muted-foreground">Decision Latency</div>
              <div className={`text-lg font-bold ${getPerformanceColor(performance?.decisionLatency || 2.3, 'latency')}`} data-testid="text-decision-latency">
                {performance?.decisionLatency?.toFixed(1) || '2.3'}ms
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-muted">
            <CardContent className="p-3 text-center">
              <div className="text-xs text-muted-foreground">Accuracy Rate</div>
              <div className={`text-lg font-bold ${getPerformanceColor(performance?.accuracyRate || 99.7, 'accuracy')}`} data-testid="text-accuracy-rate">
                {performance?.accuracyRate?.toFixed(1) || '99.7'}%
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-muted">
            <CardContent className="p-3 text-center">
              <div className="text-xs text-muted-foreground">False Positives</div>
              <div className="text-lg font-bold text-accent" data-testid="text-false-positives">
                {performance?.falsePositiveRate?.toFixed(2) || '0.03'}%
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-muted">
            <CardContent className="p-3 text-center">
              <div className="text-xs text-muted-foreground">CPU Usage</div>
              <div className={`text-lg font-bold ${getPerformanceColor(performance?.cpuUsage || 34, 'cpu')}`} data-testid="text-cpu-usage">
                {performance?.cpuUsage?.toFixed(0) || '34'}%
              </div>
            </CardContent>
          </Card>
        </div>

        {/* System Resource Usage */}
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <div className="flex items-center">
                <Cpu className="h-4 w-4 mr-2 text-primary" />
                <span>CPU Usage</span>
              </div>
              <span className={getPerformanceColor(performance?.cpuUsage || 34, 'cpu')} data-testid="text-cpu-percentage">
                {performance?.cpuUsage?.toFixed(0) || '34'}%
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all duration-300 ${getCpuProgressColor(performance?.cpuUsage || 34)}`}
                style={{ width: `${performance?.cpuUsage || 34}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-2">
              <div className="flex items-center">
                <TrendingUp className="h-4 w-4 mr-2 text-secondary" />
                <span>Memory Usage</span>
              </div>
              <span className={getPerformanceColor(performance?.memoryUsage || 67, 'memory')} data-testid="text-memory-percentage">
                {performance?.memoryUsage?.toFixed(0) || '67'}%
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all duration-300 ${getCpuProgressColor(performance?.memoryUsage || 67)}`}
                style={{ width: `${performance?.memoryUsage || 67}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-2">
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-2 text-accent" />
                <span>Threat Detection Rate</span>
              </div>
              <span className="text-accent" data-testid="text-threat-detection-rate">
                {performance?.threatDetectionRate?.toFixed(0) || '847'}/min
              </span>
            </div>
            <Progress value={85} className="h-2" />
          </div>
        </div>

        {/* Performance Chart Placeholder */}
        <div className="bg-muted/50 h-32 rounded-lg flex items-center justify-center mt-6">
          <div className="text-center">
            <BarChart3 className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
            <span className="text-sm text-muted-foreground" data-testid="text-chart-placeholder">
              Performance metrics chart
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
