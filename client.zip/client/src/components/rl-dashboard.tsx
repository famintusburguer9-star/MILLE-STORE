import { useQuery } from "@tanstack/react-query";
import { Brain, TrendingUp, Zap } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RLPerformance, Decision } from "@/lib/types";

export default function RLDashboard() {
  const { data: rlPerformance } = useQuery<RLPerformance>({
    queryKey: ['/api/rl/performance'],
    refetchInterval: 5000
  });

  const { data: recentDecisions } = useQuery<Decision[]>({
    queryKey: ['/api/decisions'],
    refetchInterval: 3000
  });

  const getDecisionIcon = (type: string) => {
    switch (type) {
      case 'block': return '🚫';
      case 'escalate': return '⚠️';
      case 'isolate': return '🔒';
      case 'redirect': return '↗️';
      case 'allow': return '✅';
      default: return '❓';
    }
  };

  const getDecisionColor = (type: string) => {
    switch (type) {
      case 'block': return 'bg-secondary';
      case 'escalate': return 'bg-accent';
      case 'isolate': return 'bg-destructive';
      case 'redirect': return 'bg-primary';
      case 'allow': return 'bg-green-500';
      default: return 'bg-muted';
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Brain className="text-primary mr-2" />
            RL Decision Engine
          </CardTitle>
          <div className="flex items-center space-x-2">
            <div className="status-indicator status-learning animate-pulse-slow"></div>
            <span className="text-sm text-muted-foreground" data-testid="text-rl-status">Q-Learning Active</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card className="bg-muted">
            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground">Current Episode</div>
              <div className="text-2xl font-bold" data-testid="text-current-episode">
                {rlPerformance?.currentEpisode?.toLocaleString() || '15,847'}
              </div>
              <div className="text-xs text-secondary">
                +{((rlPerformance?.epsilon || 0.1) * 100).toFixed(1)}% exploration rate
              </div>
            </CardContent>
          </Card>
          <Card className="bg-muted">
            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground">Reward Score</div>
              <div className="text-2xl font-bold text-secondary" data-testid="text-reward-score">
                +{rlPerformance?.averageReward?.toFixed(3) || '0.847'}
              </div>
              <div className="text-xs text-secondary">
                {((rlPerformance?.successRate || 0.8) * 100).toFixed(1)}% success rate
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-3">
          <div className="text-sm font-medium">Recent Autonomous Decisions</div>
          {recentDecisions?.slice(0, 5).map((decision, index) => (
            <Card key={decision.id} className="bg-muted">
              <CardContent className="p-3 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 ${getDecisionColor(decision.type)} rounded-full`}></div>
                  <div>
                    <div className="text-sm font-medium capitalize" data-testid={`decision-action-${index}`}>
                      {getDecisionIcon(decision.type)} {decision.type} {decision.target}
                    </div>
                    <div className="text-xs text-muted-foreground" data-testid={`decision-reason-${index}`}>
                      {decision.reason}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-muted-foreground" data-testid={`decision-time-${index}`}>
                    {decision.timestamp ? new Date(decision.timestamp).toLocaleTimeString() : 'Now'}
                  </div>
                  <Badge variant="outline" className="text-xs" data-testid={`decision-confidence-${index}`}>
                    {(decision.confidence * 100).toFixed(1)}%
                  </Badge>
                </div>
              </CardContent>
            </Card>
          )) || (
            // Fallback static examples if no real data
            <>
              <Card className="bg-muted">
                <CardContent className="p-3 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-secondary rounded-full"></div>
                    <div>
                      <div className="text-sm font-medium" data-testid="decision-action-fallback-0">
                        🚫 Block IP Range
                      </div>
                      <div className="text-xs text-muted-foreground" data-testid="decision-reason-fallback-0">
                        192.168.1.0/24 - Suspicious activity pattern
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid="decision-time-fallback-0">2.3s ago</div>
                </CardContent>
              </Card>
              
              <Card className="bg-muted">
                <CardContent className="p-3 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-accent rounded-full"></div>
                    <div>
                      <div className="text-sm font-medium" data-testid="decision-action-fallback-1">
                        ⚠️ Escalate Alert
                      </div>
                      <div className="text-xs text-muted-foreground" data-testid="decision-reason-fallback-1">
                        Anomaly in Layer 3 - Auth bypass attempt
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid="decision-time-fallback-1">5.1s ago</div>
                </CardContent>
              </Card>
              
              <Card className="bg-muted">
                <CardContent className="p-3 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <div>
                      <div className="text-sm font-medium" data-testid="decision-action-fallback-2">
                        🔒 Isolate Service
                      </div>
                      <div className="text-xs text-muted-foreground" data-testid="decision-reason-fallback-2">
                        API Gateway - Rate limit exceeded
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid="decision-time-fallback-2">12.7s ago</div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
