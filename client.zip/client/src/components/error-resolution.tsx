import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AlertCircle, Wrench, CheckCircle, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface SystemError {
  id: string;
  error: string;
  context: any;
  timestamp: Date;
  fixed: boolean;
}

export default function ErrorResolution() {
  const [dismissedErrors, setDismissedErrors] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  // Mock current error state (in real app this would come from system monitoring)
  const currentError: SystemError = {
    id: 'error_1',
    error: '[plugin:runtime-error-plugin] messages.map is not a function',
    context: {
      file: '/home/runner/workspace/client/src/components/chat-interface.tsx',
      line: 92,
      column: 26,
      cause: 'messages state not properly initialized as array'
    },
    timestamp: new Date(Date.now() - 30000), // 30 seconds ago
    fixed: false
  };

  const autoFixMutation = useMutation({
    mutationFn: async (error: SystemError) => {
      return await apiRequest(`/api/errors/auto-fix`, 'POST', {
        error: error.error,
        context: error.context
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Auto-fix Applied",
        description: `Fix applied successfully: ${data.fix_type}`,
        duration: 5000,
      });
      // In real app, would refresh system status
    },
    onError: (error) => {
      toast({
        title: "Auto-fix Failed",
        description: "Unable to automatically resolve the error",
        variant: "destructive",
      });
    }
  });

  const dismissError = (errorId: string) => {
    setDismissedErrors(prev => new Set([...prev, errorId]));
    toast({
      title: "Error Dismissed",
      description: "Error has been marked as resolved",
    });
  };

  // Don't show if error is dismissed or if there are no active errors
  if (dismissedErrors.has(currentError.id) || currentError.fixed) {
    return null;
  }

  return (
    <Card className="bg-destructive/10 border border-destructive/20 mb-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center text-destructive">
            <AlertCircle className="text-destructive text-xl mr-3" />
            Error Resolution System
            <div className="status-indicator status-learning animate-pulse-slow ml-3"></div>
            <span className="text-sm text-muted-foreground font-normal ml-2" data-testid="text-auto-fix-status">
              Auto-fixing in progress...
            </span>
          </CardTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => dismissError(currentError.id)}
            data-testid="button-dismiss-error"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-card">
            <CardContent className="p-4">
              <div className="flex items-center mb-3">
                <AlertCircle className="text-destructive mr-2" />
                <h3 className="font-medium">Detected Error</h3>
              </div>
              <div className="bg-muted p-3 rounded font-mono text-sm" data-testid="error-details">
                <div className="text-destructive mb-2">{currentError.error}</div>
                <div className="text-muted-foreground">
                  {currentError.context.file}:{currentError.context.line}:{currentError.context.column}
                </div>
              </div>
              <div className="mt-3 text-sm text-muted-foreground" data-testid="error-cause">
                Root cause: {currentError.context.cause}
              </div>
              <div className="mt-2 text-xs text-muted-foreground" data-testid="error-timestamp">
                Detected: {new Date(currentError.timestamp).toLocaleString()}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card">
            <CardContent className="p-4">
              <div className="flex items-center mb-3">
                <Wrench className="text-secondary mr-2" />
                <h3 className="font-medium">Auto-Fix Solution</h3>
              </div>
              <div className="bg-muted p-3 rounded font-mono text-sm" data-testid="auto-fix-solution">
                <div className="text-secondary mb-1">+ const [messages, setMessages] = useState([])</div>
                <div className="text-secondary mb-2">+ if (!Array.isArray(messages)) return null</div>
                <div className="text-muted-foreground">
                  Type guard added for array validation
                </div>
              </div>
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center text-sm text-secondary" data-testid="fix-status">
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Fix validated and ready
                </div>
                <Button 
                  size="sm" 
                  onClick={() => autoFixMutation.mutate(currentError)}
                  disabled={autoFixMutation.isPending}
                  data-testid="button-apply-fix"
                >
                  {autoFixMutation.isPending ? 'Applying...' : 'Apply Fix'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Success notification area */}
        {autoFixMutation.isSuccess && (
          <div className="mt-4 p-3 bg-secondary/20 border border-secondary/30 rounded-lg">
            <div className="flex items-center text-secondary">
              <CheckCircle className="mr-2 h-4 w-4" />
              <span className="font-medium" data-testid="text-fix-success">
                Auto-fix applied successfully! System is now stable.
              </span>
            </div>
          </div>
        )}

        {/* Error notification area */}
        {autoFixMutation.isError && (
          <div className="mt-4 p-3 bg-destructive/20 border border-destructive/30 rounded-lg">
            <div className="flex items-center text-destructive">
              <AlertCircle className="mr-2 h-4 w-4" />
              <span className="font-medium" data-testid="text-fix-error">
                Auto-fix failed. Manual intervention may be required.
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
