import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { SystemSetting } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function SystemControls() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings } = useQuery<SystemSetting[]>({
    queryKey: ["/api/settings"],
  });

  const forceSyncMutation = useMutation({
    mutationFn: () => apiRequest("/api/system/sync", { method: "POST" }),
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/layers"] });
      toast({
        title: "Sincronização iniciada",
        description: `Forçando sincronização com ${data.syncedLayers} camadas.`,
      });
    },
    onError: () => {
      toast({
        title: "Erro na sincronização",
        description: "Não foi possível iniciar a sincronização.",
        variant: "destructive",
      });
    },
  });

  const autoConnectMutation = useMutation({
    mutationFn: () => apiRequest("/api/layers/auto-connect", { method: "POST" }),
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/layers/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      toast({
        title: "Conexão automática concluída",
        description: `${data.connectedLayers}/${data.totalLayers} camadas conectadas com sucesso.`,
      });
    },
    onError: () => {
      toast({
        title: "Erro na conexão",
        description: "Falha ao conectar com as camadas automaticamente.",
        variant: "destructive",
      });
    },
  });

  const emergencyShutdownMutation = useMutation({
    mutationFn: () => apiRequest("/api/system/emergency-shutdown", { method: "POST" }),
    onSuccess: () => {
      toast({
        title: "Shutdown de emergência ativado",
        description: "Protocolo de emergência foi iniciado.",
        variant: "destructive",
      });
    },
    onError: () => {
      toast({
        title: "Erro no shutdown",
        description: "Não foi possível ativar o shutdown de emergência.",
        variant: "destructive",
      });
    },
  });

  const toggleSettingMutation = useMutation({
    mutationFn: (setting: { settingKey: string; settingValue: string; description: string }) =>
      apiRequest("/api/settings", {
        method: "POST",
        body: setting,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Configuração atualizada",
        description: "A configuração foi alterada com sucesso.",
      });
    },
    onError: () => {
      toast({
        title: "Erro na configuração",
        description: "Não foi possível alterar a configuração.",
        variant: "destructive",
      });
    },
  });

  const getSettingValue = (key: string): boolean => {
    const setting = settings?.find(s => s.settingKey === key);
    return setting?.settingValue === "true";
  };

  const toggleSetting = (key: string, description: string) => {
    const currentValue = getSettingValue(key);
    toggleSettingMutation.mutate({
      settingKey: key,
      settingValue: (!currentValue).toString(),
      description,
    });
  };

  return (
    <Card className="metric-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-cogs mr-2 text-primary"></i>
          Controles de Sistema
        </CardTitle>
        <CardDescription>
          Configurações operacionais e controles críticos
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Toggle Controls */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">Auto-Sync Layers</p>
            <p className="text-xs text-muted-foreground">Sincronização automática com outras camadas</p>
          </div>
          <Button
            variant={getSettingValue("auto_sync_enabled") ? "default" : "outline"}
            size="sm"
            onClick={() => toggleSetting("auto_sync_enabled", "Auto-sync with other layers")}
            data-testid="button-toggle-auto-sync"
          >
            {getSettingValue("auto_sync_enabled") ? "ON" : "OFF"}
          </Button>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">Threat Detection</p>
            <p className="text-xs text-muted-foreground">Detecção ativa de ameaças</p>
          </div>
          <Button
            variant={getSettingValue("threat_detection_enabled") ? "default" : "outline"}
            size="sm"
            onClick={() => toggleSetting("threat_detection_enabled", "Active threat detection")}
            data-testid="button-toggle-threat-detection"
          >
            {getSettingValue("threat_detection_enabled") ? "ON" : "OFF"}
          </Button>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">Alert Notifications</p>
            <p className="text-xs text-muted-foreground">Notificações de alerta em tempo real</p>
          </div>
          <Button
            variant={getSettingValue("alert_notifications_enabled") ? "default" : "outline"}
            size="sm"
            onClick={() => toggleSetting("alert_notifications_enabled", "Real-time alert notifications")}
            data-testid="button-toggle-notifications"
          >
            {getSettingValue("alert_notifications_enabled") ? "ON" : "OFF"}
          </Button>
        </div>

        <hr className="border-border" />

        {/* Action Buttons */}
        <Button
          className="w-full"
          onClick={() => autoConnectMutation.mutate()}
          disabled={autoConnectMutation.isPending}
          data-testid="button-auto-connect"
        >
          {autoConnectMutation.isPending ? (
            <>
              <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
              Conectando...
            </>
          ) : (
            <>
              <i className="fas fa-network-wired mr-2"></i>
              Conectar Camadas
            </>
          )}
        </Button>

        <Button
          variant="outline"
          className="w-full"
          onClick={() => forceSyncMutation.mutate()}
          disabled={forceSyncMutation.isPending}
          data-testid="button-force-sync"
        >
          {forceSyncMutation.isPending ? (
            <>
              <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
              Sincronizando...
            </>
          ) : (
            <>
              <i className="fas fa-sync-alt mr-2"></i>
              Forçar Sincronização
            </>
          )}
        </Button>

        <Button
          variant="destructive"
          className="w-full"
          onClick={() => emergencyShutdownMutation.mutate()}
          disabled={emergencyShutdownMutation.isPending}
          data-testid="button-emergency-shutdown"
        >
          {emergencyShutdownMutation.isPending ? (
            <>
              <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
              Desligando...
            </>
          ) : (
            <>
              <i className="fas fa-power-off mr-2"></i>
              Shutdown de Emergência
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
