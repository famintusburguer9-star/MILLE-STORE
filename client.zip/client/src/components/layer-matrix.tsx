import { Shield, Eye, Lock, Database, Brain, Network, Monitor, Cloud, Router } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LayerStatus } from "@/lib/types";

interface LayerMatrixProps {
  layerStatuses: LayerStatus[];
}

const layerIcons = {
  1: Shield,
  2: Eye,
  3: Lock,
  4: Database,
  5: Brain,
  6: Network,
  7: Monitor,
  8: Cloud,
  9: Router,
};

const layerNames = {
  1: "WAF",
  2: "IDS", 
  3: "Auth",
  4: "Data",
  5: "AI Core",
  6: "Network",
  7: "Endpoint",
  8: "Cloud",
  9: "IoT",
};

const layerColors = {
  1: "bg-primary",
  2: "bg-secondary",
  3: "bg-accent",
  4: "bg-chart-4",
  5: "bg-chart-5",
  6: "bg-chart-1",
  7: "bg-chart-2",
  8: "bg-chart-3",
  9: "bg-primary",
};

export default function LayerMatrix({ layerStatuses }: LayerMatrixProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'status-healthy';
      case 'warning': return 'status-warning';
      case 'error': return 'status-error';
      case 'learning': return 'status-learning';
      default: return 'status-error';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'online': return 'Online';
      case 'warning': return 'Warning';
      case 'error': return 'Error';
      case 'learning': return 'Learning';
      case 'offline': return 'Offline';
      default: return 'Unknown';
    }
  };

  const healthyConnections = layerStatuses.filter(layer => layer.status === 'online').length;
  const totalConnections = layerStatuses.length;

  return (
    <Card className="mb-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Network className="text-primary mr-2" />
            Layer Communication Matrix
          </CardTitle>
          <div className="flex items-center space-x-2">
            <div className="status-indicator status-healthy"></div>
            <span className="text-sm text-muted-foreground" data-testid="text-connection-status">
              {healthyConnections}/{totalConnections} connections healthy
            </span>
            <Button size="sm" className="ml-4" data-testid="button-auto-connect">
              Auto-Connect
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 mb-6">
          {layerStatuses.map((layer) => {
            const IconComponent = layerIcons[layer.id as keyof typeof layerIcons] || Shield;
            const layerName = layerNames[layer.id as keyof typeof layerNames] || `Layer ${layer.id}`;
            const colorClass = layerColors[layer.id as keyof typeof layerColors] || "bg-muted";
            
            return (
              <Card 
                key={layer.id} 
                className="bg-muted text-center hover:bg-muted/80 transition-colors"
                data-testid={`layer-card-${layer.id}`}
              >
                <CardContent className="p-4">
                  <div className={`w-12 h-12 ${colorClass} rounded-full flex items-center justify-center mx-auto mb-2`}>
                    <IconComponent className="text-white h-6 w-6" />
                  </div>
                  <div className="font-medium text-sm" data-testid={`text-layer-name-${layer.id}`}>
                    Layer {layer.id}
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid={`text-layer-type-${layer.id}`}>
                    {layerName}
                  </div>
                  <div className="mt-2">
                    <div className={`status-indicator ${getStatusColor(layer.status)}`}></div>
                    <span className="text-xs" data-testid={`text-layer-status-${layer.id}`}>
                      {getStatusText(layer.status)}
                    </span>
                  </div>
                  {layer.messageRate > 0 && (
                    <div className="text-xs text-muted-foreground mt-1" data-testid={`text-message-rate-${layer.id}`}>
                      {layer.messageRate.toFixed(1)} msg/s
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
        
        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <div className="text-sm font-medium mb-2">Communication Flow</div>
            <div className="text-xs text-muted-foreground space-y-1">
              <div data-testid="text-flow-1-2">• Layer 1 → Layer 2: 847 msgs/min</div>
              <div data-testid="text-flow-2-5">• Layer 2 → Layer 5: 342 msgs/min</div>
              <div data-testid="text-flow-5-all">• Layer 5 → All Layers: Broadcast decisions</div>
              <div data-testid="text-meta-learning-flow">• Meta-Learning: Cross-layer pattern analysis</div>
            </div>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  );
}
