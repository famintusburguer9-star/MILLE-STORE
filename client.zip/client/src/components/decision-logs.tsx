import { useQuery } from "@tanstack/react-query";
import { FileText, Download, Filter } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AuditLog } from "@/lib/types";

export default function DecisionLogs() {
  const { data: auditLogs, isLoading } = useQuery<AuditLog[]>({
    queryKey: ['/api/system/audit', { limit: 10 }],
    refetchInterval: 5000
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-destructive';
      case 'error': return 'bg-red-600';
      case 'warning': return 'bg-accent';
      case 'info': return 'bg-primary';
      default: return 'bg-muted';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical': return '🚨';
      case 'error': return '❌';
      case 'warning': return '⚠️';
      case 'info': return 'ℹ️';
      default: return '📝';
    }
  };

  const getActionType = (action: string) => {
    const actionTypes: Record<string, string> = {
      'decision_made': 'AUTO',
      'manual_override': 'MANUAL',
      'meta_learning_adaptation': 'LEARN',
      'layer_communication': 'COMM',
      'system_error': 'ERROR',
      'ai_threat_analysis': 'AI',
      'auto_fix_applied': 'FIX'
    };
    return actionTypes[action] || 'SYSTEM';
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="text-primary mr-2" />
            Decision Audit Logs
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            Loading audit logs...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <FileText className="text-primary mr-2" />
            Decision Audit Logs
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" data-testid="button-filter-logs">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Button variant="ghost" size="sm" data-testid="button-export-logs">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-80 overflow-y-auto scrollbar-thin">
          {auditLogs && auditLogs.length > 0 ? (
            auditLogs.map((log, index) => (
              <div key={log.id} className="bg-muted/50 p-3 rounded text-sm font-mono" data-testid={`audit-log-${index}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-secondary" data-testid={`log-timestamp-${index}`}>
                    [{new Date(log.timestamp).toLocaleTimeString()}]
                  </span>
                  <Badge 
                    className={`text-xs ${getSeverityColor(log.severity)}`}
                    data-testid={`log-action-${index}`}
                  >
                    {getActionType(log.action)}
                  </Badge>
                </div>
                <div className="text-foreground" data-testid={`log-message-${index}`}>
                  {getSeverityIcon(log.severity)} {log.message}
                </div>
                <div className="text-muted-foreground text-xs mt-1" data-testid={`log-component-${index}`}>
                  Component: {log.component} | Severity: {log.severity}
                </div>
              </div>
            ))
          ) : (
            // Fallback static logs for demonstration
            Array.from({ length: 8 }).map((_, index) => (
              <div key={index} className="bg-muted/50 p-3 rounded text-sm font-mono" data-testid={`audit-log-fallback-${index}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-secondary">
                    [{new Date(Date.now() - index * 8000).toLocaleTimeString()}]
                  </span>
                  <Badge className={`text-xs ${getSeverityColor(['info', 'warning', 'error', 'critical'][index % 4])}`}>
                    {['AUTO', 'LEARN', 'MANUAL', 'ALERT'][index % 4]}
                  </Badge>
                </div>
                <div className="text-foreground">
                  {['✅ Action: BLOCK | Target: IP 192.168.1.45 | Confidence: 0.97',
                    '🎓 Meta-Learning: New attack pattern identified',
                    '🔄 MAML adaptation completed | Layers: 1,2,3',
                    '🚨 Critical decision: Service isolation initiated',
                    '🔗 Connection established: Layer 4 ↔ Layer 7',
                    '🛡️ Threat detection: Advanced phishing detected',
                    '⚡ Auto-fix applied: Memory leak resolved',
                    '📊 Performance metric: Decision latency optimized'][index]}
                </div>
                <div className="text-muted-foreground text-xs mt-1">
                  {['Reason: Suspicious login pattern detected',
                    'Updated DQN weights | Reward: +0.23',
                    'Improved cross-layer communication efficiency',
                    'Manual override available for 30 seconds',
                    'Auto-connection protocol successful',
                    'Confidence: 94.7% | Source: Layer 2',
                    'System stability improved by 12%',
                    'Average latency reduced to 2.1ms'][index]}
                </div>
              </div>
            ))
          )}
        </div>
        
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span data-testid="text-monitoring-status">Real-time monitoring active</span>
            <span className="flex items-center" data-testid="text-live-indicator">
              <div className="w-2 h-2 bg-secondary rounded-full mr-2 animate-pulse-slow"></div>
              Live
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
