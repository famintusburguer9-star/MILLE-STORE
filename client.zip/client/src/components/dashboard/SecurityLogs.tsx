import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

interface SecurityLogsProps {
  data?: {
    recentIncidents?: Array<{
      id: string;
      timestamp: string | Date;
      category: string;
      description: string;
      severity: number;
      sourceIp?: string;
      actionTaken?: string;
    }>;
  } | null;
}

export default function SecurityLogs({ data }: SecurityLogsProps) {
  const incidents = data?.recentIncidents || [];

  const getSeverityColor = (severity: number) => {
    if (severity >= 8) return 'bg-red-500';
    if (severity >= 6) return 'bg-destructive';
    if (severity >= 4) return 'bg-yellow-400';
    if (severity >= 2) return 'bg-primary';
    return 'bg-green-400';
  };

  const getSeverityTextColor = (severity: number) => {
    if (severity >= 8) return 'text-red-400';
    if (severity >= 6) return 'text-destructive';
    if (severity >= 4) return 'text-yellow-400';
    if (severity >= 2) return 'text-primary';
    return 'text-green-400';
  };

  const formatTimestamp = (timestamp: string | Date) => {
    try {
      const date = typeof timestamp === 'string' ? new Date(timestamp) : timestamp;
      return formatDistanceToNow(date, { addSuffix: true });
    } catch {
      return 'Unknown time';
    }
  };

  return (
    <Card className="bg-card border-border" data-testid="security-logs">
      <CardHeader className="flex flex-row items-center justify-between pb-6">
        <CardTitle className="text-lg font-semibold text-foreground">
          Security Event Log
        </CardTitle>
        <Button 
          variant="outline" 
          size="sm"
          data-testid="button-view-all-logs"
        >
          View All
        </Button>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-3 max-h-64 overflow-y-auto" data-testid="security-logs-list">
          {incidents.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>No recent security events</p>
            </div>
          ) : (
            incidents.map((incident, index) => (
              <div 
                key={incident.id || index} 
                className="flex items-start space-x-3 p-3 bg-secondary rounded-lg"
                data-testid={`security-log-${index}`}
              >
                <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${getSeverityColor(incident.severity)}`}></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground font-medium line-clamp-2">
                    {incident.description || incident.category || 'Security event detected'}
                  </p>
                  <div className="flex items-center space-x-2 mt-1">
                    <p className="text-xs text-muted-foreground font-mono">
                      {incident.sourceIp && `IP: ${incident.sourceIp} | `}
                      {formatTimestamp(incident.timestamp)}
                    </p>
                  </div>
                  {incident.actionTaken && (
                    <p className={`text-xs mt-1 font-medium ${getSeverityTextColor(incident.severity)}`}>
                      {incident.actionTaken.charAt(0).toUpperCase() + incident.actionTaken.slice(1)}
                    </p>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
