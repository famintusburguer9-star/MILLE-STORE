import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getQueryFn } from "@/lib/queryClient";
import { Incident } from "@shared/schema";
import { Shield, Bug, Network, ExternalLink } from "lucide-react";

export function RealTimeIncidents() {
  const { data: incidentsData, isLoading, error } = useQuery({
    queryKey: ["/api/incidents", 1, { per_page: 5 }],
    queryFn: getQueryFn(),
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case "malware":
        return Bug;
      case "intrusion":
        return Shield;
      default:
        return Network;
    }
  };

  const getSeverityColor = (severity: number) => {
    if (severity >= 9) return "bg-red-500";
    if (severity >= 7) return "bg-orange-500";
    if (severity >= 5) return "bg-yellow-500";
    if (severity >= 3) return "bg-blue-500";
    return "bg-green-500";
  };

  const getSeverityLabel = (severity: number) => {
    if (severity >= 9) return "CRITICAL";
    if (severity >= 7) return "HIGH";
    if (severity >= 5) return "MEDIUM";
    return "LOW";
  };

  const formatTimeAgo = (timestamp: string | null) => {
    if (!timestamp) return "Unknown";
    
    const now = new Date();
    const time = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - time.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s ago`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  return (
    <Card className="h-full">
      <CardHeader className="border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-foreground">
            Real-time Security Incidents
          </CardTitle>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-sm text-muted-foreground">Live</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center space-x-4 p-4 bg-muted/50 rounded-lg">
                  <div className="w-10 h-10 bg-muted rounded-lg"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-muted rounded mb-2"></div>
                    <div className="h-3 bg-muted rounded w-2/3"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-8 text-destructive">
            Error loading incidents
          </div>
        ) : !incidentsData?.incidents?.length ? (
          <div className="text-center py-8 text-muted-foreground">
            No recent incidents
          </div>
        ) : (
          <div className="space-y-4">
            {incidentsData.incidents.map((incident: Incident) => {
              const CategoryIcon = getCategoryIcon(incident.category);
              const severityColor = getSeverityColor(incident.severity);
              const severityLabel = getSeverityLabel(incident.severity);
              
              return (
                <div
                  key={incident.id}
                  className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border border-border hover:bg-muted/70 transition-colors"
                  data-testid={`incident-${incident.id}`}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-10 h-10 ${severityColor}/20 rounded-lg flex items-center justify-center`}>
                      <CategoryIcon className={`w-5 h-5 ${severityColor.replace('bg-', 'text-')}`} />
                    </div>
                    <div>
                      <h3 className="font-medium text-foreground">
                        {incident.category || "Unknown Category"}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {incident.sourceIp && incident.destinationIp
                          ? `${incident.sourceIp} → ${incident.destinationIp}`
                          : incident.description || "No description available"}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <Badge className={`${severityColor} text-white text-xs`}>
                      {severityLabel}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {formatTimeAgo(incident.timestamp)}
                    </span>
                    <Button size="sm" variant="ghost" data-testid={`incident-details-${incident.id}`}>
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
            
            <div className="mt-6 flex justify-center">
              <Button variant="outline" data-testid="button-view-all-incidents">
                View All Incidents
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
