import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, CheckCircle, Clock, Layers } from "lucide-react";
import type { DashboardMetrics } from "@shared/schema";

const MetricsOverview = () => {
  const { data: metrics, isLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics"],
  });

  const metricItems = [
    {
      title: "Incidentes Ativos",
      value: metrics?.activeIncidents || 0,
      icon: AlertTriangle,
      iconColor: "text-red-600",
      bgColor: "bg-red-100",
      change: "+12%",
      changeType: "increase" as const,
      period: "últimas 24h",
    },
    {
      title: "Taxa de Resolução",
      value: `${metrics?.resolutionRate || 0}%`,
      icon: CheckCircle,
      iconColor: "text-green-600",
      bgColor: "bg-green-100",
      change: "+2.1%",
      changeType: "increase" as const,
      period: "últimas 24h",
    },
    {
      title: "Tempo Médio",
      value: `${metrics?.avgResolutionTime || 0}h`,
      icon: Clock,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100",
      change: "-0.3h",
      changeType: "decrease" as const,
      period: "últimas 24h",
    },
    {
      title: "Camadas Ativas",
      value: `${metrics?.activeLayers || 0}/${metrics?.totalLayers || 4}`,
      icon: Layers,
      iconColor: "text-purple-600",
      bgColor: "bg-purple-100",
      change: "Todas Online",
      changeType: "neutral" as const,
      period: "",
    },
  ];

  if (isLoading) {
    return (
      <section className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="metric-card">
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="flex items-center justify-between mb-4">
                    <div className="space-y-2">
                      <div className="h-4 bg-muted rounded w-24"></div>
                      <div className="h-8 bg-muted rounded w-16"></div>
                    </div>
                    <div className="w-12 h-12 bg-muted rounded-lg"></div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="h-4 bg-muted rounded w-12"></div>
                    <div className="h-4 bg-muted rounded w-16"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metricItems.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card key={index} className="metric-card" data-testid={`metric-${metric.title.toLowerCase().replace(/\s+/g, '-')}`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{metric.title}</p>
                    <p className="text-3xl font-bold text-foreground">{metric.value}</p>
                  </div>
                  <div className={`w-12 h-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
                    <Icon className={metric.iconColor} size={24} />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className={`flex items-center ${
                    metric.changeType === "increase" ? "text-red-600" :
                    metric.changeType === "decrease" ? "text-green-600" :
                    "text-green-600"
                  }`}>
                    {metric.change}
                  </span>
                  {metric.period && (
                    <span className="text-muted-foreground ml-2">{metric.period}</span>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </section>
  );
};

export default MetricsOverview;
