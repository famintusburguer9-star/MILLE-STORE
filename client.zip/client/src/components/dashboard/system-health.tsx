import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { getQueryFn } from "@/lib/queryClient";
import { Activity, Database, Wifi, Zap } from "lucide-react";

export function SystemHealth() {
  const { data: systemHealth } = useQuery({
    queryKey: ["/api/system/health"],
    queryFn: getQueryFn(),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: systemMetrics } = useQuery({
    queryKey: ["/api/system/metrics"],
    queryFn: getQueryFn(),
    refetchInterval: 30000,
  });

  const getProgressColor = (value: number) => {
    if (value >= 90) return "bg-red-500";
    if (value >= 75) return "bg-orange-500";
    if (value >= 50) return "bg-yellow-500";
    return "bg-green-500";
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "healthy":
        return "default";
      case "warning":
        return "secondary";
      case "critical":
        return "destructive";
      default:
        return "outline";
    }
  };

  const cpuUsage = systemMetrics?.current?.cpuUsage || 0;
  const memoryUsage = systemMetrics?.current?.memoryUsage || 0;
  const apiLatency = systemMetrics?.current?.apiLatency || 0;

  return (
    <Card className="h-full">
      <CardHeader className="border-b border-border">
        <CardTitle className="text-lg font-semibold text-foreground flex items-center space-x-2">
          <Activity className="w-5 h-5" />
          <span>System Health</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-2 gap-4">
          {/* Left Column */}
          <div className="space-y-3">
            {/* CPU Usage */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">CPU Usage</span>
                <span className="text-sm font-medium text-foreground" data-testid="text-cpu-usage">
                  {cpuUsage.toFixed(0)}%
                </span>
              </div>
              <Progress 
                value={cpuUsage} 
                className="w-full h-2"
                data-testid="progress-cpu"
              />
            </div>

            {/* Memory */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">Memory</span>
                <span className="text-sm font-medium text-foreground" data-testid="text-memory-usage">
                  {memoryUsage.toFixed(0)}%
                </span>
              </div>
              <Progress 
                value={memoryUsage} 
                className="w-full h-2"
                data-testid="progress-memory"
              />
            </div>

            {/* Redis */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">Redis</span>
                <Badge variant="default" className="text-xs" data-testid="badge-redis-status">
                  Online
                </Badge>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-xs text-muted-foreground">Connection pooled</span>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-3">
            {/* API Latency */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">API Latency</span>
                <span className="text-sm font-medium text-foreground" data-testid="text-api-latency">
                  {apiLatency.toFixed(0)}ms
                </span>
              </div>
              <Progress 
                value={Math.min(100, (apiLatency / 1000) * 100)} 
                className="w-full h-2"
                data-testid="progress-latency"
              />
            </div>

            {/* Database */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">Database</span>
                <Badge variant="default" className="text-xs" data-testid="badge-database-status">
                  Healthy
                </Badge>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-xs text-muted-foreground">
                  {systemMetrics?.current?.activeConnections || 5} connections active
                </span>
              </div>
            </div>

            {/* Circuit Breakers */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">Circuit Breakers</span>
                <Badge variant="default" className="text-xs" data-testid="badge-circuit-breakers">
                  All Closed
                </Badge>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-xs text-muted-foreground">0 failures</span>
              </div>
            </div>
          </div>
        </div>

        {/* System Alerts */}
        {systemHealth?.alerts && systemHealth.alerts.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border">
            <h4 className="text-sm font-medium text-foreground mb-2">Active Alerts</h4>
            <div className="space-y-2">
              {systemHealth.alerts.map((alert: string, index: number) => (
                <div key={index} className="text-xs text-orange-600 bg-orange-50 dark:bg-orange-950 p-2 rounded">
                  {alert}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Overall Status */}
        <div className="mt-4 pt-4 border-t border-border text-center">
          <div className="flex items-center justify-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${
              systemHealth?.status === "healthy" ? "bg-green-500" :
              systemHealth?.status === "warning" ? "bg-yellow-500" :
              systemHealth?.status === "critical" ? "bg-red-500" : "bg-gray-500"
            }`} />
            <span className="text-sm font-medium" data-testid="text-overall-status">
              System {systemHealth?.status || "Unknown"}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
