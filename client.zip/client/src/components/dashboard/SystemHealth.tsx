import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import type { SystemMetric } from "@shared/schema";

const SystemHealth = () => {
  const { data: metrics, isLoading } = useQuery<SystemMetric[]>({
    queryKey: ["/api/system/metrics"],
  });

  const getProgressColor = (value: number) => {
    if (value >= 80) return "bg-red-500";
    if (value >= 60) return "bg-yellow-500";
    return "bg-green-500";
  };

  const getMetricByType = (type: string) => {
    if (!metrics) return null;
    return metrics.find(m => m.metricType === type);
  };

  const healthMetrics = [
    { type: "cpu", label: "CPU", unit: "%" },
    { type: "memory", label: "Memória", unit: "%" },
    { type: "disk", label: "Disco", unit: "%" },
    { type: "network", label: "Rede", unit: "%" },
  ];

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Saúde do Sistema</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center justify-between mb-2">
                  <div className="h-4 bg-muted rounded w-16"></div>
                  <div className="h-4 bg-muted rounded w-12"></div>
                </div>
                <div className="w-full bg-muted rounded-full h-2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Saúde do Sistema</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {healthMetrics.map((metric) => {
            const data = getMetricByType(metric.type);
            const value = data?.value || 0;
            
            return (
              <div key={metric.type} data-testid={`system-health-${metric.type}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">{metric.label}</span>
                  <span className="text-sm font-medium text-foreground">
                    {value}{metric.unit}
                  </span>
                </div>
                <Progress 
                  value={value} 
                  className="w-full h-2"
                />
              </div>
            );
          })}
        </div>

        <div className="mt-6 pt-4 border-t border-border">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Última atualização</span>
            <span className="text-foreground font-medium">Há 2 minutos</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SystemHealth;
