import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { 
  Shield, 
  LayoutDashboard, 
  AlertTriangle, 
  Brain, 
  Search, 
  Cog, 
  BarChart3, 
  FileText,
  Settings,
  User,
  LogOut
} from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const navigation = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Incidents", href: "/incidents", icon: AlertTriangle },
    { name: "RL Training", href: "/rl-training", icon: Brain },
    { name: "Forensic Analysis", href: "/forensics", icon: Search },
    { name: "Actions", href: "/actions", icon: Cog },
    { name: "Monitoring", href: "/monitoring", icon: BarChart3 },
    { name: "Reports", href: "/reports", icon: FileText },
    { name: "Configuration", href: "/config", icon: Settings },
  ];

  return (
    <div className="w-64 bg-slate-900 text-white flex-shrink-0 flex flex-col">
      {/* Logo */}
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold gradient-text">AZYRÍS</h1>
            <p className="text-xs text-slate-400">Camada 4 - RL Engine</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 px-4 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          return (
            <Link key={item.name} href={item.href}>
              <div
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? "bg-primary/20 text-primary-foreground border border-primary/30"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
                data-testid={`nav-link-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <Icon className="w-5 h-5" />
                <span className={isActive ? "font-medium" : ""}>{item.name}</span>
              </div>
            </Link>
          );
        })}
      </nav>
      
      {/* User Info */}
      <div className="p-4 border-t border-slate-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center">
            <User className="w-4 h-4 text-slate-300" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-white" data-testid="text-username">
              {user?.username || "Admin User"}
            </p>
            <p className="text-xs text-slate-400">{user?.role || "Administrator"}</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => logoutMutation.mutate()}
            className="text-slate-400 hover:text-white"
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
