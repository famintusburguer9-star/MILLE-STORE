import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getQueryFn } from "@/lib/queryClient";
import { RLAction } from "@shared/schema";
import { 
  Check, 
  Shield, 
  Bell, 
  Database, 
  Ban,
  AlertTriangle,
  Settings,
  Clock
} from "lucide-react";

export function RecentActions() {
  const { data: rlMetrics } = useQuery({
    queryKey: ["/api/rl/metrics"],
    queryFn: getQueryFn(),
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const getActionIcon = (action: string) => {
    switch (action.toLowerCase()) {
      case "monitor":
        return Settings;
      case "alert":
        return Bell;
      case "isolate":
      case "block":
        return Ban;
      case "quarantine":
        return Database;
      case "escalate":
        return AlertTriangle;
      default:
        return Shield;
    }
  };

  const getActionColor = (action: string) => {
    switch (action.toLowerCase()) {
      case "monitor":
        return "text-blue-600 bg-blue-500/20";
      case "alert":
        return "text-orange-500 bg-orange-500/20";
      case "isolate":
      case "block":
        return "text-red-600 bg-red-500/20";
      case "quarantine":
        return "text-purple-600 bg-purple-500/20";
      case "escalate":
        return "text-yellow-600 bg-yellow-500/20";
      default:
        return "text-green-600 bg-green-500/20";
    }
  };

  const getActionDescription = (action: RLAction) => {
    switch (action.action.toLowerCase()) {
      case "monitor":
        return "Enhanced monitoring activated";
      case "alert":
        return "Security team alerted";
      case "isolate":
        return `Source ${action.incident?.sourceIp || "unknown"} isolated`;
      case "block":
        return "Traffic patterns blocked";
      case "quarantine":
        return "Suspicious files quarantined";
      case "escalate":
        return "Incident escalated to senior team";
      default:
        return `${action.action} action executed`;
    }
  };

  const formatTimeAgo = (timestamp: string | null) => {
    if (!timestamp) return "Unknown";
    
    const now = new Date();
    const time = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - time.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s ago`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    return `${Math.floor(diffInSeconds / 86400)}d ago`;
  };

  const recentActions = rlMetrics?.recent_actions || [];

  return (
    <Card className="h-full">
      <CardHeader className="border-b border-border">
        <CardTitle className="text-lg font-semibold text-foreground flex items-center space-x-2">
          <Check className="w-5 h-5" />
          <span>Recent RL Actions</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {recentActions.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Settings className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
            <p>No recent actions</p>
          </div>
        ) : (
          <div className="space-y-4">
            {recentActions.slice(0, 6).map((action: RLAction) => {
              const ActionIcon = getActionIcon(action.action);
              const actionColorClass = getActionColor(action.action);
              
              return (
                <div key={action.id} className="flex items-center space-x-4" data-testid={`action-${action.id}`}>
                  <div className={`w-8 h-8 ${actionColorClass} rounded-lg flex items-center justify-center`}>
                    <ActionIcon className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground capitalize">
                      {action.action.replace(/([A-Z])/g, ' $1').trim()}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {getActionDescription(action)}
                    </p>
                    {action.confidence && (
                      <div className="flex items-center mt-1">
                        <div className="w-16 bg-muted rounded-full h-1 mr-2">
                          <div 
                            className="bg-primary h-1 rounded-full" 
                            style={{ width: `${action.confidence * 100}%` }}
                          />
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {(action.confidence * 100).toFixed(0)}%
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Clock className="w-3 h-3 mr-1" />
                    <span>{formatTimeAgo(action.timestamp)}</span>
                  </div>
                </div>
              );
            })}
            
            <div className="mt-6 flex justify-center">
              <Button variant="outline" data-testid="button-view-all-actions">
                View All Actions
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
