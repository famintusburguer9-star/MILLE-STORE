import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Stethoscope, FileDown, UserCog } from "lucide-react";

interface QuickActionsProps {
  onCreateIncident?: () => void;
  onRunDiagnostic?: () => void;
  onGenerateReport?: () => void;
  onManageUsers?: () => void;
}

const QuickActions = ({ 
  onCreateIncident, 
  onRunDiagnostic, 
  onGenerateReport, 
  onManageUsers 
}: QuickActionsProps) => {
  const actions = [
    {
      icon: Plus,
      title: "Criar Incidente",
      description: "Reportar novo problema",
      color: "bg-primary/10 text-primary",
      onClick: onCreateIncident,
      testId: "button-create-incident",
    },
    {
      icon: Stethoscope,
      title: "Diagnóstico",
      description: "Executar verificações",
      color: "bg-blue-500/10 text-blue-500",
      onClick: onRunDiagnostic,
      testId: "button-run-diagnostic",
    },
    {
      icon: FileDown,
      title: "Gerar Relatório",
      description: "Exportar métricas",
      color: "bg-green-500/10 text-green-500",
      onClick: onGenerateReport,
      testId: "button-generate-report",
    },
    {
      icon: UserCog,
      title: "Gerenciar Usuários",
      description: "Administrar acesso",
      color: "bg-purple-500/10 text-purple-500",
      onClick: onManageUsers,
      testId: "button-manage-users",
    },
  ];

  return (
    <section className="mt-8">
      <Card>
        <CardHeader>
          <CardTitle>Ações Rápidas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {actions.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.title}
                  variant="outline"
                  className="flex items-center space-x-3 p-4 h-auto justify-start hover:bg-accent transition-colors"
                  onClick={action.onClick}
                  data-testid={action.testId}
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${action.color}`}>
                    <Icon size={20} />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-medium text-foreground">{action.title}</p>
                    <p className="text-xs text-muted-foreground">{action.description}</p>
                  </div>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </section>
  );
};

export default QuickActions;
