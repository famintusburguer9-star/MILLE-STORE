import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Loader2, Shield } from "lucide-react";

interface LayerStatusProps {
  data?: {
    layerStatus?: Array<{
      id: number;
      name: string;
      description: string;
      status: 'online' | 'offline' | 'syncing' | 'error';
      lastSeen: Date | null;
    }>;
  } | null;
}

const defaultLayers = [
  { id: 1, name: 'Layer 1', description: 'Network Gateway', status: 'online' as const },
  { id: 2, name: 'Layer 2', description: 'Data Processing', status: 'online' as const },
  { id: 3, name: 'Layer 3', description: 'Authentication', status: 'online' as const },
  { id: 4, name: 'Layer 4', description: 'Security Core (Current)', status: 'online' as const },
  { id: 5, name: 'Layers 5-9', description: 'Syncing...', status: 'syncing' as const },
];

export default function LayerStatus({ data }: LayerStatusProps) {
  const layers = data?.layerStatus || defaultLayers;

  const getStatusIcon = (status: string, layerId: number) => {
    switch (status) {
      case 'online':
        return layerId === 4 ? (
          <Shield className="text-primary" />
        ) : (
          <CheckCircle className="text-green-400" />
        );
      case 'syncing':
        return <Loader2 className="text-yellow-400 animate-spin" />;
      case 'error':
        return <CheckCircle className="text-red-400" />;
      default:
        return <CheckCircle className="text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'text-green-400';
      case 'syncing':
        return 'text-yellow-400';
      case 'error':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };

  const getStatusText = (status: string, layerId: number) => {
    if (layerId === 4) return 'Active';
    
    switch (status) {
      case 'online':
        return 'Online';
      case 'syncing':
        return 'Syncing...';
      case 'error':
        return 'Error';
      default:
        return 'Offline';
    }
  };

  return (
    <Card className="bg-card border-border" data-testid="layer-status">
      <CardHeader className="pb-6">
        <CardTitle className="text-lg font-semibold text-foreground">
          AZYRÍS Layer Status
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {layers.slice(0, 5).map((layer, index) => {
            const isCurrentLayer = layer.id === 4 || layer.name.includes('Layer 4');
            
            return (
              <div
                key={layer.id || index}
                className={`flex items-center justify-between p-3 rounded-lg ${
                  isCurrentLayer 
                    ? 'bg-primary/20 border border-primary gradient-border' 
                    : 'bg-secondary'
                }`}
                data-testid={`layer-${layer.id || index}`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`status-indicator ${
                    layer.status === 'online' ? 'status-online' :
                    layer.status === 'syncing' ? 'status-warning' : 'status-critical'
                  }`}></div>
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {layer.name}
                    </p>
                    <p className={`text-xs ${
                      isCurrentLayer ? 'text-primary' : 'text-muted-foreground'
                    }`}>
                      {layer.description}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {getStatusIcon(layer.status, layer.id)}
                  <span className={`text-xs font-medium ${getStatusColor(layer.status)}`}>
                    {getStatusText(layer.status, layer.id)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
