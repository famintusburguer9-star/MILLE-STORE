import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { getQueryFn } from "@/lib/queryClient";
import { AlertTriangle, Brain, TrendingUp, Clock } from "lucide-react";

export function SystemOverviewCards() {
  const { data: incidentsStats } = useQuery({
    queryKey: ["/api/incidents/statistics"],
    queryFn: getQueryFn(),
  });

  const { data: rlMetrics } = useQuery({
    queryKey: ["/api/rl/metrics"],
    queryFn: getQueryFn(),
  });

  const { data: systemMetrics } = useQuery({
    queryKey: ["/api/system/metrics"],
    queryFn: getQueryFn(),
  });

  const totalIncidents = incidentsStats?.total_incidents || 0;
  const pendingIncidents = totalIncidents - (incidentsStats?.processed_incidents || 0);
  const totalActions = rlMetrics?.recent_actions?.length || 0;
  const modelAccuracy = rlMetrics?.training?.averageReward 
    ? Math.min(95, Math.max(50, (rlMetrics.training.averageReward + 100) / 2))
    : 0;
  const responseTime = systemMetrics?.current?.apiLatency || 0;

  const cards = [
    {
      title: "Active Incidents",
      value: pendingIncidents,
      icon: AlertTriangle,
      color: "text-red-500",
      bgColor: "bg-red-500/10",
      change: pendingIncidents > 10 ? "+12%" : "-5%",
      changeColor: pendingIncidents > 10 ? "text-red-500" : "text-green-600",
      testId: "card-active-incidents"
    },
    {
      title: "RL Actions Taken",
      value: totalActions,
      icon: Brain,
      color: "text-primary",
      bgColor: "bg-primary/10",
      change: "+8%",
      changeColor: "text-green-600",
      testId: "card-rl-actions"
    },
    {
      title: "Model Accuracy",
      value: `${modelAccuracy.toFixed(1)}%`,
      icon: TrendingUp,
      color: "text-green-600",
      bgColor: "bg-green-500/10",
      change: "+2.1%",
      changeColor: "text-green-600",
      testId: "card-model-accuracy"
    },
    {
      title: "Response Time",
      value: `${responseTime.toFixed(0)}ms`,
      icon: Clock,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      change: "-15%",
      changeColor: "text-green-600",
      testId: "card-response-time"
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => {
        const Icon = card.icon;
        
        return (
          <Card key={index} className="hover:shadow-lg transition-shadow" data-testid={card.testId}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{card.title}</p>
                  <p className="text-2xl font-bold text-foreground" data-testid={`${card.testId}-value`}>
                    {card.value}
                  </p>
                </div>
                <div className={`w-12 h-12 ${card.bgColor} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${card.color} w-6 h-6`} />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <span className={card.changeColor}>{card.change}</span>
                <span className="text-muted-foreground ml-2">vs last hour</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
