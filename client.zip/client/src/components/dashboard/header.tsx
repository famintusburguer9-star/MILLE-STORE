import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getQueryFn } from "@/lib/queryClient";
import { Bell, Clock } from "lucide-react";
import { useEffect, useState } from "react";

export function Header() {
  const [currentTime, setCurrentTime] = useState(new Date());

  const { data: systemHealth } = useQuery({
    queryKey: ["/api/system/health"],
    queryFn: getQueryFn(),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: incidentsData } = useQuery({
    queryKey: ["/api/incidents", 1, { processed: "false" }],
    queryFn: getQueryFn(),
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "healthy":
        return "bg-green-500";
      case "warning":
        return "bg-yellow-500";
      case "critical":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  const pendingIncidents = incidentsData?.pagination?.total || 0;

  return (
    <header className="bg-card border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Security Operations Dashboard</h1>
          <p className="text-muted-foreground">Real-time RL-powered threat response system</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* System Status */}
          <div className="flex items-center space-x-2">
            <div 
              className={`w-2 h-2 rounded-full animate-pulse ${getStatusColor(systemHealth?.status || "unknown")}`}
            />
            <span className="text-sm text-muted-foreground" data-testid="text-system-status">
              System {systemHealth?.status || "Unknown"}
            </span>
          </div>
          
          {/* Notifications */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="relative"
            data-testid="button-notifications"
          >
            <Bell className="w-4 h-4" />
            {pendingIncidents > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center text-xs p-0"
                data-testid="badge-notification-count"
              >
                {pendingIncidents > 99 ? "99+" : pendingIncidents}
              </Badge>
            )}
          </Button>
          
          {/* Time Display */}
          <div className="flex items-center text-sm text-muted-foreground">
            <Clock className="w-4 h-4 mr-2" />
            <span data-testid="text-current-time">
              {currentTime.toLocaleString("en-US", {
                year: "numeric",
                month: "2-digit",
                day: "2-digit",
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                timeZoneName: "short"
              })}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
