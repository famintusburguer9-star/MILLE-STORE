import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Shield, Network, Brain } from "lucide-react";

interface MetricsGridProps {
  data?: {
    threatStats?: {
      totalThreats: number;
      threatsBlocked: number;
      activeConnections: number;
      mlAccuracy: number;
    };
  } | null;
}

export default function MetricsGrid({ data }: MetricsGridProps) {
  const threatStats = data?.threatStats || {
    totalThreats: 0,
    threatsBlocked: 0,
    activeConnections: 0,
    mlAccuracy: 0,
  };

  const successRate = threatStats.totalThreats > 0 
    ? ((threatStats.threatsBlocked / threatStats.totalThreats) * 100).toFixed(1)
    : '0.0';

  const threatIncrease = threatStats.totalThreats > 100 
    ? '+' + Math.floor((threatStats.totalThreats - 100) / 100 * 23) + '% from last hour'
    : 'No recent threats';

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" data-testid="metrics-grid">
      
      {/* Threats Detected */}
      <Card className="bg-card border-border" data-testid="metric-threats-detected">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Threats Detected
          </CardTitle>
          <AlertTriangle className="h-4 w-4 text-destructive" />
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-3xl font-bold text-foreground" data-testid="threats-detected-count">
            {threatStats.totalThreats.toLocaleString()}
          </p>
          <p className={`text-xs ${threatStats.totalThreats > 100 ? 'text-destructive' : 'text-muted-foreground'}`}>
            {threatIncrease}
          </p>
        </CardContent>
      </Card>

      {/* Threats Blocked */}
      <Card className="bg-card border-border" data-testid="metric-threats-blocked">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Threats Blocked
          </CardTitle>
          <Shield className="h-4 w-4 text-green-400" />
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-3xl font-bold text-foreground" data-testid="threats-blocked-count">
            {threatStats.threatsBlocked.toLocaleString()}
          </p>
          <p className="text-xs text-green-400">
            {successRate}% success rate
          </p>
        </CardContent>
      </Card>

      {/* Active Connections */}
      <Card className="bg-card border-border" data-testid="metric-active-connections">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Active Connections
          </CardTitle>
          <Network className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-3xl font-bold text-foreground" data-testid="active-connections-count">
            {threatStats.activeConnections.toLocaleString()}
          </p>
          <p className="text-xs text-muted-foreground">
            Across 9 layers
          </p>
        </CardContent>
      </Card>

      {/* ML Accuracy */}
      <Card className="bg-card border-border" data-testid="metric-ml-accuracy">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            ML Accuracy
          </CardTitle>
          <Brain className="h-4 w-4 text-purple-400" />
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-3xl font-bold text-foreground" data-testid="ml-accuracy-percentage">
            {(threatStats.mlAccuracy * 100).toFixed(1)}%
          </p>
          <p className="text-xs text-green-400">
            +0.3% improvement
          </p>
        </CardContent>
      </Card>

    </div>
  );
}
