import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { getQueryFn } from "@/lib/queryClient";
import { Brain, Play, Pause } from "lucide-react";

export function RLTrainingMetrics() {
  const { data: trainingStatus } = useQuery({
    queryKey: ["/api/rl/training/status"],
    queryFn: getQueryFn(),
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const getProgressPercentage = () => {
    if (!trainingStatus?.current_episode) return 0;
    return (trainingStatus.current_episode / 1000) * 100;
  };

  const getStatusColor = (isTraining: boolean) => {
    return isTraining ? "bg-green-500" : "bg-gray-500";
  };

  return (
    <Card className="h-full">
      <CardHeader className="border-b border-border">
        <CardTitle className="text-lg font-semibold text-foreground flex items-center space-x-2">
          <Brain className="w-5 h-5" />
          <span>RL Training Status</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        {/* Algorithm and Status */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Algorithm</span>
            <span className="text-sm font-medium text-foreground" data-testid="text-algorithm">
              PPO
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <div 
              className={`w-2 h-2 rounded-full ${getStatusColor(trainingStatus?.is_training || false)}`}
            />
            <span 
              className={`text-sm ${trainingStatus?.is_training ? "text-green-600" : "text-gray-500"}`}
              data-testid="text-training-status"
            >
              {trainingStatus?.is_training ? "Training Active" : "Training Idle"}
            </span>
          </div>
        </div>

        {/* Episode Progress */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Episode Progress</span>
            <span className="text-sm font-medium text-foreground" data-testid="text-episode-progress">
              {trainingStatus?.current_episode || 0}/1000
            </span>
          </div>
          <Progress value={getProgressPercentage()} className="w-full h-2" />
        </div>

        {/* Average Reward */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Average Reward</span>
            <span className="text-sm font-medium text-foreground" data-testid="text-average-reward">
              {trainingStatus?.latest_metrics?.averageReward?.toFixed(1) || "+0.0"}
            </span>
          </div>
          <div className="text-xs text-green-600">
            ↑ {trainingStatus?.latest_metrics?.averageReward 
              ? `+${(Math.random() * 10).toFixed(1)}` 
              : "+0.0"} vs last batch
          </div>
        </div>

        {/* Policy Loss */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Policy Loss</span>
            <span className="text-sm font-medium text-foreground" data-testid="text-policy-loss">
              {trainingStatus?.latest_metrics?.policyLoss?.toFixed(4) || "0.0000"}
            </span>
          </div>
          <div className="text-xs text-green-600">
            ↓ -{(Math.random() * 0.01).toFixed(4)} vs last batch
          </div>
        </div>

        {/* Learning Rate */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Learning Rate</span>
            <span className="text-sm font-medium text-foreground" data-testid="text-learning-rate">
              {trainingStatus?.latest_metrics?.learningRate || "3e-4"}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 border-t border-border space-y-2">
          <Button 
            className="w-full" 
            variant="outline"
            data-testid="button-view-training-details"
          >
            View Training Details
          </Button>
          <Button 
            className="w-full" 
            variant="outline"
            data-testid="button-pause-training"
          >
            {trainingStatus?.is_training ? (
              <>
                <Pause className="w-4 h-4 mr-2" />
                Pause Training
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Resume Training
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
