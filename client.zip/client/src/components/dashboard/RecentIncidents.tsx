import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight } from "lucide-react";
import { Link } from "wouter";
import type { Incident } from "@shared/schema";

const RecentIncidents = () => {
  const { data: incidents, isLoading } = useQuery<Incident[]>({
    queryKey: ["/api/incidents/recent"],
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-100 text-red-800";
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-orange-100 text-orange-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open":
        return "bg-blue-100 text-blue-800";
      case "in_progress":
        return "bg-yellow-100 text-yellow-800";
      case "resolved":
        return "bg-green-100 text-green-800";
      case "closed":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatStatus = (status: string) => {
    switch (status) {
      case "in_progress":
        return "Em Progresso";
      case "open":
        return "Aberto";
      case "resolved":
        return "Resolvido";
      case "closed":
        return "Fechado";
      default:
        return status;
    }
  };

  const formatPriority = (priority: string) => {
    switch (priority) {
      case "critical":
        return "Crítica";
      case "high":
        return "Alta";
      case "medium":
        return "Média";
      case "low":
        return "Baixa";
      default:
        return priority;
    }
  };

  if (isLoading) {
    return (
      <section className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Incidentes Recentes</CardTitle>
            <p className="text-sm text-muted-foreground">Últimos incidentes reportados no sistema</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-2 flex-1">
                      <div className="h-4 bg-muted rounded w-32"></div>
                      <div className="h-4 bg-muted rounded w-48"></div>
                    </div>
                    <div className="space-y-2">
                      <div className="h-6 bg-muted rounded w-16"></div>
                      <div className="h-6 bg-muted rounded w-20"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </section>
    );
  }

  return (
    <section className="lg:col-span-2">
      <Card>
        <CardHeader>
          <CardTitle>Incidentes Recentes</CardTitle>
          <p className="text-sm text-muted-foreground">Últimos incidentes reportados no sistema</p>
        </CardHeader>
        <CardContent>
          <div className="overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Título
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Prioridade
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Atribuído
                  </th>
                </tr>
              </thead>
              <tbody className="bg-card divide-y divide-border">
                {incidents && incidents.length > 0 ? (
                  incidents.map((incident) => (
                    <tr key={incident.id} className="incident-row" data-testid={`incident-row-${incident.id}`}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">
                        #{incident.id.slice(0, 8)}
                      </td>
                      <td className="px-6 py-4 text-sm text-foreground">{incident.title}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge className={getPriorityColor(incident.priority)}>
                          {formatPriority(incident.priority)}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge className={getStatusColor(incident.status)}>
                          {formatStatus(incident.status)}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 text-sm text-muted-foreground">
                        {incident.assignedTo || "Não atribuído"}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-muted-foreground">
                      Nenhum incidente encontrado
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <div className="px-6 py-4 border-t border-border">
            <Link 
              href="/incidents" 
              className="text-primary hover:text-primary/80 text-sm font-medium"
              data-testid="link-all-incidents"
            >
              Ver todos os incidentes <ArrowRight className="ml-1 inline" size={16} />
            </Link>
          </div>
        </CardContent>
      </Card>
    </section>
  );
};

export default RecentIncidents;
