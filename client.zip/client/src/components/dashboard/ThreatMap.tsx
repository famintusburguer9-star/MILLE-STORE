import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function ThreatMap() {
  const [isLive, setIsLive] = useState(true);

  return (
    <Card className="bg-card border-border" data-testid="threat-map">
      <CardHeader className="flex flex-row items-center justify-between pb-6">
        <CardTitle className="text-lg font-semibold text-foreground">
          Real-time Threat Map
        </CardTitle>
        <div className="flex space-x-2">
          <Button 
            size="sm" 
            variant={isLive ? "default" : "secondary"}
            onClick={() => setIsLive(true)}
            data-testid="button-live"
          >
            Live
          </Button>
          <Button 
            size="sm" 
            variant={!isLive ? "default" : "secondary"}
            onClick={() => setIsLive(false)}
            data-testid="button-paused"
          >
            Paused
          </Button>
        </div>
      </CardHeader>
      
      <CardContent>
        {/* Threat visualization container */}
        <div className="relative bg-secondary rounded-lg h-64 overflow-hidden" data-testid="threat-map-visualization">
          {/* Global map background */}
          <div className="absolute inset-0 bg-gradient-to-br from-secondary via-muted to-secondary opacity-50"></div>
          
          {/* Threat indicators */}
          {isLive && (
            <>
              <div className="absolute top-12 left-16 w-3 h-3 bg-destructive rounded-full animate-ping" data-testid="threat-indicator-1"></div>
              <div className="absolute top-20 right-24 w-2 h-2 bg-yellow-400 rounded-full animate-pulse" data-testid="threat-indicator-2"></div>
              <div className="absolute bottom-16 left-32 w-4 h-4 bg-destructive rounded-full animate-ping" data-testid="threat-indicator-3"></div>
              <div className="absolute top-8 right-12 w-2 h-2 bg-green-400 rounded-full" data-testid="threat-indicator-4"></div>
              
              {/* Connection lines */}
              <svg className="absolute inset-0 w-full h-full">
                <line 
                  x1="64" y1="48" x2="200" y2="80" 
                  stroke="hsl(var(--destructive))" 
                  strokeWidth="1" 
                  opacity="0.6"
                />
                <line 
                  x1="128" y1="192" x2="300" y2="32" 
                  stroke="hsl(var(--chart-3))" 
                  strokeWidth="1" 
                  opacity="0.4"
                />
              </svg>
            </>
          )}
          
          <div className="absolute bottom-4 left-4 text-xs text-muted-foreground">
            {isLive ? 'Global threat monitoring active' : 'Threat monitoring paused'}
          </div>
          
          {/* Threat legend */}
          <div className="absolute top-4 right-4 bg-background/80 backdrop-blur-sm rounded-md p-3 text-xs space-y-1">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-destructive rounded-full"></div>
              <span className="text-muted-foreground">High Severity</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
              <span className="text-muted-foreground">Medium Severity</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span className="text-muted-foreground">Resolved</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
