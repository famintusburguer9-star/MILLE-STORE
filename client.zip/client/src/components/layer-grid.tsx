import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { LayerStatus } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface LayerGridProps {
  layers: LayerStatus[];
}

export default function LayerGrid({ layers }: LayerGridProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: layerHealth } = useQuery<{
    overall: {
      totalLayers: number;
      onlineLayers: number;
      healthyLayers: number;
      averageHealthScore: number;
      lastUpdate: string;
    };
    layers: Array<{
      layerId: number;
      name: string;
      status: string;
      healthScore: number;
      isHealthy: boolean;
    }>;
  }>({
    queryKey: ["/api/layers/health"],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const pingLayerMutation = useMutation({
    mutationFn: (layerId: number) => 
      apiRequest(`/api/layers/ping/${layerId}`, { method: "POST" }),
    onSuccess: (data: any, layerId: number) => {
      queryClient.invalidateQueries({ queryKey: ["/api/layers/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/layers/health"] });
      toast({
        title: "Ping bem-sucedido",
        description: `Layer ${layerId} respondeu com sucesso.`,
      });
    },
    onError: (error: any, layerId: number) => {
      queryClient.invalidateQueries({ queryKey: ["/api/layers/status"] });
      toast({
        title: "Ping falhou",
        description: `Layer ${layerId} não está respondendo.`,
        variant: "destructive",
      });
    },
  });

  const getLayerStatus = (layerId: number) => {
    const layer = layers.find(l => l.layerId === layerId);
    if (layerId === 4) return "active"; // Current layer
    if (!layer) return "disconnected";
    return layer.status === "online" ? "connected" : "disconnected";
  };

  const getLayerClass = (layerId: number) => {
    const status = getLayerStatus(layerId);
    switch (status) {
      case "active":
        return "layer-active";
      case "connected":
        return "layer-connected";
      default:
        return "layer-disconnected";
    }
  };

  const getHealthScore = (layerId: number) => {
    const healthData = layerHealth?.layers?.find((l: any) => l.layerId === layerId);
    return healthData?.healthScore || 0;
  };

  const isHealthy = (layerId: number) => {
    const healthData = layerHealth?.layers?.find((l: any) => l.layerId === layerId);
    return healthData?.isHealthy || false;
  };

  const getConnectionCount = (layerId: number) => {
    const layer = layers.find(l => l.layerId === layerId);
    return layer?.connectionCount || 0;
  };

  const getLastSync = (layerId: number) => {
    const layer = layers.find(l => l.layerId === layerId);
    if (!layer?.lastSync) return null;
    return new Date(layer.lastSync).toLocaleTimeString('pt-BR');
  };

  const connectedCount = layers.filter(l => l.status === "online").length;
  const disconnectedCount = 9 - connectedCount;

  return (
    <div>
      {/* Layer Grid with Enhanced Information */}
      <div className="grid grid-cols-3 gap-3 mb-6" data-testid="layer-grid">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((layerId) => (
          <div
            key={layerId}
            className={`relative p-3 rounded-lg border transition-all ${getLayerClass(layerId)} hover:shadow-md`}
            data-testid={`layer-${layerId}`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <span className="font-semibold text-sm">L{layerId}</span>
                {layerId === 4 && (
                  <Badge variant="secondary" className="text-xs">Atual</Badge>
                )}
              </div>
              <div className={`w-2 h-2 rounded-full ${
                layerId === 4 
                  ? "bg-primary" 
                  : getLayerStatus(layerId) === "connected" 
                    ? "bg-green-500" 
                    : "bg-red-500"
              }`}></div>
            </div>
            
            <div className="space-y-1 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>Status:</span>
                <span className={
                  layerId === 4 
                    ? "text-primary font-medium" 
                    : getLayerStatus(layerId) === "connected" 
                      ? "text-green-600 font-medium" 
                      : "text-red-600 font-medium"
                }>
                  {layerId === 4 ? "Ativo" : getLayerStatus(layerId) === "connected" ? "Online" : "Offline"}
                </span>
              </div>
              
              {layerId !== 4 && (
                <>
                  <div className="flex justify-between">
                    <span>Saúde:</span>
                    <span className={isHealthy(layerId) ? "text-green-600" : "text-red-600"}>
                      {Math.round(getHealthScore(layerId))}%
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span>Conexões:</span>
                    <span>{getConnectionCount(layerId)}</span>
                  </div>
                  
                  {getLastSync(layerId) && (
                    <div className="flex justify-between">
                      <span>Última sync:</span>
                      <span>{getLastSync(layerId)}</span>
                    </div>
                  )}
                </>
              )}
            </div>

            {layerId !== 4 && (
              <Button
                size="sm"
                variant="outline"
                className="w-full mt-2 h-6 text-xs"
                onClick={() => pingLayerMutation.mutate(layerId)}
                disabled={pingLayerMutation.isPending}
                data-testid={`button-ping-layer-${layerId}`}
              >
                {pingLayerMutation.isPending ? (
                  <div className="w-3 h-3 border border-current border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <i className="fas fa-satellite-dish"></i>
                )}
              </Button>
            )}
          </div>
        ))}
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-muted/50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Camadas Online</span>
            <span className="text-lg font-bold text-green-600" data-testid="connected-count">
              {connectedCount}
            </span>
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Incluindo Layer 4 (atual)
          </div>
        </div>
        
        <div className="bg-muted/50 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Desconectadas</span>
            <span className="text-lg font-bold text-red-600" data-testid="disconnected-count">
              {disconnectedCount}
            </span>
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Precisam reconectar
          </div>
        </div>
      </div>

      {/* Overall Health Indicator */}
      {layerHealth?.overall && (
        <div className="mt-4 p-3 bg-muted/30 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Saúde Geral do Sistema</span>
            <span className="text-lg font-bold">
              {Math.round(layerHealth.overall.averageHealthScore)}%
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="text-center">
              <div className="font-medium">{layerHealth.overall.healthyLayers}</div>
              <div className="text-muted-foreground">Saudáveis</div>
            </div>
            <div className="text-center">
              <div className="font-medium">{layerHealth.overall.onlineLayers}</div>
              <div className="text-muted-foreground">Online</div>
            </div>
            <div className="text-center">
              <div className="font-medium">{layerHealth.overall.totalLayers}</div>
              <div className="text-muted-foreground">Total</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}