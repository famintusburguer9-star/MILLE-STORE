import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Sidebar() {
  const [location] = useLocation();
  const { logout } = useAuth();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logout realizado",
        description: "Você foi desconectado com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro no logout",
        description: "Não foi possível realizar o logout.",
        variant: "destructive",
      });
    }
  };

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  const navigationItems = [
    { path: "/", icon: "fas fa-tachometer-alt", label: "Dashboard" },
    { path: "/incidents", icon: "fas fa-exclamation-triangle", label: "Incidentes", badge: 3 },
    { path: "/metrics", icon: "fas fa-chart-line", label: "Métricas" },
    { path: "/communication", icon: "fas fa-comments", label: "Comunicação", badge: 2 },
    { path: "/admin", icon: "fas fa-cog", label: "Administração" },
  ];

  const systemItems = [
    { path: "/logs", icon: "fas fa-list", label: "Registros" },
    { path: "/settings", icon: "fas fa-sliders-h", label: "Configurações" },
  ];

  return (
    <div className="w-64 bg-card border-r border-border flex-shrink-0 flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-shield-alt text-primary-foreground"></i>
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">AZYRÍS</h1>
            <p className="text-sm text-muted-foreground">Layer 4</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navigationItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <a
              className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${
                isActive(item.path)
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
              data-testid={`nav-${item.label.toLowerCase()}`}
            >
              <i className={`${item.icon} w-5`}></i>
              <span>{item.label}</span>
              {item.badge && (
                <span className="ml-auto bg-destructive text-destructive-foreground px-2 py-0.5 rounded-full text-xs">
                  {item.badge}
                </span>
              )}
            </a>
          </Link>
        ))}

        <div className="pt-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-2">
            Sistema
          </p>
          {systemItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a
                className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${
                  isActive(item.path)
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                data-testid={`nav-${item.label.toLowerCase()}`}
              >
                <i className={`${item.icon} w-5`}></i>
                <span>{item.label}</span>
              </a>
            </Link>
          ))}
        </div>
      </nav>

      {/* System Status */}
      <div className="p-4 border-t border-border">
        <div className="bg-muted rounded-lg p-3 mb-4">
          <p className="text-xs text-muted-foreground mb-2">Status do Sistema</p>
          <div className="space-y-1">
            <div className="flex items-center text-sm">
              <span className="status-indicator status-online">Operacional</span>
            </div>
            <p className="text-xs text-muted-foreground" data-testid="system-last-update">
              Última atualização: {new Date().toLocaleTimeString('pt-BR')}
            </p>
          </div>
        </div>
        
        <Button
          variant="outline"
          size="sm"
          className="w-full"
          onClick={handleLogout}
          data-testid="button-logout"
        >
          <i className="fas fa-sign-out-alt mr-2"></i>
          Sair
        </Button>
      </div>
    </div>
  );
}
