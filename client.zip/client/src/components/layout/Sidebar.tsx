import { Shield, BarChart3, Bug, Brain, Layers, Database, TrendingUp, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  icon: any;
  label: string;
  href: string;
  active?: boolean;
}

const navItems: NavItem[] = [
  { icon: BarChart3, label: "Dashboard", href: "#", active: true },
  { icon: Bug, label: "Threat Detection", href: "#" },
  { icon: Brain, label: "ML Engine", href: "#" },
  { icon: Layers, label: "Layer Communication", href: "#" },
  { icon: Database, label: "Database", href: "#" },
  { icon: TrendingUp, label: "Analytics", href: "#" },
  { icon: Settings, label: "Settings", href: "#" },
];

export default function Sidebar() {
  return (
    <aside className="w-64 bg-card border-r border-border flex-shrink-0" data-testid="sidebar">
      <div className="p-6">
        {/* Logo */}
        <div className="flex items-center space-x-3 mb-8" data-testid="logo">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Shield className="text-primary-foreground text-lg" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">AZYRÍS</h1>
            <p className="text-xs text-muted-foreground">Layer 4 Security</p>
          </div>
        </div>
        
        {/* Navigation */}
        <nav className="space-y-2" data-testid="navigation">
          {navItems.map((item, index) => (
            <a
              key={index}
              href={item.href}
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-md transition-colors",
                item.active
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-accent"
              )}
              data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </a>
          ))}
        </nav>
        
        {/* System Status */}
        <div className="mt-8 p-4 bg-secondary rounded-lg" data-testid="system-status">
          <h3 className="text-sm font-medium text-foreground mb-3">System Status</h3>
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">PostgreSQL</span>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
                <span className="text-green-400" data-testid="status-postgresql">Online</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">ML Engine</span>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
                <span className="text-green-400" data-testid="status-ml-engine">Active</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Layer Sync</span>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-yellow-500 animate-ping"></div>
                <span className="text-yellow-400" data-testid="status-layer-sync">Syncing</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
