import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Incident } from "@shared/schema";

interface IncidentCardProps {
  incident: Incident;
}

export default function IncidentCard({ incident }: IncidentCardProps) {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-destructive";
      case "warning":
        return "bg-chart-3";
      default:
        return "bg-muted";
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `há ${diffInMinutes} min`;
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return `há ${hours}h`;
    } else {
      const days = Math.floor(diffInMinutes / 1440);
      return `há ${days}d`;
    }
  };

  return (
    <div
      className="flex items-center justify-between p-3 bg-muted rounded-lg"
      data-testid={`incident-card-${incident.id}`}
    >
      <div className="flex items-center space-x-3">
        <div className={`w-3 h-3 ${getSeverityColor(incident.severity)} rounded-full`}></div>
        <div>
          <p className="text-sm font-medium">{incident.title}</p>
          <p className="text-xs text-muted-foreground">
            {formatTimeAgo(new Date(incident.createdAt))}
          </p>
        </div>
      </div>
      <Button
        size="sm"
        variant="outline"
        className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded hover:bg-primary/90"
        data-testid={`button-view-incident-${incident.id}`}
      >
        Ver
      </Button>
    </div>
  );
}
