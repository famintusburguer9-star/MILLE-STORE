import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Message, LayerStatus } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface ChatInterfaceProps {
  messages: Message[];
}

export default function ChatInterface({ messages }: ChatInterfaceProps) {
  const [newMessage, setNewMessage] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Ensure messages is always an array
  const safeMessages = Array.isArray(messages) ? messages : [];

  const { data: layerStatuses } = useQuery<LayerStatus[]>({
    queryKey: ["/api/layers/status"],
  });

  const sendMessageMutation = useMutation({
    mutationFn: (messageData: any) =>
      apiRequest("/api/messages", {
        method: "POST",
        body: messageData,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      setNewMessage("");
      toast({
        title: "Mensagem enviada",
        description: "Mensagem broadcast enviada para todas as camadas.",
      });
    },
    onError: () => {
      toast({
        title: "Erro ao enviar",
        description: "Não foi possível enviar a mensagem.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    sendMessageMutation.mutate({
      fromLayer: 4,
      toLayer: null, // Broadcast message
      content: newMessage.trim(),
      messageType: "info",
      metadata: null,
    });
  };

  const getMessageTypeColor = (type: string) => {
    switch (type) {
      case "alert":
        return "destructive";
      case "sync":
        return "default";
      case "ack":
        return "secondary";
      default:
        return "outline";
    }
  };

  const onlineLayers = layerStatuses?.filter(layer => layer.status === "online") || [];

  return (
    <div className="bg-card rounded-lg border border-border p-6 mb-8">
      <h3 className="text-lg font-semibold mb-4 flex items-center">
        <i className="fas fa-comments mr-2 text-chart-2"></i>
        Interface de Comunicação Inter-Camadas
      </h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Message History */}
        <div className="lg:col-span-2">
          <div className="bg-muted rounded-lg p-4 h-64 overflow-y-auto custom-scrollbar">
            <div className="space-y-3" data-testid="chat-messages">
              {safeMessages.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <i className="fas fa-comment-slash text-2xl mb-2"></i>
                  <p>Nenhuma mensagem recente</p>
                </div>
              ) : (
                safeMessages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex items-start space-x-3 ${
                      message.fromLayer === 4 ? "justify-end" : ""
                    }`}
                    data-testid={`chat-message-${message.id}`}
                  >
                    {message.fromLayer !== 4 && (
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-xs font-bold">
                        L{message.fromLayer}
                      </div>
                    )}
                    <div className={`flex-1 ${message.fromLayer === 4 ? "text-right" : ""}`}>
                      <div
                        className={`rounded-lg p-3 inline-block max-w-md ${
                          message.fromLayer === 4
                            ? "bg-primary text-primary-foreground"
                            : "bg-card border border-border"
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant={getMessageTypeColor(message.messageType)} className="text-xs">
                            {message.messageType.toUpperCase()}
                          </Badge>
                        </div>
                        <p className="text-sm">{message.content}</p>
                        <p
                          className={`text-xs mt-1 ${
                            message.fromLayer === 4
                              ? "text-primary-foreground/70"
                              : "text-muted-foreground"
                          }`}
                        >
                          {new Date(message.createdAt).toLocaleString("pt-BR")}
                        </p>
                      </div>
                    </div>
                    {message.fromLayer === 4 && (
                      <div className="w-8 h-8 bg-chart-2 rounded-full flex items-center justify-center text-xs font-bold text-background">
                        L4
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
          
          {/* Send Message */}
          <div className="mt-4 flex space-x-2">
            <Input
              placeholder="Digite sua mensagem..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              className="flex-1"
              data-testid="input-chat-message"
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            />
            <Button
              onClick={handleSendMessage}
              disabled={sendMessageMutation.isPending}
              data-testid="button-send-chat"
            >
              {sendMessageMutation.isPending ? (
                <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <i className="fas fa-paper-plane"></i>
              )}
            </Button>
          </div>
        </div>

        {/* Online Layers Sidebar */}
        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-semibold mb-2">Camadas Online</h4>
            <div className="space-y-2" data-testid="online-layers">
              {layerStatuses?.map((layer) => (
                <div
                  key={layer.layerId}
                  className={`flex items-center justify-between p-2 rounded ${
                    layer.layerId === 4 ? "bg-primary/20" : "bg-muted"
                  }`}
                  data-testid={`online-layer-${layer.layerId}`}
                >
                  <span className={`text-sm ${layer.layerId === 4 ? "font-medium" : ""}`}>
                    {layer.name}
                  </span>
                  <span
                    className={`status-indicator text-xs ${
                      layer.status === "online"
                        ? "status-online"
                        : layer.status === "reconnecting"
                        ? "status-warning"
                        : "status-error"
                    }`}
                  >
                    {layer.layerId === 4
                      ? "Atual"
                      : layer.status === "online"
                      ? "Online"
                      : layer.status === "reconnecting"
                      ? "Reconectando"
                      : "Offline"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
