interface MetricCardProps {
  title: string;
  value: string | number;
  change?: number;
  subtitle?: string;
  icon: string;
  variant?: "primary" | "destructive" | "success" | "warning";
  "data-testid"?: string;
}

export default function MetricCard({
  title,
  value,
  change,
  subtitle,
  icon,
  variant = "primary",
  "data-testid": testId,
}: MetricCardProps) {
  const getIconColor = () => {
    switch (variant) {
      case "destructive":
        return "text-destructive";
      case "success":
        return "text-chart-2";
      case "warning":
        return "text-chart-3";
      default:
        return "text-primary";
    }
  };

  const getIconBg = () => {
    switch (variant) {
      case "destructive":
        return "bg-destructive/20";
      case "success":
        return "bg-chart-2/20";
      case "warning":
        return "bg-chart-3/20";
      default:
        return "bg-primary/20";
    }
  };

  const getChangeColor = () => {
    if (!change) return "";
    return change > 0 ? "text-chart-2" : "text-destructive";
  };

  const getChangeIcon = () => {
    if (!change) return "";
    return change > 0 ? "↑" : "↓";
  };

  return (
    <div className="metric-card rounded-lg p-6" data-testid={testId}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{title}</p>
          <p className="text-3xl font-bold text-foreground">{value}</p>
          {change !== undefined ? (
            <p className={`text-xs ${getChangeColor()}`}>
              {getChangeIcon()} {Math.abs(change)}% vs ontem
            </p>
          ) : subtitle ? (
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          ) : null}
        </div>
        <div className={`w-12 h-12 ${getIconBg()} rounded-lg flex items-center justify-center`}>
          <i className={`${icon} ${getIconColor()} text-xl`}></i>
        </div>
      </div>
    </div>
  );
}
