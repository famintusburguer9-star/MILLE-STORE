import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LayerStatus } from "@shared/schema";

interface ConnectionStatusProps {
  layers: LayerStatus[];
}

export default function ConnectionStatus({ layers }: ConnectionStatusProps) {
  const { data: communications } = useQuery<any[]>({
    queryKey: ["/api/layers/communications"],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: layerHealth } = useQuery<{
    overall: {
      averageHealthScore: number;
      lastUpdate: string;
    };
  }>({
    queryKey: ["/api/layers/health"],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const getRecentCommunications = () => {
    if (!communications || !Array.isArray(communications)) return [];
    return communications.slice(0, 5); // Show last 5 communications
  };

  const getConnectionBadgeVariant = (status: string) => {
    switch (status) {
      case "delivered":
        return "default";
      case "failed":
        return "destructive";
      case "pending":
        return "secondary";
      default:
        return "outline";
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInSeconds = Math.floor((now.getTime() - time.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s atrás`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m atrás`;
    return `${Math.floor(diffInSeconds / 3600)}h atrás`;
  };

  const getOverallConnectionHealth = () => {
    const onlineCount = layers.filter(l => l.status === "online").length;
    const totalCount = layers.length;
    const percentage = Math.round((onlineCount / totalCount) * 100);
    
    if (percentage >= 80) return { status: "healthy", color: "text-green-600", icon: "fas fa-check-circle" };
    if (percentage >= 50) return { status: "warning", color: "text-yellow-600", icon: "fas fa-exclamation-triangle" };
    return { status: "critical", color: "text-red-600", icon: "fas fa-times-circle" };
  };

  const healthStatus = getOverallConnectionHealth();

  return (
    <div className="space-y-4">
      {/* Overall Connection Health */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <i className="fas fa-heartbeat mr-2 text-primary"></i>
              Status de Conectividade
            </span>
            <Badge variant={healthStatus.status === "healthy" ? "default" : healthStatus.status === "warning" ? "secondary" : "destructive"}>
              <i className={`${healthStatus.icon} mr-1`}></i>
              {healthStatus.status === "healthy" ? "Saudável" : healthStatus.status === "warning" ? "Atenção" : "Crítico"}
            </Badge>
          </CardTitle>
          <CardDescription>
            Status em tempo real das conexões inter-camadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-green-600">
                {layers.filter(l => l.status === "online").length}
              </div>
              <div className="text-sm text-muted-foreground">Online</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-yellow-600">
                {layers.filter(l => l.status === "reconnecting").length}
              </div>
              <div className="text-sm text-muted-foreground">Reconectando</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-red-600">
                {layers.filter(l => l.status === "offline").length}
              </div>
              <div className="text-sm text-muted-foreground">Offline</div>
            </div>
          </div>
          
          {layerHealth?.overall && (
            <div className="mt-4 p-3 bg-muted/30 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm">Saúde Geral do Sistema</span>
                <span className={`font-bold ${healthStatus.color}`}>
                  {Math.round(layerHealth.overall.averageHealthScore)}%
                </span>
              </div>
              <div className="mt-2 text-xs text-muted-foreground">
                Última atualização: {formatTimeAgo(layerHealth.overall.lastUpdate)}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Communications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <i className="fas fa-exchange-alt mr-2 text-chart-2"></i>
            Comunicações Recentes
          </CardTitle>
          <CardDescription>
            Últimas comunicações entre camadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {getRecentCommunications().length === 0 ? (
              <div className="text-center py-4 text-muted-foreground">
                <i className="fas fa-satellite-dish text-2xl mb-2 opacity-50"></i>
                <p>Nenhuma comunicação recente</p>
              </div>
            ) : (
              getRecentCommunications().map((comm: any, index: number) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-1 text-sm">
                      <span className="font-medium">L{comm.sourceLayer}</span>
                      <i className="fas fa-arrow-right text-muted-foreground"></i>
                      <span className="font-medium">L{comm.destinationLayer}</span>
                    </div>
                    <Badge variant={getConnectionBadgeVariant(comm.status)} className="text-xs">
                      {comm.messageType}
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`text-xs ${
                      comm.status === "delivered" ? "text-green-600" : 
                      comm.status === "failed" ? "text-red-600" : "text-yellow-600"
                    }`}>
                      {comm.status === "delivered" ? "✓ Entregue" : 
                       comm.status === "failed" ? "✗ Falhou" : "⏳ Pendente"}
                    </span>
                    {comm.responseTime && (
                      <span className="text-xs text-muted-foreground">
                        {comm.responseTime}ms
                      </span>
                    )}
                    <span className="text-xs text-muted-foreground">
                      {formatTimeAgo(comm.timestamp)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Auto-Reconnect Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <i className="fas fa-redo mr-2 text-green-600"></i>
              Reconexão Automática
            </span>
            <Badge variant="default" className="bg-green-600">
              <i className="fas fa-play mr-1"></i>
              Ativo
            </Badge>
          </CardTitle>
          <CardDescription>
            Sistema de reconexão automática está monitorando as camadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span>Intervalo de verificação:</span>
              <span className="font-medium">30 segundos</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>Última verificação:</span>
              <span className="font-medium">
                {new Date().toLocaleTimeString('pt-BR')}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>Taxa de sucesso:</span>
              <span className="font-medium text-green-600">40%</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}