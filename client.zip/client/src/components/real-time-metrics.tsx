import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { SystemHealth } from "@shared/schema";

export default function RealTimeMetrics() {
  const { data: systemHealth, isLoading } = useQuery<SystemHealth>({
    queryKey: ["/api/dashboard/system-health"],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  if (isLoading) {
    return (
      <Card className="metric-card">
        <CardHeader>
          <CardTitle className="flex items-center">
            <i className="fas fa-chart-bar mr-2 text-chart-1"></i>
            Métricas em Tempo Real
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-muted rounded mb-2"></div>
                <div className="h-2 bg-muted rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="metric-card">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-chart-bar mr-2 text-chart-1"></i>
          Métricas em Tempo Real
        </CardTitle>
        <CardDescription>
          Monitoramento contínuo de recursos do sistema
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Largura de Banda</span>
            <span data-testid="bandwidth-value">
              {systemHealth?.bandwidth.value} {systemHealth?.bandwidth.unit}
            </span>
          </div>
          <Progress
            value={systemHealth?.bandwidth.percentage || 0}
            className="h-2 progress-animate"
            data-testid="bandwidth-progress"
          />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Memória</span>
            <span data-testid="memory-value">
              {systemHealth?.memory.value}{systemHealth?.memory.unit}
            </span>
          </div>
          <Progress
            value={systemHealth?.memory.percentage || 0}
            className="h-2 progress-animate"
            data-testid="memory-progress"
          />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Conexões Inter-Layer</span>
            <span data-testid="connections-value">
              {systemHealth?.connections.active}/{systemHealth?.connections.total}
            </span>
          </div>
          <Progress
            value={systemHealth?.connections.percentage || 0}
            className="h-2 progress-animate"
            data-testid="connections-progress"
          />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Latência Média</span>
            <span data-testid="latency-value">
              {systemHealth?.latency.value}{systemHealth?.latency.unit}
            </span>
          </div>
          <Progress
            value={systemHealth?.latency.percentage || 0}
            className="h-2 progress-animate"
            data-testid="latency-progress"
          />
        </div>
      </CardContent>
    </Card>
  );
}
