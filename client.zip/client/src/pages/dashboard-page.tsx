import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { SystemOverviewCards } from "@/components/dashboard/system-overview-cards";
import { RealTimeIncidents } from "@/components/dashboard/real-time-incidents";
import { RLTrainingMetrics } from "@/components/dashboard/rl-training-metrics";
import { SystemHealth } from "@/components/dashboard/system-health";
import { RecentActions } from "@/components/dashboard/recent-actions";

export default function DashboardPage() {
  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-auto p-6">
          <SystemOverviewCards />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
            <div className="lg:col-span-2">
              <RealTimeIncidents />
            </div>
            <div>
              <RLTrainingMetrics />
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <SystemHealth />
            <RecentActions />
          </div>
        </main>
      </div>
    </div>
  );
}
