import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Brain, Network, Lock, Zap, Eye } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5">
      {/* Navigation */}
      <nav className="border-b border-border bg-background/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Shield className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">AZYRÍS</h1>
                <p className="text-xs text-muted-foreground">Layer 4 Security</p>
              </div>
            </div>
            <Button onClick={handleLogin} data-testid="button-login">
              Secure Login
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Zap className="h-4 w-4" />
              <span>Production Ready • AI-Powered • Real-time Protection</span>
            </div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight">
              AZYRÍS Layer 4
              <span className="block text-primary">Security Core</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
              Advanced cybersecurity platform with reinforcement learning, real-time threat detection, 
              and autonomous incident response. Engineered for production environments with PostgreSQL 
              integration and 9-layer architecture support.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" onClick={handleLogin} className="text-lg px-8" data-testid="button-access-dashboard">
                Access Security Dashboard
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8" data-testid="button-system-status">
                System Status
              </Button>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-20">
            <Card className="bg-card/50 backdrop-blur-sm border-border hover:bg-card/80 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Brain className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>AI Security Engine</CardTitle>
                <CardDescription>
                  TensorFlow-powered reinforcement learning for autonomous threat response with 99.2% accuracy
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• PPO algorithm for optimal decision making</li>
                  <li>• Real-time threat pattern learning</li>
                  <li>• Continuous model improvement</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-card/50 backdrop-blur-sm border-border hover:bg-card/80 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Network className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Inter-Layer Communication</CardTitle>
                <CardDescription>
                  Seamless integration with all 9 AZYRÍS architecture layers for coordinated defense
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Automatic layer discovery and sync</li>
                  <li>• Priority-based message queuing</li>
                  <li>• Fault-tolerant communication</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-card/50 backdrop-blur-sm border-border hover:bg-card/80 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Lock className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Production Database</CardTitle>
                <CardDescription>
                  PostgreSQL with hybrid storage, connection pooling, and automatic failover
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Supabase PostgreSQL integration</li>
                  <li>• In-memory fallback system</li>
                  <li>• Real-time data synchronization</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-card/50 backdrop-blur-sm border-border hover:bg-card/80 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Eye className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Real-time Monitoring</CardTitle>
                <CardDescription>
                  Comprehensive system health monitoring with WebSocket-based live updates
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• System performance metrics</li>
                  <li>• Live threat visualization</li>
                  <li>• Automated health checks</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-card/50 backdrop-blur-sm border-border hover:bg-card/80 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Threat Detection</CardTitle>
                <CardDescription>
                  Advanced pattern matching and heuristic analysis for comprehensive threat identification
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• SQL injection detection</li>
                  <li>• DDoS attack mitigation</li>
                  <li>• Malware C&C identification</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-card/50 backdrop-blur-sm border-border hover:bg-card/80 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Incident Response</CardTitle>
                <CardDescription>
                  Automated response actions with configurable policies and forensic analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Automatic threat blocking</li>
                  <li>• System isolation protocols</li>
                  <li>• Evidence collection</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Background decoration */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-40 -right-32 w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>
          <div className="absolute -bottom-40 -left-32 w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>
        </div>
      </section>

      {/* System Status */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">System Status</h2>
            <p className="text-muted-foreground">Real-time operational status of AZYRÍS Layer 4</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500/10 rounded-full mb-4">
                <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">PostgreSQL</h3>
              <p className="text-green-500 font-medium" data-testid="status-postgresql">Online</p>
              <p className="text-sm text-muted-foreground mt-1">Database operational</p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500/10 rounded-full mb-4">
                <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">ML Engine</h3>
              <p className="text-green-500 font-medium" data-testid="status-ml-engine">Active Learning</p>
              <p className="text-sm text-muted-foreground mt-1">AI models training</p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-yellow-500/10 rounded-full mb-4">
                <div className="w-4 h-4 bg-yellow-500 rounded-full animate-ping"></div>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Layer Sync</h3>
              <p className="text-yellow-500 font-medium" data-testid="status-layer-sync">Syncing</p>
              <p className="text-sm text-muted-foreground mt-1">Connecting to other layers</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-muted-foreground">
              AZYRÍS Layer 4 Security Core • Production Environment • 
              <span className="text-primary ml-1">Fully Operational</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
