import { useQuery, useMutation } from "@tanstack/react-query";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { Play, Pause, RefreshCw, Brain, TrendingUp } from "lucide-react";

export default function RLTrainingPage() {
  const { toast } = useToast();

  const { data: trainingStatus } = useQuery({
    queryKey: ["/api/rl/training/status"],
    queryFn: getQueryFn(),
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: rlMetrics } = useQuery({
    queryKey: ["/api/rl/metrics"],
    queryFn: getQueryFn(),
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const startTrainingMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/rl/training/start"),
    onSuccess: () => {
      toast({
        title: "Training Started",
        description: "RL training has been started successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/rl/training/status"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const stopTrainingMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/rl/training/stop"),
    onSuccess: () => {
      toast({
        title: "Training Stopped",
        description: "RL training has been stopped successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/rl/training/status"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleStartStop = () => {
    if (trainingStatus?.is_training) {
      stopTrainingMutation.mutate();
    } else {
      startTrainingMutation.mutate();
    }
  };

  const getProgressPercentage = () => {
    if (!trainingStatus?.current_episode) return 0;
    return (trainingStatus.current_episode / 1000) * 100;
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-auto p-6">
          <div className="space-y-6">
            {/* Page Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground">RL Training Control</h1>
                <p className="text-muted-foreground">Monitor and control reinforcement learning training</p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => queryClient.invalidateQueries()}
                  variant="outline"
                  size="sm"
                  data-testid="button-refresh"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh
                </Button>
                <Button
                  onClick={handleStartStop}
                  disabled={startTrainingMutation.isPending || stopTrainingMutation.isPending}
                  data-testid="button-start-stop-training"
                >
                  {trainingStatus?.is_training ? (
                    <>
                      <Pause className="w-4 h-4 mr-2" />
                      Stop Training
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Start Training
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Training Status Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Brain className="w-5 h-5 text-primary" />
                    <div>
                      <div className="font-semibold">Status</div>
                      <Badge 
                        variant={trainingStatus?.is_training ? "default" : "secondary"}
                        data-testid="text-training-status"
                      >
                        {trainingStatus?.is_training ? "Training" : "Idle"}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-foreground" data-testid="text-current-episode">
                    {trainingStatus?.current_episode || 0}
                  </div>
                  <p className="text-sm text-muted-foreground">Current Episode</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-green-600" data-testid="text-average-reward">
                    {trainingStatus?.latest_metrics?.averageReward?.toFixed(2) || "0.00"}
                  </div>
                  <p className="text-sm text-muted-foreground">Average Reward</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-blue-600" data-testid="text-policy-loss">
                    {trainingStatus?.latest_metrics?.policyLoss?.toFixed(4) || "0.0000"}
                  </div>
                  <p className="text-sm text-muted-foreground">Policy Loss</p>
                </CardContent>
              </Card>
            </div>

            {/* Training Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5" />
                  <span>Training Progress</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Episode Progress</span>
                      <span data-testid="text-progress-percentage">
                        {trainingStatus?.current_episode || 0}/1000 ({getProgressPercentage().toFixed(1)}%)
                      </span>
                    </div>
                    <Progress value={getProgressPercentage()} className="w-full" />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Learning Rate</label>
                      <div className="text-lg font-semibold" data-testid="text-learning-rate">
                        {trainingStatus?.latest_metrics?.learningRate || "3e-4"}
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Epsilon</label>
                      <div className="text-lg font-semibold" data-testid="text-epsilon">
                        {trainingStatus?.latest_metrics?.epsilon?.toFixed(3) || "0.500"}
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Entropy</label>
                      <div className="text-lg font-semibold" data-testid="text-entropy">
                        {trainingStatus?.latest_metrics?.entropy?.toFixed(3) || "0.100"}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Distribution */}
            {rlMetrics?.action_distribution && (
              <Card>
                <CardHeader>
                  <CardTitle>Action Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {Object.entries(rlMetrics.action_distribution).map(([action, percentage]) => (
                      <div key={action} className="text-center">
                        <div className="text-2xl font-bold text-primary">
                          {((percentage as number) * 100).toFixed(1)}%
                        </div>
                        <div className="text-sm text-muted-foreground capitalize">
                          {action}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Training History */}
            {trainingStatus?.training_history && trainingStatus.training_history.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Recent Training History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {trainingStatus.training_history.slice(0, 10).map((metric: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div>
                          <span className="font-medium">Episode {metric.episode}</span>
                          <span className="text-muted-foreground text-sm ml-2">
                            {new Date(metric.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex items-center space-x-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Reward:</span>
                            <span className="font-medium ml-1">{metric.averageReward?.toFixed(2)}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Loss:</span>
                            <span className="font-medium ml-1">{metric.policyLoss?.toFixed(4)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
