import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { SystemSetting } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function SettingsPage() {
  const [isDirty, setIsDirty] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery<SystemSetting[]>({
    queryKey: ["/api/settings"],
  });

  const updateSettingMutation = useMutation({
    mutationFn: (setting: { settingKey: string; settingValue: string; description?: string }) =>
      apiRequest("/api/settings", {
        method: "POST",
        body: setting,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      setIsDirty(false);
      toast({
        title: "Configurações salvas",
        description: "As configurações foram atualizadas com sucesso.",
      });
    },
    onError: () => {
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações.",
        variant: "destructive",
      });
    },
  });

  const getSettingValue = (key: string): boolean => {
    const setting = settings?.find(s => s.settingKey === key);
    return setting?.settingValue === "true";
  };

  const handleToggleSetting = (key: string, description: string) => {
    const currentValue = getSettingValue(key);
    updateSettingMutation.mutate({
      settingKey: key,
      settingValue: (!currentValue).toString(),
      description,
    });
    setIsDirty(true);
  };

  return (
    <>
      {/* Header */}
      <header className="bg-card border-b border-border p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground flex items-center">
              <i className="fas fa-sliders-h mr-3 text-primary"></i>
              Configurações do Sistema
            </h2>
            <p className="text-muted-foreground">Configuração e personalização do AZYRÍS Layer 4</p>
          </div>
          {isDirty && (
            <div className="flex items-center space-x-2 text-sm text-chart-3">
              <i className="fas fa-exclamation-circle"></i>
              <span>Alterações não salvas</span>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto bg-muted/10">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-muted-foreground">Carregando configurações...</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* System Settings */}
            <div className="space-y-6">
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-cogs mr-2 text-chart-2"></i>
                    Configurações Operacionais
                  </CardTitle>
                  <CardDescription>
                    Controles principais de funcionamento do sistema
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Sincronização Automática</Label>
                      <p className="text-sm text-muted-foreground">
                        Sincronização automática com outras camadas
                      </p>
                    </div>
                    <Switch
                      checked={getSettingValue("auto_sync_enabled")}
                      onCheckedChange={() => handleToggleSetting("auto_sync_enabled", "Auto-sync with other layers")}
                      data-testid="switch-auto-sync"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Detecção de Ameaças</Label>
                      <p className="text-sm text-muted-foreground">
                        Sistema ativo de detecção de ameaças
                      </p>
                    </div>
                    <Switch
                      checked={getSettingValue("threat_detection_enabled")}
                      onCheckedChange={() => handleToggleSetting("threat_detection_enabled", "Active threat detection")}
                      data-testid="switch-threat-detection"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Notificações de Alerta</Label>
                      <p className="text-sm text-muted-foreground">
                        Notificações em tempo real de alertas
                      </p>
                    </div>
                    <Switch
                      checked={getSettingValue("alert_notifications_enabled")}
                      onCheckedChange={() => handleToggleSetting("alert_notifications_enabled", "Real-time alert notifications")}
                      data-testid="switch-notifications"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-network-wired mr-2 text-chart-3"></i>
                    Configurações de Rede
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="api-timeout">Timeout de API (segundos)</Label>
                    <Input
                      id="api-timeout"
                      type="number"
                      defaultValue="30"
                      className="mt-1"
                      data-testid="input-api-timeout"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="max-connections">Máximo de Conexões</Label>
                    <Input
                      id="max-connections"
                      type="number"
                      defaultValue="300"
                      className="mt-1"
                      data-testid="input-max-connections"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="retry-attempts">Tentativas de Reconexão</Label>
                    <Input
                      id="retry-attempts"
                      type="number"
                      defaultValue="3"
                      className="mt-1"
                      data-testid="input-retry-attempts"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Security & Logging */}
            <div className="space-y-6">
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-shield-alt mr-2 text-destructive"></i>
                    Configurações de Segurança
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="session-timeout">Timeout de Sessão (minutos)</Label>
                    <Input
                      id="session-timeout"
                      type="number"
                      defaultValue="60"
                      className="mt-1"
                      data-testid="input-session-timeout"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="max-login-attempts">Máximo de Tentativas de Login</Label>
                    <Input
                      id="max-login-attempts"
                      type="number"
                      defaultValue="5"
                      className="mt-1"
                      data-testid="input-max-login-attempts"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="encryption-key">Chave de Criptografia</Label>
                    <Input
                      id="encryption-key"
                      type="password"
                      placeholder="••••••••••••••••"
                      className="mt-1"
                      data-testid="input-encryption-key"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-file-alt mr-2 text-chart-1"></i>
                    Configurações de Log
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="log-level">Nível de Log</Label>
                    <select
                      id="log-level"
                      className="w-full mt-1 bg-input border border-border rounded-md px-3 py-2 text-sm"
                      defaultValue="info"
                      data-testid="select-log-level"
                    >
                      <option value="debug">Debug</option>
                      <option value="info">Info</option>
                      <option value="warning">Warning</option>
                      <option value="error">Error</option>
                    </select>
                  </div>
                  
                  <div>
                    <Label htmlFor="log-retention">Retenção de Logs (dias)</Label>
                    <Input
                      id="log-retention"
                      type="number"
                      defaultValue="30"
                      className="mt-1"
                      data-testid="input-log-retention"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="max-log-size">Tamanho Máximo de Arquivo (MB)</Label>
                    <Input
                      id="max-log-size"
                      type="number"
                      defaultValue="100"
                      className="mt-1"
                      data-testid="input-max-log-size"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-database mr-2 text-chart-4"></i>
                    Backup e Recuperação
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Backup Automático</p>
                      <p className="text-xs text-muted-foreground">Backup diário às 03:00</p>
                    </div>
                    <Switch defaultChecked data-testid="switch-auto-backup" />
                  </div>
                  
                  <div>
                    <Label htmlFor="backup-retention">Retenção de Backups (dias)</Label>
                    <Input
                      id="backup-retention"
                      type="number"
                      defaultValue="7"
                      className="mt-1"
                      data-testid="input-backup-retention"
                    />
                  </div>
                  
                  <Button variant="outline" className="w-full" data-testid="button-manual-backup">
                    <i className="fas fa-save mr-2"></i>
                    Executar Backup Manual
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </main>
    </>
  );
}
