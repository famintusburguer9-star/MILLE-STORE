import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'warning' | 'error' | 'debug';
  source: string;
  message: string;
  layerId?: number;
  metadata?: any;
}

export default function LogsPage() {
  const [filter, setFilter] = useState<string>("all");
  const [search, setSearch] = useState<string>("");
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Mock log data - in real implementation this would come from the backend
  const mockLogs: LogEntry[] = [
    {
      id: "1",
      timestamp: new Date().toISOString(),
      level: "info",
      source: "layer-communication",
      message: "Sincronização bem-sucedida com Layer 3",
      layerId: 3,
    },
    {
      id: "2",
      timestamp: new Date(Date.now() - 300000).toISOString(),
      level: "warning",
      source: "threat-detection",
      message: "Tentativa de acesso suspeita detectada",
    },
    {
      id: "3",
      timestamp: new Date(Date.now() - 600000).toISOString(),
      level: "error",
      source: "layer-communication",
      message: "Falha na conexão com Layer 8",
      layerId: 8,
    },
    {
      id: "4",
      timestamp: new Date(Date.now() - 900000).toISOString(),
      level: "info",
      source: "system-monitor",
      message: "Backup automático concluído",
    },
    {
      id: "5",
      timestamp: new Date(Date.now() - 1200000).toISOString(),
      level: "debug",
      source: "auth-service",
      message: "Login realizado: user admin",
    },
  ];

  const filteredLogs = mockLogs.filter((log) => {
    const matchesFilter = filter === "all" || log.level === filter;
    const matchesSearch = log.message.toLowerCase().includes(search.toLowerCase()) ||
                         log.source.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getLevelColor = (level: string) => {
    switch (level) {
      case "error":
        return "destructive";
      case "warning":
        return "default";
      case "info":
        return "secondary";
      case "debug":
        return "outline";
      default:
        return "outline";
    }
  };

  const getLevelIcon = (level: string) => {
    switch (level) {
      case "error":
        return "fas fa-times-circle";
      case "warning":
        return "fas fa-exclamation-triangle";
      case "info":
        return "fas fa-info-circle";
      case "debug":
        return "fas fa-bug";
      default:
        return "fas fa-circle";
    }
  };

  return (
    <>
      {/* Header */}
      <header className="bg-card border-b border-border p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground flex items-center">
              <i className="fas fa-list mr-3 text-chart-1"></i>
              Registros do Sistema
            </h2>
            <p className="text-muted-foreground">Monitoramento de logs e eventos do AZYRÍS Layer 4</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant={autoRefresh ? "default" : "outline"}
              size="sm"
              onClick={() => setAutoRefresh(!autoRefresh)}
              data-testid="button-auto-refresh"
            >
              <i className={`fas fa-sync-alt mr-2 ${autoRefresh ? 'animate-spin' : ''}`}></i>
              Auto-refresh
            </Button>
            <Button variant="outline" size="sm" data-testid="button-export-logs">
              <i className="fas fa-download mr-2"></i>
              Exportar
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto bg-muted/10">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <Input
            placeholder="Buscar nos registros..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="sm:max-w-sm"
            data-testid="input-search-logs"
          />
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="sm:w-48" data-testid="select-filter-level">
              <SelectValue placeholder="Filtrar por nível..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os níveis</SelectItem>
              <SelectItem value="error">Erros</SelectItem>
              <SelectItem value="warning">Avisos</SelectItem>
              <SelectItem value="info">Informações</SelectItem>
              <SelectItem value="debug">Debug</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Log Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="metric-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-destructive/20 rounded-lg flex items-center justify-center mr-3">
                  <i className="fas fa-times-circle text-destructive"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Erros</p>
                  <p className="text-2xl font-bold" data-testid="stat-errors">
                    {mockLogs.filter(l => l.level === "error").length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="metric-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-chart-3/20 rounded-lg flex items-center justify-center mr-3">
                  <i className="fas fa-exclamation-triangle text-chart-3"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avisos</p>
                  <p className="text-2xl font-bold" data-testid="stat-warnings">
                    {mockLogs.filter(l => l.level === "warning").length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="metric-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-chart-2/20 rounded-lg flex items-center justify-center mr-3">
                  <i className="fas fa-info-circle text-chart-2"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Info</p>
                  <p className="text-2xl font-bold" data-testid="stat-info">
                    {mockLogs.filter(l => l.level === "info").length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="metric-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center mr-3">
                  <i className="fas fa-bug text-primary"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Debug</p>
                  <p className="text-2xl font-bold" data-testid="stat-debug">
                    {mockLogs.filter(l => l.level === "debug").length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Logs List */}
        <Card className="metric-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-stream mr-2 text-chart-1"></i>
              Log Stream
            </CardTitle>
            <CardDescription>
              Registros em tempo real do sistema ({filteredLogs.length} entradas)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96 w-full" data-testid="logs-container">
              <div className="space-y-2">
                {filteredLogs.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <i className="fas fa-search text-2xl mb-2"></i>
                    <p>Nenhum registro encontrado</p>
                  </div>
                ) : (
                  filteredLogs.map((log) => (
                    <div 
                      key={log.id} 
                      className="flex items-start space-x-3 p-3 bg-muted rounded-lg hover:bg-muted/80 transition-colors"
                      data-testid={`log-entry-${log.id}`}
                    >
                      <div className="flex-shrink-0 mt-1">
                        <i className={`${getLevelIcon(log.level)} text-sm`}></i>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant={getLevelColor(log.level)} className="text-xs">
                            {log.level.toUpperCase()}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {log.source}
                          </span>
                          {log.layerId && (
                            <span className="text-xs text-muted-foreground">
                              Layer {log.layerId}
                            </span>
                          )}
                          <span className="text-xs text-muted-foreground ml-auto">
                            {new Date(log.timestamp).toLocaleString('pt-BR')}
                          </span>
                        </div>
                        <p className="text-sm text-foreground break-words">
                          {log.message}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </main>
    </>
  );
}
