import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { Incident } from "@shared/schema";
import { Eye, Check, AlertTriangle, Loader2, RefreshCw } from "lucide-react";

export default function IncidentsPage() {
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState({
    category: "",
    severity_min: "",
    severity_max: "",
    processed: "",
  });
  const { toast } = useToast();

  const { data: incidentsData, isLoading, error } = useQuery({
    queryKey: ["/api/incidents", page, filters],
    queryFn: getQueryFn(),
  });

  const { data: statistics } = useQuery({
    queryKey: ["/api/incidents/statistics"],
    queryFn: getQueryFn(),
  });

  const markProcessedMutation = useMutation({
    mutationFn: async (incidentIds: string[]) => {
      return apiRequest("POST", "/api/incidents/bulk-action", {
        incident_ids: incidentIds,
        action: "mark_processed"
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Incidents marked as processed",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/incidents/statistics"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getSeverityColor = (severity: number) => {
    if (severity >= 9) return "bg-red-500";
    if (severity >= 7) return "bg-orange-500";
    if (severity >= 5) return "bg-yellow-500";
    if (severity >= 3) return "bg-blue-500";
    return "bg-green-500";
  };

  const formatTimestamp = (timestamp: string | null) => {
    if (!timestamp) return "N/A";
    return new Date(timestamp).toLocaleString();
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
    queryClient.invalidateQueries({ queryKey: ["/api/incidents/statistics"] });
  };

  const applyFilters = () => {
    setPage(1);
    queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-auto p-6">
          <div className="space-y-6">
            {/* Page Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Security Incidents</h1>
                <p className="text-muted-foreground">Monitor and manage security incidents</p>
              </div>
              <Button onClick={handleRefresh} size="sm" data-testid="button-refresh">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>

            {/* Statistics Cards */}
            {statistics && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-foreground" data-testid="text-total-incidents">
                      {statistics.total_incidents}
                    </div>
                    <p className="text-sm text-muted-foreground">Total Incidents</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-green-600" data-testid="text-processed-incidents">
                      {statistics.processed_incidents}
                    </div>
                    <p className="text-sm text-muted-foreground">Processed</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-orange-500" data-testid="text-pending-incidents">
                      {statistics.total_incidents - statistics.processed_incidents}
                    </div>
                    <p className="text-sm text-muted-foreground">Pending</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-2xl font-bold text-red-500" data-testid="text-critical-incidents">
                      {Object.entries(statistics.severity_distribution || {})
                        .filter(([severity]) => parseInt(severity) >= 8)
                        .reduce((sum, [, count]) => sum + count, 0)}
                    </div>
                    <p className="text-sm text-muted-foreground">Critical</p>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle>Filters</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="text-sm font-medium">Category</label>
                    <Select
                      value={filters.category}
                      onValueChange={(value) => setFilters({...filters, category: value})}
                    >
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder="All Categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Categories</SelectItem>
                        <SelectItem value="malware">Malware</SelectItem>
                        <SelectItem value="intrusion">Intrusion</SelectItem>
                        <SelectItem value="ddos">DDoS</SelectItem>
                        <SelectItem value="phishing">Phishing</SelectItem>
                        <SelectItem value="vulnerability">Vulnerability</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Min Severity</label>
                    <Input
                      type="number"
                      placeholder="0"
                      min="0"
                      max="10"
                      value={filters.severity_min}
                      onChange={(e) => setFilters({...filters, severity_min: e.target.value})}
                      data-testid="input-severity-min"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Max Severity</label>
                    <Input
                      type="number"
                      placeholder="10"
                      min="0"
                      max="10"
                      value={filters.severity_max}
                      onChange={(e) => setFilters({...filters, severity_max: e.target.value})}
                      data-testid="input-severity-max"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Status</label>
                    <Select
                      value={filters.processed}
                      onValueChange={(value) => setFilters({...filters, processed: value})}
                    >
                      <SelectTrigger data-testid="select-status">
                        <SelectValue placeholder="All Statuses" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Statuses</SelectItem>
                        <SelectItem value="true">Processed</SelectItem>
                        <SelectItem value="false">Pending</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="mt-4">
                  <Button onClick={applyFilters} data-testid="button-apply-filters">
                    Apply Filters
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Incidents Table */}
            <Card>
              <CardHeader>
                <CardTitle>Incidents</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin" />
                    <span className="ml-2">Loading incidents...</span>
                  </div>
                ) : error ? (
                  <div className="flex items-center justify-center py-8 text-destructive">
                    <AlertTriangle className="w-6 h-6 mr-2" />
                    <span>Error loading incidents</span>
                  </div>
                ) : !incidentsData?.incidents?.length ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No incidents found
                  </div>
                ) : (
                  <div className="space-y-4">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Timestamp</TableHead>
                          <TableHead>Source IP</TableHead>
                          <TableHead>Destination IP</TableHead>
                          <TableHead>Protocol</TableHead>
                          <TableHead>Severity</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Action</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {incidentsData.incidents.map((incident: Incident) => (
                          <TableRow key={incident.id}>
                            <TableCell className="text-sm">
                              {formatTimestamp(incident.timestamp)}
                            </TableCell>
                            <TableCell>
                              <code className="text-sm bg-muted px-1 rounded">
                                {incident.sourceIp || "N/A"}
                              </code>
                            </TableCell>
                            <TableCell>
                              <code className="text-sm bg-muted px-1 rounded">
                                {incident.destinationIp || "N/A"}
                              </code>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="text-xs">
                                {incident.protocol || "N/A"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge className={`${getSeverityColor(incident.severity)} text-white text-xs`}>
                                {incident.severity}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs">
                                {incident.category}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {incident.actionTaken ? (
                                <Badge className="text-xs">
                                  {incident.actionTaken}
                                </Badge>
                              ) : (
                                <span className="text-muted-foreground text-xs">None</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <Badge variant={incident.processed ? "default" : "secondary"} className="text-xs">
                                {incident.processed ? "Processed" : "Pending"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center space-x-2">
                                <Button size="sm" variant="ghost" data-testid={`button-view-${incident.id}`}>
                                  <Eye className="w-4 h-4" />
                                </Button>
                                {!incident.processed && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => markProcessedMutation.mutate([incident.id])}
                                    disabled={markProcessedMutation.isPending}
                                    data-testid={`button-mark-processed-${incident.id}`}
                                  >
                                    <Check className="w-4 h-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>

                    {/* Pagination */}
                    {incidentsData.pagination && incidentsData.pagination.pages > 1 && (
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-muted-foreground">
                          Showing {((page - 1) * 20) + 1} to {Math.min(page * 20, incidentsData.pagination.total)} of {incidentsData.pagination.total} incidents
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setPage(page - 1)}
                            disabled={page === 1}
                            data-testid="button-prev-page"
                          >
                            Previous
                          </Button>
                          <span className="text-sm">
                            Page {page} of {incidentsData.pagination.pages}
                          </span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setPage(page + 1)}
                            disabled={page === incidentsData.pagination.pages}
                            data-testid="button-next-page"
                          >
                            Next
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
