import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Shield, Cpu, Brain, AlertTriangle, Activity, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import LayerMatrix from "@/components/layer-matrix";
import RLDashboard from "@/components/rl-dashboard";
import DecisionLogs from "@/components/decision-logs";
import PerformanceMetrics from "@/components/performance-metrics";
import ErrorResolution from "@/components/error-resolution";
import { SSEManager } from "@/lib/websocket";
import { DashboardData, LayerStatus, SystemPerformance } from "@/lib/types";

export default function Dashboard() {
  const [realTimeData, setRealTimeData] = useState<DashboardData | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  // Initialize SSE for real-time updates
  useEffect(() => {
    const sseManager = new SSEManager('/api/stream/dashboard');
    
    const unsubscribe = sseManager.subscribe((data: DashboardData) => {
      setRealTimeData(data);
      setIsConnected(true);
    });

    sseManager.connect();

    return () => {
      unsubscribe();
      sseManager.disconnect();
    };
  }, []);

  // Fetch static data
  const { data: systemPerformance } = useQuery({
    queryKey: ['/api/system/performance'],
    refetchInterval: 30000 // Refetch every 30 seconds as backup
  });

  const { data: layerStatuses } = useQuery({
    queryKey: ['/api/layer-status'],
    refetchInterval: 10000
  });

  const currentPerformance = realTimeData?.systemPerformance || systemPerformance;
  const currentLayerStatuses = realTimeData?.layerStatuses || layerStatuses || [];

  const getSystemHealthStatus = (): { status: string; color: string } => {
    const onlineLayers = currentLayerStatuses.filter(layer => layer.status === 'online').length;
    const totalLayers = currentLayerStatuses.length;
    const healthPercentage = totalLayers > 0 ? (onlineLayers / totalLayers) * 100 : 0;

    if (healthPercentage >= 90) return { status: 'Optimal', color: 'text-green-500' };
    if (healthPercentage >= 70) return { status: 'Good', color: 'text-yellow-500' };
    if (healthPercentage >= 50) return { status: 'Warning', color: 'text-orange-500' };
    return { status: 'Critical', color: 'text-red-500' };
  };

  const systemHealth = getSystemHealthStatus();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Shield className="text-primary text-2xl" data-testid="icon-shield" />
              <h1 className="text-xl font-bold" data-testid="title-header">AI Security Layer</h1>
            </div>
            <Separator orientation="vertical" className="h-6" />
            <div className="flex items-center space-x-2">
              <div className={`status-indicator ${isConnected ? 'status-healthy' : 'status-error'}`} data-testid="indicator-rl-status"></div>
              <span className="text-sm text-muted-foreground" data-testid="text-rl-status">
                RL System {isConnected ? 'Online' : 'Offline'}
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm">
              <Cpu className="text-primary" data-testid="icon-cpu" />
              <span data-testid="text-meta-learning">Meta-Learning: Active</span>
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <Brain className="text-secondary" data-testid="icon-brain" />
              <span data-testid="text-decisions-rate">
                Decisions/min: {currentPerformance?.threatDetectionRate || 847}
              </span>
            </div>
            <Button 
              className="bg-accent text-accent-foreground hover:bg-accent/80"
              data-testid="button-manual-override"
            >
              <AlertTriangle className="mr-2 h-4 w-4" />
              Manual Override
            </Button>
          </div>
        </div>
      </header>

      <div className="flex h-screen">
        {/* Sidebar */}
        <aside className="w-64 bg-card border-r border-border p-4 overflow-y-auto scrollbar-thin">
          <nav className="space-y-2">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-4">
              Sistema Principal
            </div>
            
            <Button 
              variant="default" 
              className="w-full justify-start space-x-3"
              data-testid="nav-dashboard"
            >
              <Activity className="h-4 w-4" />
              <span>Dashboard</span>
            </Button>
            
            <Button 
              variant="ghost" 
              className="w-full justify-start space-x-3"
              data-testid="nav-layer-monitor"
            >
              <Shield className="h-4 w-4" />
              <span>Layer Monitor</span>
            </Button>
            
            <Button 
              variant="ghost" 
              className="w-full justify-start space-x-3"
              data-testid="nav-rl-decisions"
            >
              <Brain className="h-4 w-4" />
              <span>RL Decisions</span>
            </Button>
            
            <Button 
              variant="ghost" 
              className="w-full justify-start space-x-3"
              data-testid="nav-meta-learning"
            >
              <Cpu className="h-4 w-4" />
              <span>Meta-Learning</span>
            </Button>

            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mt-6 mb-4">
              Status Rápido
            </div>
            
            <Card className="bg-muted">
              <CardContent className="p-3">
                <div className="text-xs text-muted-foreground">System Health</div>
                <div className={`font-mono text-sm ${systemHealth.color}`} data-testid="text-system-health">
                  {systemHealth.status}
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-muted">
              <CardContent className="p-3">
                <div className="text-xs text-muted-foreground">Threats Blocked</div>
                <div className="font-mono text-sm text-destructive" data-testid="text-threats-blocked">
                  1,247
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-muted">
              <CardContent className="p-3">
                <div className="text-xs text-muted-foreground">Learning Rate</div>
                <div className="font-mono text-sm text-secondary" data-testid="text-learning-rate">
                  0.001
                </div>
              </CardContent>
            </Card>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 overflow-y-auto scrollbar-thin">
          {/* Error Resolution Section */}
          <ErrorResolution />

          {/* Layer Connection Matrix */}
          <LayerMatrix layerStatuses={currentLayerStatuses} />

          {/* Main Dashboard Grid */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
            {/* RL Decision Engine */}
            <div className="xl:col-span-2">
              <RLDashboard />
            </div>
            
            {/* Meta-Learning Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="text-secondary mr-2" />
                  Meta-Learning
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Card className="bg-muted">
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground">MAML Adaptation</div>
                    <div className="text-xl font-bold text-secondary" data-testid="text-maml-adaptation">97.3%</div>
                    <Progress value={97.3} className="mt-2" />
                  </CardContent>
                </Card>
                
                <Card className="bg-muted">
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground">Pattern Recognition</div>
                    <div className="text-xl font-bold text-primary" data-testid="text-pattern-recognition">847</div>
                    <div className="text-xs text-muted-foreground">New patterns learned today</div>
                  </CardContent>
                </Card>
                
                <Card className="bg-muted">
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground">Threat Adaptation</div>
                    <div className="text-xl font-bold text-accent" data-testid="text-threat-adaptation">23</div>
                    <div className="text-xs text-muted-foreground">New threat types adapted</div>
                  </CardContent>
                </Card>
                
                <Card className="bg-muted">
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-2">Learning Progress</div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span>DDoS Detection</span>
                        <span>95%</span>
                      </div>
                      <Progress value={95} className="h-1" />
                      <div className="flex justify-between text-xs">
                        <span>Malware Analysis</span>
                        <span>89%</span>
                      </div>
                      <Progress value={89} className="h-1" />
                      <div className="flex justify-between text-xs">
                        <span>Social Engineering</span>
                        <span>76%</span>
                      </div>
                      <Progress value={76} className="h-1" />
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </div>
          
          {/* Performance Metrics and Logs */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <PerformanceMetrics performance={currentPerformance} />
            <DecisionLogs />
          </div>
        </main>
      </div>

      {/* Real-time Connection Status */}
      {realTimeData && (
        <div className="fixed bottom-4 right-4 z-50">
          <Card className="bg-secondary text-secondary-foreground">
            <CardContent className="p-3 flex items-center space-x-3">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse-slow"></div>
              <div className="text-sm">
                <div className="font-medium">Real-time Updates</div>
                <div className="text-xs opacity-90">
                  Last update: {new Date(realTimeData.timestamp).toLocaleTimeString()}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
