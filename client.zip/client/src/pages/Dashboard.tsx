import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useRealTimeData } from "@/hooks/useRealTimeData";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import MetricsGrid from "@/components/dashboard/MetricsGrid";
import ThreatMap from "@/components/dashboard/ThreatMap";
import LayerStatus from "@/components/dashboard/LayerStatus";
import SecurityLogs from "@/components/dashboard/SecurityLogs";
import MLEngineStatus from "@/components/dashboard/MLEngineStatus";
import DatabaseStatus from "@/components/dashboard/DatabaseStatus";

export default function Dashboard() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const { data: realTimeData, isConnected } = useRealTimeData();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Initializing AZYRÍS Layer 4...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen flex bg-background" data-testid="dashboard-main">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <Header isConnected={isConnected} />
        
        {/* Dashboard Content */}
        <div className="flex-1 p-6 overflow-auto" data-testid="dashboard-content">
          
          {/* Metrics Grid */}
          <div className="mb-8" data-testid="metrics-section">
            <MetricsGrid data={realTimeData} />
          </div>
          
          {/* Main Dashboard Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Threat Map */}
            <div className="lg:col-span-2" data-testid="threat-map-section">
              <ThreatMap />
            </div>
            
            {/* Layer Status */}
            <div data-testid="layer-status-section">
              <LayerStatus data={realTimeData} />
            </div>
          </div>
          
          {/* Secondary Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Security Logs */}
            <div data-testid="security-logs-section">
              <SecurityLogs data={realTimeData} />
            </div>
            
            {/* ML Engine Status */}
            <div data-testid="ml-engine-section">
              <MLEngineStatus data={realTimeData} />
            </div>
          </div>
          
          {/* Database Status */}
          <div data-testid="database-status-section">
            <DatabaseStatus />
          </div>
          
        </div>
      </main>
      
      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col space-y-3" data-testid="floating-actions">
        <button 
          className="w-12 h-12 bg-primary text-primary-foreground rounded-full shadow-lg hover:bg-primary/90 transition-colors flex items-center justify-center" 
          title="Emergency Stop"
          data-testid="button-emergency-stop"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
        <button 
          className="w-12 h-12 bg-destructive text-destructive-foreground rounded-full shadow-lg hover:bg-destructive/90 transition-colors flex items-center justify-center" 
          title="Alert Management"
          data-testid="button-alert-management"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-5-5.5V5a1 1 0 00-1-1H10a1 1 0 00-1 1v6.5L4 17h11z" />
          </svg>
        </button>
        <button 
          className="w-12 h-12 bg-green-600 text-white rounded-full shadow-lg hover:bg-green-700 transition-colors flex items-center justify-center" 
          title="System Health Check"
          data-testid="button-health-check"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.8 11.2L8 14.4l8.2-8.2" />
          </svg>
        </button>
      </div>
    </div>
  );
}
