import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { SystemMetric, SystemHealth } from "@shared/schema";

export default function MetricsPage() {
  const { data: metrics, isLoading: metricsLoading } = useQuery<SystemMetric[]>({
    queryKey: ["/api/metrics"],
  });

  const { data: systemHealth, isLoading: healthLoading } = useQuery<SystemHealth>({
    queryKey: ["/api/dashboard/system-health"],
  });

  const isLoading = metricsLoading || healthLoading;

  const getMetricValue = (metricName: string) => {
    const metric = metrics?.find(m => m.metricName === metricName);
    return metric?.metricValue || "0";
  };

  return (
    <>
      {/* Header */}
      <header className="bg-card border-b border-border p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground flex items-center">
              <i className="fas fa-chart-line mr-3 text-chart-1"></i>
              Métricas do Sistema
            </h2>
            <p className="text-muted-foreground">Monitoramento em tempo real do desempenho e saúde do sistema</p>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <span className="status-indicator status-online">Sistema Monitorado</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto bg-muted/10">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-muted-foreground">Carregando métricas...</p>
            </div>
          </div>
        ) : (
          <>
            {/* System Health Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card className="metric-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <i className="fas fa-tachometer-alt mr-2 text-chart-1"></i>
                    Largura de Banda
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold mb-2" data-testid="metric-bandwidth">
                    {systemHealth?.bandwidth.value} {systemHealth?.bandwidth.unit}
                  </div>
                  <Progress value={systemHealth?.bandwidth.percentage || 0} className="h-2 mb-2" />
                  <p className="text-xs text-muted-foreground">
                    {systemHealth?.bandwidth.percentage}% de utilização
                  </p>
                </CardContent>
              </Card>

              <Card className="metric-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <i className="fas fa-memory mr-2 text-chart-2"></i>
                    Memória
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold mb-2" data-testid="metric-memory">
                    {systemHealth?.memory.value}{systemHealth?.memory.unit}
                  </div>
                  <Progress value={systemHealth?.memory.percentage || 0} className="h-2 mb-2" />
                  <p className="text-xs text-muted-foreground">
                    {systemHealth?.memory.percentage}% em uso
                  </p>
                </CardContent>
              </Card>

              <Card className="metric-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <i className="fas fa-network-wired mr-2 text-chart-3"></i>
                    Conexões
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold mb-2" data-testid="metric-connections">
                    {systemHealth?.connections.active}/{systemHealth?.connections.total}
                  </div>
                  <Progress value={systemHealth?.connections.percentage || 0} className="h-2 mb-2" />
                  <p className="text-xs text-muted-foreground">
                    {systemHealth?.connections.percentage}% de capacidade
                  </p>
                </CardContent>
              </Card>

              <Card className="metric-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <i className="fas fa-clock mr-2 text-chart-4"></i>
                    Latência
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold mb-2" data-testid="metric-latency">
                    {systemHealth?.latency.value}{systemHealth?.latency.unit}
                  </div>
                  <Progress value={systemHealth?.latency.percentage || 0} className="h-2 mb-2" />
                  <p className="text-xs text-muted-foreground">
                    Excelente desempenho
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Detailed Metrics */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              {/* Security Metrics */}
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-shield-alt mr-2 text-destructive"></i>
                    Métricas de Segurança
                  </CardTitle>
                  <CardDescription>
                    Estatísticas de detecção e prevenção de ameaças
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Ameaças Detectadas</span>
                    <span className="text-lg font-bold text-destructive" data-testid="threats-detected">
                      {getMetricValue("threats_detected")}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Tentativas Bloqueadas</span>
                    <span className="text-lg font-bold text-chart-2">324</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">False Positives</span>
                    <span className="text-lg font-bold text-chart-3">12</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Taxa de Detecção</span>
                    <span className="text-lg font-bold text-chart-1">97.8%</span>
                  </div>
                </CardContent>
              </Card>

              {/* Performance Metrics */}
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-microchip mr-2 text-primary"></i>
                    Métricas de Performance
                  </CardTitle>
                  <CardDescription>
                    Monitoramento de recursos do sistema
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">CPU Usage</span>
                      <span className="text-sm font-bold" data-testid="cpu-usage">
                        {getMetricValue("cpu_usage")}%
                      </span>
                    </div>
                    <Progress value={parseInt(getMetricValue("cpu_usage"))} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">Disk I/O</span>
                      <span className="text-sm font-bold">23%</span>
                    </div>
                    <Progress value={23} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">Network Usage</span>
                      <span className="text-sm font-bold">45%</span>
                    </div>
                    <Progress value={45} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">Process Count</span>
                      <span className="text-sm font-bold">342</span>
                    </div>
                    <Progress value={68} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Layer Communication Metrics */}
            <Card className="metric-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-layer-group mr-2 text-chart-2"></i>
                  Métricas de Comunicação Entre Camadas
                </CardTitle>
                <CardDescription>
                  Status e estatísticas de comunicação inter-camadas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                      Mensagens Enviadas
                    </h4>
                    <div className="space-y-2">
                      {[1, 2, 3, 5, 6, 7].map(layerId => (
                        <div key={layerId} className="flex items-center justify-between text-sm">
                          <span>Layer {layerId}</span>
                          <span className="font-medium">{Math.floor(Math.random() * 100) + 20}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                      Mensagens Recebidas
                    </h4>
                    <div className="space-y-2">
                      {[1, 2, 3, 5, 6, 7].map(layerId => (
                        <div key={layerId} className="flex items-center justify-between text-sm">
                          <span>Layer {layerId}</span>
                          <span className="font-medium">{Math.floor(Math.random() * 100) + 15}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                      Latência Média (ms)
                    </h4>
                    <div className="space-y-2">
                      {[1, 2, 3, 5, 6, 7].map(layerId => (
                        <div key={layerId} className="flex items-center justify-between text-sm">
                          <span>Layer {layerId}</span>
                          <span className="font-medium">{Math.floor(Math.random() * 20) + 5}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </>
  );
}
