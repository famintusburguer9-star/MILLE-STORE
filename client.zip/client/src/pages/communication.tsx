import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Message, LayerStatus, InsertMessage } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function CommunicationPage() {
  const [newMessage, setNewMessage] = useState("");
  const [targetLayer, setTargetLayer] = useState<string>("");
  const [messageType, setMessageType] = useState<string>("info");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: messages, isLoading: messagesLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
  });

  const { data: layerStatuses, isLoading: layersLoading } = useQuery<LayerStatus[]>({
    queryKey: ["/api/layers/status"],
  });

  const sendMessageMutation = useMutation({
    mutationFn: (messageData: InsertMessage) =>
      apiRequest("/api/messages", {
        method: "POST",
        body: messageData,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      setNewMessage("");
      setTargetLayer("");
      toast({
        title: "Mensagem enviada",
        description: "Mensagem enviada com sucesso para a camada selecionada.",
      });
    },
    onError: () => {
      toast({
        title: "Erro ao enviar mensagem",
        description: "Não foi possível enviar a mensagem. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!newMessage.trim() || !targetLayer) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha a mensagem e selecione uma camada de destino.",
        variant: "destructive",
      });
      return;
    }

    sendMessageMutation.mutate({
      fromLayer: 4,
      toLayer: parseInt(targetLayer),
      content: newMessage.trim(),
      messageType: messageType as any,
      metadata: null,
    });
  };

  const getMessageTypeColor = (type: string) => {
    switch (type) {
      case "alert":
        return "destructive";
      case "sync":
        return "default";
      case "ack":
        return "secondary";
      default:
        return "outline";
    }
  };

  const getMessageTypeIcon = (type: string) => {
    switch (type) {
      case "alert":
        return "fas fa-exclamation-triangle";
      case "sync":
        return "fas fa-sync-alt";
      case "ack":
        return "fas fa-check";
      default:
        return "fas fa-info-circle";
    }
  };

  const onlineLayers = layerStatuses?.filter(layer => layer.status === "online" && layer.layerId !== 4) || [];
  const isLoading = messagesLoading || layersLoading;

  return (
    <>
      {/* Header */}
      <header className="bg-card border-b border-border p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground flex items-center">
              <i className="fas fa-comments mr-3 text-chart-2"></i>
              Comunicação Inter-Camadas
            </h2>
            <p className="text-muted-foreground">Interface de comunicação com outras camadas do sistema AZYRÍS</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="bg-muted rounded-lg px-3 py-2">
              <span className="text-xs text-muted-foreground">Camadas online:</span>
              <span className="text-sm font-medium text-foreground ml-1" data-testid="text-layers-online">
                {onlineLayers.length + 1}/9
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto bg-muted/10">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-muted-foreground">Carregando comunicações...</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Message History */}
            <div className="lg:col-span-2">
              <Card className="metric-card h-96">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-history mr-2 text-primary"></i>
                    Histórico de Comunicação
                  </CardTitle>
                  <CardDescription>
                    Mensagens recentes entre as camadas do sistema
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 overflow-y-auto custom-scrollbar space-y-3" data-testid="messages-container">
                    {messages?.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <i className="fas fa-comment-slash text-2xl mb-2"></i>
                        <p>Nenhuma mensagem encontrada</p>
                      </div>
                    ) : (
                      messages?.map((message) => (
                        <div 
                          key={message.id} 
                          className={`flex items-start space-x-3 ${message.fromLayer === 4 ? 'justify-end' : ''}`}
                          data-testid={`message-${message.id}`}
                        >
                          {message.fromLayer !== 4 && (
                            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-xs font-bold">
                              L{message.fromLayer}
                            </div>
                          )}
                          <div className={`flex-1 ${message.fromLayer === 4 ? 'text-right' : ''}`}>
                            <div className={`rounded-lg p-3 inline-block max-w-md ${
                              message.fromLayer === 4 
                                ? 'bg-primary text-primary-foreground' 
                                : 'bg-card border border-border'
                            }`}>
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant={getMessageTypeColor(message.messageType)} className="text-xs">
                                  <i className={`${getMessageTypeIcon(message.messageType)} mr-1`}></i>
                                  {message.messageType.toUpperCase()}
                                </Badge>
                                {message.toLayer && (
                                  <span className="text-xs opacity-70">
                                    → L{message.toLayer}
                                  </span>
                                )}
                              </div>
                              <p className="text-sm">{message.content}</p>
                              <p className={`text-xs mt-1 ${
                                message.fromLayer === 4 ? 'text-primary-foreground/70' : 'text-muted-foreground'
                              }`}>
                                {new Date(message.createdAt).toLocaleString('pt-BR')}
                              </p>
                            </div>
                          </div>
                          {message.fromLayer === 4 && (
                            <div className="w-8 h-8 bg-chart-2 rounded-full flex items-center justify-center text-xs font-bold text-background">
                              L4
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Send Message */}
              <Card className="metric-card mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-paper-plane mr-2 text-chart-3"></i>
                    Enviar Mensagem
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Select value={targetLayer} onValueChange={setTargetLayer}>
                        <SelectTrigger data-testid="select-target-layer">
                          <SelectValue placeholder="Selecionar camada..." />
                        </SelectTrigger>
                        <SelectContent>
                          {onlineLayers.map((layer) => (
                            <SelectItem key={layer.layerId} value={layer.layerId.toString()}>
                              Layer {layer.layerId} - {layer.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      
                      <Select value={messageType} onValueChange={setMessageType}>
                        <SelectTrigger data-testid="select-message-type">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="info">Informação</SelectItem>
                          <SelectItem value="alert">Alerta</SelectItem>
                          <SelectItem value="sync">Sincronização</SelectItem>
                          <SelectItem value="ack">Confirmação</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Digite sua mensagem..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        className="flex-1"
                        data-testid="input-message"
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      />
                      <Button 
                        onClick={handleSendMessage}
                        disabled={sendMessageMutation.isPending}
                        data-testid="button-send-message"
                      >
                        {sendMessageMutation.isPending ? (
                          <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                          <i className="fas fa-paper-plane"></i>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Layer Status Sidebar */}
            <div className="space-y-6">
              {/* Online Layers */}
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="text-lg">Status das Camadas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {layerStatuses?.map((layer) => (
                      <div 
                        key={layer.layerId} 
                        className={`flex items-center justify-between p-2 rounded ${
                          layer.layerId === 4 ? 'bg-primary/20' : 'bg-muted'
                        }`}
                        data-testid={`layer-status-${layer.layerId}`}
                      >
                        <span className={`text-sm ${layer.layerId === 4 ? 'font-medium' : ''}`}>
                          {layer.name}
                        </span>
                        <span className={`status-indicator text-xs ${
                          layer.status === 'online' ? 'status-online' : 
                          layer.status === 'reconnecting' ? 'status-warning' : 'status-error'
                        }`}>
                          {layer.status === 'online' ? 'Online' :
                           layer.status === 'reconnecting' ? 'Reconectando' : 'Offline'}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="text-lg">Ações Rápidas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    data-testid="button-broadcast-sync"
                  >
                    <i className="fas fa-broadcast-tower mr-2"></i>
                    Broadcast de Status
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    data-testid="button-ping-all"
                  >
                    <i className="fas fa-wifi mr-2"></i>
                    Ping Todas Camadas
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    data-testid="button-emergency-alert"
                  >
                    <i className="fas fa-exclamation-triangle mr-2"></i>
                    Alerta de Emergência
                  </Button>
                </CardContent>
              </Card>

              {/* Communication Stats */}
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="text-lg">Estatísticas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span>Mensagens hoje</span>
                    <span className="font-medium" data-testid="stat-messages-today">
                      {messages?.filter(m => 
                        new Date(m.createdAt).toDateString() === new Date().toDateString()
                      ).length || 0}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Enviadas</span>
                    <span className="font-medium text-chart-3" data-testid="stat-sent">
                      {messages?.filter(m => m.fromLayer === 4).length || 0}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Recebidas</span>
                    <span className="font-medium text-chart-2" data-testid="stat-received">
                      {messages?.filter(m => m.toLayer === 4 || m.toLayer === null).length || 0}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Alertas</span>
                    <span className="font-medium text-destructive" data-testid="stat-alerts">
                      {messages?.filter(m => m.messageType === 'alert').length || 0}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </main>
    </>
  );
}
