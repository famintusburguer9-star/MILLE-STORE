import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const Administration = () => {
  return (
    <>
      <Header 
        title="Administração"
        description="Gerenciamento de usuários e configurações administrativas"
      />
      
      <div className="flex-1 overflow-y-auto p-6">
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Painel Administrativo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <p className="text-muted-foreground">
                  Painel administrativo em desenvolvimento
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default Administration;
