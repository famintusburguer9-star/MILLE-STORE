import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Incident } from "@shared/schema";

export default function IncidentsPage() {
  const [filter, setFilter] = useState<string>("all");
  const [search, setSearch] = useState<string>("");

  const { data: incidents, isLoading } = useQuery<Incident[]>({
    queryKey: ["/api/incidents"],
  });

  const filteredIncidents = incidents?.filter((incident) => {
    const matchesFilter = filter === "all" || incident.status === filter || incident.severity === filter;
    const matchesSearch = incident.title.toLowerCase().includes(search.toLowerCase()) ||
                         incident.description?.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "destructive";
      case "warning":
        return "default";
      case "info":
        return "secondary";
      default:
        return "outline";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "destructive";
      case "investigating":
        return "default";
      case "resolved":
        return "secondary";
      default:
        return "outline";
    }
  };

  return (
    <>
      {/* Header */}
      <header className="bg-card border-b border-border p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground flex items-center">
              <i className="fas fa-exclamation-triangle mr-3 text-destructive"></i>
              Gestão de Incidentes
            </h2>
            <p className="text-muted-foreground">Monitoramento e resolução de incidentes de segurança</p>
          </div>
          <Button data-testid="button-new-incident">
            <i className="fas fa-plus mr-2"></i>
            Novo Incidente
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto bg-muted/10">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <Input
            placeholder="Buscar incidentes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="sm:max-w-sm"
            data-testid="input-search-incidents"
          />
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="sm:w-48" data-testid="select-filter">
              <SelectValue placeholder="Filtrar por..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="active">Ativos</SelectItem>
              <SelectItem value="investigating">Investigando</SelectItem>
              <SelectItem value="resolved">Resolvidos</SelectItem>
              <SelectItem value="critical">Críticos</SelectItem>
              <SelectItem value="warning">Avisos</SelectItem>
              <SelectItem value="info">Informativos</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="metric-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-destructive/20 rounded-lg flex items-center justify-center mr-3">
                  <i className="fas fa-fire text-destructive"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Críticos</p>
                  <p className="text-2xl font-bold" data-testid="stat-critical">
                    {incidents?.filter(i => i.severity === "critical" && i.status === "active").length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="metric-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-chart-3/20 rounded-lg flex items-center justify-center mr-3">
                  <i className="fas fa-exclamation text-chart-3"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avisos</p>
                  <p className="text-2xl font-bold" data-testid="stat-warnings">
                    {incidents?.filter(i => i.severity === "warning" && i.status === "active").length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="metric-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center mr-3">
                  <i className="fas fa-search text-primary"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Investigando</p>
                  <p className="text-2xl font-bold" data-testid="stat-investigating">
                    {incidents?.filter(i => i.status === "investigating").length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="metric-card">
            <CardContent className="p-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-chart-2/20 rounded-lg flex items-center justify-center mr-3">
                  <i className="fas fa-check text-chart-2"></i>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Resolvidos</p>
                  <p className="text-2xl font-bold" data-testid="stat-resolved">
                    {incidents?.filter(i => i.status === "resolved").length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Incidents List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-muted-foreground">Carregando incidentes...</p>
              </div>
            </div>
          ) : filteredIncidents?.length === 0 ? (
            <Card className="metric-card">
              <CardContent className="p-8 text-center">
                <i className="fas fa-search text-4xl text-muted-foreground mb-4"></i>
                <h3 className="text-lg font-medium mb-2">Nenhum incidente encontrado</h3>
                <p className="text-muted-foreground">
                  {search ? "Tente ajustar os filtros de busca" : "Não há incidentes que correspondam aos filtros selecionados"}
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredIncidents?.map((incident) => (
              <Card key={incident.id} className="metric-card" data-testid={`incident-card-${incident.id}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-3">
                        <span>#{incident.id.toString().padStart(4, '0')} - {incident.title}</span>
                        <Badge variant={getSeverityColor(incident.severity)} data-testid={`badge-severity-${incident.id}`}>
                          {incident.severity === "critical" ? "Crítico" : 
                           incident.severity === "warning" ? "Aviso" : "Info"}
                        </Badge>
                        <Badge variant={getStatusColor(incident.status)} data-testid={`badge-status-${incident.id}`}>
                          {incident.status === "active" ? "Ativo" :
                           incident.status === "investigating" ? "Investigando" : "Resolvido"}
                        </Badge>
                      </CardTitle>
                      <CardDescription className="mt-2">
                        {incident.description}
                      </CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm" data-testid={`button-view-${incident.id}`}>
                        <i className="fas fa-eye mr-1"></i>
                        Ver
                      </Button>
                      <Button variant="outline" size="sm" data-testid={`button-edit-${incident.id}`}>
                        <i className="fas fa-edit mr-1"></i>
                        Editar
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center space-x-4">
                      <span>
                        <i className="fas fa-layer-group mr-1"></i>
                        Layer {incident.sourceLayer || "N/A"}
                      </span>
                      <span>
                        <i className="fas fa-clock mr-1"></i>
                        {new Date(incident.createdAt).toLocaleString('pt-BR')}
                      </span>
                      {incident.affectedLayers && incident.affectedLayers.length > 0 && (
                        <span>
                          <i className="fas fa-sitemap mr-1"></i>
                          Afeta: L{incident.affectedLayers.join(", L")}
                        </span>
                      )}
                    </div>
                    {incident.resolvedAt && (
                      <span className="text-chart-2">
                        <i className="fas fa-check-circle mr-1"></i>
                        Resolvido em {new Date(incident.resolvedAt).toLocaleString('pt-BR')}
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </>
  );
}
