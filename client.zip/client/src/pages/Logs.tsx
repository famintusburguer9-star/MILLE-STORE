import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const Logs = () => {
  return (
    <>
      <Header 
        title="Logs do Sistema"
        description="Visualização e análise de logs de auditoria"
      />
      
      <div className="flex-1 overflow-y-auto p-6">
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Logs de Auditoria</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <p className="text-muted-foreground">
                  Visualizador de logs em desenvolvimento
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default Logs;
