import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Brain, ArrowLeft, TrendingUp, Target, Zap, BarChart3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import RLDashboard from "@/components/rl-dashboard";
import { DecisionMetrics, Decision, RLPerformance } from "@/lib/types";

export default function RLDecisions() {
  const [timeRange, setTimeRange] = useState("24h");
  const [selectedDecisionType, setSelectedDecisionType] = useState("all");

  const { data: decisionMetrics, isLoading: loadingMetrics } = useQuery<DecisionMetrics>({
    queryKey: ['/api/decisions/metrics', timeRange],
    refetchInterval: 30000
  });

  const { data: rlPerformance, isLoading: loadingRL } = useQuery<RLPerformance>({
    queryKey: ['/api/rl/performance'],
    refetchInterval: 5000
  });

  const { data: decisions, isLoading: loadingDecisions } = useQuery<Decision[]>({
    queryKey: ['/api/decisions', { limit: 100 }],
    refetchInterval: 10000
  });

  const filteredDecisions = decisions?.filter(decision => 
    selectedDecisionType === "all" || decision.type === selectedDecisionType
  ) || [];

  const getDecisionTypeColor = (type: string) => {
    switch (type) {
      case 'block': return 'bg-destructive';
      case 'escalate': return 'bg-accent';
      case 'isolate': return 'bg-red-600';
      case 'redirect': return 'bg-primary';
      case 'allow': return 'bg-green-600';
      default: return 'bg-muted';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-green-500';
    if (confidence >= 0.6) return 'text-yellow-500';
    return 'text-red-500';
  };

  if (loadingMetrics || loadingRL || loadingDecisions) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Brain className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading RL decision data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm" data-testid="button-back">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <Brain className="text-primary text-2xl" />
              <h1 className="text-xl font-bold" data-testid="title-rl-decisions">RL Decisions</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32" data-testid="select-time-range">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1h">Last Hour</SelectItem>
                <SelectItem value="6h">Last 6 Hours</SelectItem>
                <SelectItem value="24h">Last 24 Hours</SelectItem>
                <SelectItem value="7d">Last Week</SelectItem>
              </SelectContent>
            </Select>
            <Button className="bg-secondary text-secondary-foreground" data-testid="button-retrain">
              <TrendingUp className="mr-2 h-4 w-4" />
              Retrain Model
            </Button>
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* RL Engine Overview */}
        <RLDashboard />

        {/* Performance Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Decisions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-total-decisions">
                {decisionMetrics?.totalDecisions.toLocaleString() || '0'}
              </div>
              <div className="text-xs text-muted-foreground">
                {((decisionMetrics?.autonomousDecisions || 0) / (decisionMetrics?.totalDecisions || 1) * 100).toFixed(1)}% autonomous
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Success Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500" data-testid="text-success-rate">
                {(decisionMetrics?.successRate || 0).toFixed(1)}%
              </div>
              <div className="text-xs text-muted-foreground">
                vs {((rlPerformance?.successRate || 0) * 100).toFixed(1)}% RL model
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Avg Confidence</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getConfidenceColor(decisionMetrics?.averageConfidence || 0)}`} data-testid="text-avg-confidence">
                {(decisionMetrics?.averageConfidence || 0).toFixed(3)}
              </div>
              <div className="text-xs text-muted-foreground">
                Episode {rlPerformance?.currentEpisode?.toLocaleString() || '0'}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Manual Overrides</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive" data-testid="text-manual-overrides">
                {decisionMetrics?.manualOverrides || 0}
              </div>
              <div className="text-xs text-muted-foreground">
                {((decisionMetrics?.manualOverrides || 0) / (decisionMetrics?.totalDecisions || 1) * 100).toFixed(2)}% of total
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="decisions" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="decisions" data-testid="tab-decisions">Decision History</TabsTrigger>
            <TabsTrigger value="analysis" data-testid="tab-analysis">Analysis</TabsTrigger>
            <TabsTrigger value="patterns" data-testid="tab-patterns">Patterns</TabsTrigger>
            <TabsTrigger value="training" data-testid="tab-training">Training Data</TabsTrigger>
          </TabsList>

          <TabsContent value="decisions" className="space-y-6">
            <div className="flex items-center space-x-4 mb-4">
              <Select value={selectedDecisionType} onValueChange={setSelectedDecisionType}>
                <SelectTrigger className="w-40" data-testid="select-decision-type">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="block">Block</SelectItem>
                  <SelectItem value="escalate">Escalate</SelectItem>
                  <SelectItem value="isolate">Isolate</SelectItem>
                  <SelectItem value="redirect">Redirect</SelectItem>
                  <SelectItem value="allow">Allow</SelectItem>
                </SelectContent>
              </Select>
              <Badge variant="outline" data-testid="badge-filtered-count">
                {filteredDecisions.length} decisions
              </Badge>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Decision Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto scrollbar-thin">
                  {filteredDecisions.map((decision, index) => (
                    <div 
                      key={decision.id} 
                      className="bg-muted p-4 rounded-lg"
                      data-testid={`decision-item-${index}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${getDecisionTypeColor(decision.type)}`}></div>
                          <div>
                            <div className="font-medium capitalize" data-testid={`decision-type-${index}`}>
                              {decision.type} - {decision.target}
                            </div>
                            <div className="text-sm text-muted-foreground" data-testid={`decision-reason-${index}`}>
                              {decision.reason}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge 
                            variant={decision.isAutonomous ? "default" : "destructive"}
                            data-testid={`decision-mode-${index}`}
                          >
                            {decision.isAutonomous ? 'AUTO' : 'MANUAL'}
                          </Badge>
                          <div className="text-xs text-muted-foreground mt-1" data-testid={`decision-timestamp-${index}`}>
                            {decision.timestamp ? new Date(decision.timestamp).toLocaleString() : 'Now'}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 text-sm">
                          <span className="text-muted-foreground">Confidence:</span>
                          <span className={getConfidenceColor(decision.confidence)} data-testid={`decision-confidence-${index}`}>
                            {(decision.confidence * 100).toFixed(1)}%
                          </span>
                          {decision.sourceLayer && (
                            <>
                              <span className="text-muted-foreground">Source:</span>
                              <span data-testid={`decision-source-${index}`}>Layer {decision.sourceLayer}</span>
                            </>
                          )}
                        </div>
                        <Badge 
                          variant={decision.reviewStatus === 'approved' ? 'default' : 'secondary'}
                          data-testid={`decision-review-${index}`}
                        >
                          {decision.reviewStatus}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Decision Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(decisionMetrics?.decisionsByType || {}).map(([type, count]) => (
                      <div key={type} className="space-y-2">
                        <div className="flex justify-between">
                          <span className="capitalize">{type}</span>
                          <span data-testid={`type-count-${type}`}>{count}</span>
                        </div>
                        <Progress 
                          value={(count / (decisionMetrics?.totalDecisions || 1)) * 100} 
                          className="h-2" 
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Hourly Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(decisionMetrics?.decisionsByHour || {}).map(([hour, count]) => (
                      <div key={hour} className="flex justify-between text-sm">
                        <span>Hour {hour}:00</span>
                        <span data-testid={`hour-count-${hour}`}>{count} decisions</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="patterns" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Learning Patterns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary" data-testid="text-exploration-rate">
                      {((rlPerformance?.epsilon || 0) * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-muted-foreground">Exploration Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-secondary" data-testid="text-reward-avg">
                      {(rlPerformance?.averageReward || 0).toFixed(3)}
                    </div>
                    <div className="text-sm text-muted-foreground">Avg Reward</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-accent" data-testid="text-total-actions">
                      {rlPerformance?.totalDecisions.toLocaleString() || '0'}
                    </div>
                    <div className="text-sm text-muted-foreground">Total Actions</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="training" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Training Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-4">Model Performance</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Current Episode:</span>
                        <span className="font-mono" data-testid="text-current-episode-training">
                          {rlPerformance?.currentEpisode?.toLocaleString() || '0'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Success Rate:</span>
                        <span className="font-mono text-green-500" data-testid="text-success-rate-training">
                          {((rlPerformance?.successRate || 0) * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Exploration Rate:</span>
                        <span className="font-mono" data-testid="text-exploration-rate-training">
                          {((rlPerformance?.epsilon || 0) * 100).toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-4">Training Progress</h4>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Q-Learning Progress</span>
                          <span className="text-sm">78%</span>
                        </div>
                        <Progress value={78} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Network Stability</span>
                          <span className="text-sm">92%</span>
                        </div>
                        <Progress value={92} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Convergence</span>
                          <span className="text-sm">65%</span>
                        </div>
                        <Progress value={65} className="h-2" />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
