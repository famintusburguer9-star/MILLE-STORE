import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { User, Layer } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function AdminPage() {
  const [emergencyConfirm, setEmergencyConfirm] = useState("");
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: user?.role === 'admin',
  });

  const { data: layers, isLoading: layersLoading } = useQuery<Layer[]>({
    queryKey: ["/api/layers"],
  });

  const forceSyncMutation = useMutation({
    mutationFn: () => apiRequest("/api/system/sync", { method: "POST" }),
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/layers"] });
      toast({
        title: "Sincronização iniciada",
        description: `Sincronização forçada com ${data.syncedLayers} de ${data.totalLayers} camadas.`,
      });
    },
    onError: () => {
      toast({
        title: "Erro na sincronização",
        description: "Não foi possível iniciar a sincronização forçada.",
        variant: "destructive",
      });
    },
  });

  const emergencyShutdownMutation = useMutation({
    mutationFn: () => apiRequest("/api/system/emergency-shutdown", { method: "POST" }),
    onSuccess: () => {
      toast({
        title: "Shutdown de emergência iniciado",
        description: "Protocolo de shutdown de emergência foi ativado.",
        variant: "destructive",
      });
      setEmergencyConfirm("");
    },
    onError: () => {
      toast({
        title: "Erro no shutdown",
        description: "Não foi possível executar o shutdown de emergência.",
        variant: "destructive",
      });
    },
  });

  const handleEmergencyShutdown = () => {
    if (emergencyConfirm !== "CONFIRM") {
      toast({
        title: "Confirmação necessária",
        description: "Digite 'CONFIRM' para executar o shutdown de emergência.",
        variant: "destructive",
      });
      return;
    }
    emergencyShutdownMutation.mutate();
  };

  if (user?.role !== 'admin') {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <Alert className="max-w-md">
          <i className="fas fa-lock"></i>
          <AlertDescription className="ml-2">
            Acesso restrito. Apenas administradores podem acessar esta página.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const isLoading = usersLoading || layersLoading;

  return (
    <>
      {/* Header */}
      <header className="bg-card border-b border-border p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground flex items-center">
              <i className="fas fa-cog mr-3 text-primary"></i>
              Administração do Sistema
            </h2>
            <p className="text-muted-foreground">Controle e configuração avançada do AZYRÍS Layer 4</p>
          </div>
          <Badge variant="destructive" className="px-3 py-1">
            <i className="fas fa-shield-alt mr-1"></i>
            Modo Administrador
          </Badge>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto bg-muted/10">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-muted-foreground">Carregando dados administrativos...</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* System Control Panel */}
            <div className="space-y-6">
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center text-destructive">
                    <i className="fas fa-exclamation-triangle mr-2"></i>
                    Controles Críticos
                  </CardTitle>
                  <CardDescription>
                    Operações que afetam todo o sistema
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Button
                      onClick={() => forceSyncMutation.mutate()}
                      disabled={forceSyncMutation.isPending}
                      className="w-full"
                      data-testid="button-force-sync"
                    >
                      {forceSyncMutation.isPending ? (
                        <>
                          <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
                          Sincronizando...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-sync-alt mr-2"></i>
                          Forçar Sincronização Completa
                        </>
                      )}
                    </Button>
                    <p className="text-xs text-muted-foreground mt-1">
                      Força sincronização com todas as camadas online
                    </p>
                  </div>

                  <div className="border-t border-border pt-4">
                    <label className="text-sm font-medium text-destructive mb-2 block">
                      Shutdown de Emergência
                    </label>
                    <div className="space-y-2">
                      <Input
                        placeholder="Digite 'CONFIRM' para confirmar"
                        value={emergencyConfirm}
                        onChange={(e) => setEmergencyConfirm(e.target.value)}
                        data-testid="input-emergency-confirm"
                      />
                      <Button
                        variant="destructive"
                        onClick={handleEmergencyShutdown}
                        disabled={emergencyShutdownMutation.isPending || emergencyConfirm !== "CONFIRM"}
                        className="w-full"
                        data-testid="button-emergency-shutdown"
                      >
                        {emergencyShutdownMutation.isPending ? (
                          <>
                            <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
                            Executando...
                          </>
                        ) : (
                          <>
                            <i className="fas fa-power-off mr-2"></i>
                            Shutdown de Emergência
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Layer Management */}
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-layer-group mr-2 text-chart-2"></i>
                    Gestão de Camadas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {layers?.map((layer) => (
                      <div 
                        key={layer.id} 
                        className="flex items-center justify-between p-3 bg-muted rounded-lg"
                        data-testid={`layer-admin-${layer.id}`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${
                            layer.status === 'online' ? 'bg-chart-2' :
                            layer.status === 'reconnecting' ? 'bg-chart-3' : 'bg-destructive'
                          }`}></div>
                          <div>
                            <p className="text-sm font-medium">{layer.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {layer.connectionCount} conexões ativas
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={
                            layer.status === 'online' ? 'secondary' :
                            layer.status === 'reconnecting' ? 'default' : 'destructive'
                          }>
                            {layer.status === 'online' ? 'Online' :
                             layer.status === 'reconnecting' ? 'Reconectando' : 'Offline'}
                          </Badge>
                          <Button variant="outline" size="sm" data-testid={`button-manage-${layer.id}`}>
                            <i className="fas fa-cog text-xs"></i>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* User Management & System Info */}
            <div className="space-y-6">
              {/* User Management */}
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center">
                      <i className="fas fa-users mr-2 text-chart-1"></i>
                      Usuários do Sistema
                    </span>
                    <Button size="sm" data-testid="button-new-user">
                      <i className="fas fa-plus mr-1"></i>
                      Novo
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {users?.map((userData) => (
                      <div 
                        key={userData.id} 
                        className="flex items-center justify-between p-3 bg-muted rounded-lg"
                        data-testid={`user-${userData.id}`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                            <i className="fas fa-user text-primary-foreground text-xs"></i>
                          </div>
                          <div>
                            <p className="text-sm font-medium">{userData.username}</p>
                            <p className="text-xs text-muted-foreground">
                              Layer {userData.layerId} • {userData.role}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={userData.isActive ? 'secondary' : 'destructive'}>
                            {userData.isActive ? 'Ativo' : 'Inativo'}
                          </Badge>
                          <Button variant="outline" size="sm" data-testid={`button-edit-user-${userData.id}`}>
                            <i className="fas fa-edit text-xs"></i>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* System Information */}
              <Card className="metric-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-info-circle mr-2 text-chart-4"></i>
                    Informações do Sistema
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Versão AZYRÍS</p>
                      <p className="font-medium" data-testid="system-version">4.2.1</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Build</p>
                      <p className="font-medium" data-testid="system-build">20240907</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Uptime</p>
                      <p className="font-medium" data-testid="system-uptime">7d 14h 23m</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Layer ID</p>
                      <p className="font-medium" data-testid="system-layer">4</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Camadas Ativas</p>
                      <p className="font-medium" data-testid="system-active-layers">
                        {layers?.filter(l => l.status === 'online').length || 0}/9
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Último Backup</p>
                      <p className="font-medium" data-testid="system-last-backup">Ontem 03:00</p>
                    </div>
                  </div>
                  
                  <div className="border-t border-border pt-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Status Geral</span>
                      <Badge variant="secondary" className="text-chart-2" data-testid="system-status">
                        <i className="fas fa-check-circle mr-1"></i>
                        Operacional
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </main>
    </>
  );
}
