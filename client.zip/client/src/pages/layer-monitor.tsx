import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Shield, Network, Activity, AlertTriangle, CheckCircle, Clock, ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import LayerMatrix from "@/components/layer-matrix";
import { LayerStatus, LayerConnection } from "@/lib/types";

export default function LayerMonitor() {
  const [selectedLayer, setSelectedLayer] = useState<number | null>(null);

  const { data: layerStatuses, isLoading: loadingStatuses } = useQuery<LayerStatus[]>({
    queryKey: ['/api/layer-status'],
    refetchInterval: 5000
  });

  const { data: connectionMatrix, isLoading: loadingConnections } = useQuery<{
    layers: any[];
    connections: LayerConnection[];
    messageRates: Record<string, number>;
  }>({
    queryKey: ['/api/layer-connections'],
    refetchInterval: 10000
  });

  const getConnectionHealth = (connections: LayerConnection[]): number => {
    if (!connections.length) return 0;
    const healthyConnections = connections.filter(c => c.status === 'connected').length;
    return Math.round((healthyConnections / connections.length) * 100);
  };

  const getLayerDetails = (layerId: number) => {
    const layer = layerStatuses?.find(l => l.id === layerId);
    const connections = connectionMatrix?.connections.filter(
      c => c.sourceLayerId === layerId || c.destinationLayerId === layerId
    ) || [];
    
    return { layer, connections };
  };

  if (loadingStatuses || loadingConnections) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Activity className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading layer monitoring data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm" data-testid="button-back">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <Network className="text-primary text-2xl" />
              <h1 className="text-xl font-bold" data-testid="title-layer-monitor">Layer Monitor</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-sm">
              <span className="text-muted-foreground">Connection Health: </span>
              <span className={`font-medium ${
                connectionMatrix && getConnectionHealth(connectionMatrix.connections) >= 80 
                  ? 'text-green-500' 
                  : 'text-yellow-500'
              }`} data-testid="text-connection-health">
                {connectionMatrix ? getConnectionHealth(connectionMatrix.connections) : 0}%
              </span>
            </div>
            <Button className="bg-primary text-primary-foreground" data-testid="button-auto-heal">
              <CheckCircle className="mr-2 h-4 w-4" />
              Auto-Heal
            </Button>
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* Layer Matrix Overview */}
        <LayerMatrix layerStatuses={layerStatuses || []} />

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="connections" data-testid="tab-connections">Connections</TabsTrigger>
            <TabsTrigger value="performance" data-testid="tab-performance">Performance</TabsTrigger>
            <TabsTrigger value="logs" data-testid="tab-logs">Communication Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {layerStatuses?.map((layer) => {
                const { connections } = getLayerDetails(layer.id);
                const statusColor = layer.status === 'online' ? 'text-green-500' : 
                                  layer.status === 'warning' ? 'text-yellow-500' : 'text-red-500';
                
                return (
                  <Card 
                    key={layer.id} 
                    className={`hover:bg-muted/50 transition-colors cursor-pointer ${
                      selectedLayer === layer.id ? 'ring-2 ring-primary' : ''
                    }`}
                    onClick={() => setSelectedLayer(layer.id)}
                    data-testid={`layer-overview-${layer.id}`}
                  >
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>Layer {layer.id}</span>
                        <Badge variant="outline" className={statusColor} data-testid={`badge-status-${layer.id}`}>
                          {layer.status}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Last Heartbeat:</span>
                        <span data-testid={`text-heartbeat-${layer.id}`}>
                          {new Date(layer.lastHeartbeat).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Message Rate:</span>
                        <span data-testid={`text-message-rate-${layer.id}`}>
                          {layer.messageRate.toFixed(1)} msg/s
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Connections:</span>
                        <span data-testid={`text-connections-${layer.id}`}>
                          {connections.length} active
                        </span>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Health:</span>
                          <span data-testid={`text-health-${layer.id}`}>
                            {layer.connectionHealth}%
                          </span>
                        </div>
                        <Progress value={layer.connectionHealth} className="h-2" />
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="connections" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Connection Matrix</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {connectionMatrix?.connections.map((connection) => (
                    <div 
                      key={connection.id} 
                      className="flex items-center justify-between p-4 bg-muted rounded-lg"
                      data-testid={`connection-${connection.sourceLayerId}-${connection.destinationLayerId}`}
                    >
                      <div className="flex items-center space-x-4">
                        <div className="text-sm font-medium">
                          Layer {connection.sourceLayerId} → Layer {connection.destinationLayerId}
                        </div>
                        <Badge 
                          variant={connection.status === 'connected' ? 'default' : 'destructive'}
                          data-testid={`connection-status-${connection.id}`}
                        >
                          {connection.status}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                        <div data-testid={`connection-messages-${connection.id}`}>
                          {connection.messageCount} msgs
                        </div>
                        <div data-testid={`connection-latency-${connection.id}`}>
                          {connection.avgLatency.toFixed(1)}ms avg
                        </div>
                        <div data-testid={`connection-last-comm-${connection.id}`}>
                          <Clock className="h-4 w-4 inline mr-1" />
                          {new Date(connection.lastCommunication).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Message Throughput</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(connectionMatrix?.messageRates || {}).map(([layerKey, rate]) => (
                      <div key={layerKey} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{layerKey.replace('layer_', 'Layer ')}</span>
                          <span data-testid={`throughput-${layerKey}`}>{rate.toFixed(1)} msg/s</span>
                        </div>
                        <Progress value={Math.min(100, (rate / 10) * 100)} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Health Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Overall Health</span>
                      <span className="text-lg font-semibold text-green-500" data-testid="text-overall-health">
                        {connectionMatrix ? getConnectionHealth(connectionMatrix.connections) : 0}%
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Active Layers</span>
                      <span className="text-lg font-semibold" data-testid="text-active-layers">
                        {layerStatuses?.filter(l => l.status === 'online').length || 0}/
                        {layerStatuses?.length || 0}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Average Latency</span>
                      <span className="text-lg font-semibold" data-testid="text-avg-latency">
                        {connectionMatrix?.connections.reduce((acc, c) => acc + c.avgLatency, 0) / (connectionMatrix?.connections.length || 1) || 0}ms
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="logs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Communication Logs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto scrollbar-thin">
                  {/* Mock communication logs */}
                  {Array.from({ length: 10 }).map((_, index) => (
                    <div 
                      key={index}
                      className="bg-muted/50 p-3 rounded text-sm font-mono"
                      data-testid={`comm-log-${index}`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-secondary">
                          [{new Date(Date.now() - index * 10000).toLocaleTimeString()}]
                        </span>
                        <Badge variant="outline" className="text-xs">
                          COMM
                        </Badge>
                      </div>
                      <div className="text-foreground">
                        Layer {((index % 5) + 1)} → Layer {((index + 1) % 5) + 1}: heartbeat
                      </div>
                      <div className="text-muted-foreground text-xs mt-1">
                        Latency: {(Math.random() * 10 + 1).toFixed(1)}ms | Status: success
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
