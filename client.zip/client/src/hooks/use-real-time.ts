import { useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";

interface UseRealTimeOptions {
  queryKeys: string[];
  interval?: number;
  enabled?: boolean;
}

export function useRealTime({ 
  queryKeys, 
  interval = 30000, 
  enabled = true 
}: UseRealTimeOptions) {
  const queryClient = useQueryClient();
  const intervalRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (!enabled) return;

    const updateData = () => {
      queryKeys.forEach(queryKey => {
        queryClient.invalidateQueries({ queryKey: [queryKey] });
      });
    };

    // Initial update
    updateData();

    // Set up interval
    intervalRef.current = setInterval(updateData, interval);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [queryKeys, interval, enabled, queryClient]);

  const forceUpdate = () => {
    queryKeys.forEach(queryKey => {
      queryClient.invalidateQueries({ queryKey: [queryKey] });
    });
  };

  return { forceUpdate };
}

export function useSystemMonitoring() {
  return useRealTime({
    queryKeys: [
      "/api/dashboard/stats",
      "/api/dashboard/system-health",
      "/api/layers/status",
      "/api/messages",
      "/api/incidents/critical"
    ],
    interval: 15000, // Update every 15 seconds
  });
}

export function useMetricsMonitoring() {
  return useRealTime({
    queryKeys: [
      "/api/metrics",
      "/api/dashboard/system-health"
    ],
    interval: 5000, // Update every 5 seconds for real-time metrics
  });
}
