import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useWebSocket } from './useWebSocket';

interface RealTimeData {
  threatStats: {
    totalThreats: number;
    threatsBlocked: number;
    activeConnections: number;
    mlAccuracy: number;
  };
  recentIncidents: any[];
  layerStatus: any[];
  systemMetrics: any[];
  mlStatus: any;
  timestamp?: string;
}

interface UseRealTimeDataReturn {
  data: RealTimeData | null;
  isLoading: boolean;
  error: Error | null;
  isConnected: boolean;
  refresh: () => void;
}

export function useRealTimeData(): UseRealTimeDataReturn {
  const [realtimeData, setRealtimeData] = useState<RealTimeData | null>(null);
  const { isConnected, lastMessage } = useWebSocket();

  // Initial data fetch
  const {
    data: initialData,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ['/api/dashboard/data'],
    queryFn: async () => {
      const response = await fetch('/api/dashboard/data', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`Dashboard data fetch failed: ${response.status}`);
      }
      
      return response.json();
    },
    refetchInterval: isConnected ? undefined : 30000, // Poll every 30s if WebSocket disconnected
    retry: 2,
  });

  // Initialize with fetched data
  useEffect(() => {
    if (initialData && !realtimeData) {
      setRealtimeData(initialData);
    }
  }, [initialData, realtimeData]);

  // Handle real-time updates via WebSocket
  useEffect(() => {
    if (lastMessage?.type === 'realtime_update' && lastMessage.data) {
      setRealtimeData(prevData => ({
        ...prevData,
        ...lastMessage.data,
        timestamp: lastMessage.data.timestamp || new Date().toISOString(),
      }));
    } else if (lastMessage?.type === 'connected') {
      console.log('🚀 AZYRÍS Layer 4 WebSocket connection established');
    }
  }, [lastMessage]);

  const refresh = () => {
    refetch();
  };

  return {
    data: realtimeData,
    isLoading,
    error,
    isConnected,
    refresh,
  };
}
