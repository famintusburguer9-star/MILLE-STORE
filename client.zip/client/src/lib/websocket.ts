import { DashboardData } from './types';

export class WebSocketManager {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private callbacks: Map<string, (data: any) => void> = new Map();

  constructor(private url: string) {}

  connect(): void {
    try {
      this.ws = new WebSocket(this.url);
      
      this.ws.onopen = () => {
        console.log('WebSocket connected');
        this.reconnectAttempts = 0;
        this.onConnect();
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.handleMessage(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      this.ws.onclose = () => {
        console.log('WebSocket disconnected');
        this.onDisconnect();
        this.attemptReconnect();
      };

      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
      };
    } catch (error) {
      console.error('Error creating WebSocket connection:', error);
      this.attemptReconnect();
    }
  }

  disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  private attemptReconnect(): void {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
      
      console.log(`Attempting to reconnect in ${delay}ms (attempt ${this.reconnectAttempts})`);
      
      setTimeout(() => {
        this.connect();
      }, delay);
    }
  }

  private handleMessage(data: any): void {
    // Handle different message types
    if (data.type) {
      const callback = this.callbacks.get(data.type);
      if (callback) {
        callback(data);
      }
    }

    // Handle general data updates
    this.callbacks.forEach((callback) => {
      callback(data);
    });
  }

  private onConnect(): void {
    const callback = this.callbacks.get('connect');
    if (callback) {
      callback({ type: 'connect', connected: true });
    }
  }

  private onDisconnect(): void {
    const callback = this.callbacks.get('disconnect');
    if (callback) {
      callback({ type: 'disconnect', connected: false });
    }
  }

  subscribe(event: string, callback: (data: any) => void): () => void {
    this.callbacks.set(event, callback);
    
    // Return unsubscribe function
    return () => {
      this.callbacks.delete(event);
    };
  }

  send(data: any): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    } else {
      console.warn('WebSocket is not connected');
    }
  }

  isConnected(): boolean {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }
}

// SSE (Server-Sent Events) manager for dashboard real-time updates
export class SSEManager {
  private eventSource: EventSource | null = null;
  private callbacks: Map<string, (data: any) => void> = new Map();

  constructor(private url: string) {}

  connect(): void {
    try {
      this.eventSource = new EventSource(this.url);
      
      this.eventSource.onopen = () => {
        console.log('SSE connected');
      };

      this.eventSource.onmessage = (event) => {
        try {
          const data: DashboardData = JSON.parse(event.data);
          this.handleUpdate(data);
        } catch (error) {
          console.error('Error parsing SSE data:', error);
        }
      };

      this.eventSource.onerror = (error) => {
        console.error('SSE error:', error);
      };
    } catch (error) {
      console.error('Error creating SSE connection:', error);
    }
  }

  disconnect(): void {
    if (this.eventSource) {
      this.eventSource.close();
      this.eventSource = null;
    }
  }

  private handleUpdate(data: DashboardData): void {
    this.callbacks.forEach((callback) => {
      callback(data);
    });
  }

  subscribe(callback: (data: DashboardData) => void): () => void {
    const id = Math.random().toString(36).substr(2, 9);
    this.callbacks.set(id, callback);
    
    return () => {
      this.callbacks.delete(id);
    };
  }

  isConnected(): boolean {
    return this.eventSource !== null && this.eventSource.readyState === EventSource.OPEN;
  }
}
