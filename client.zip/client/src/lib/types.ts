export interface LayerStatus {
  id: number;
  name: string;
  status: 'online' | 'offline' | 'warning' | 'error' | 'learning';
  lastHeartbeat: Date;
  messageRate: number;
  latency: number;
  connectionHealth: number;
}

export interface LayerConnection {
  id: string;
  sourceLayerId: number;
  destinationLayerId: number;
  status: 'connected' | 'disconnected' | 'error';
  lastCommunication: Date;
  messageCount: number;
  avgLatency: number;
}

export interface Decision {
  id: string;
  type: string;
  target: string;
  confidence: number;
  reason: string;
  action: string;
  timestamp: Date;
  sourceLayer?: number;
  isAutonomous: boolean;
  reviewStatus: string;
  metadata?: Record<string, any>;
}

export interface RLPerformance {
  averageReward: number;
  successRate: number;
  totalDecisions: number;
  currentEpisode: number;
  epsilon: number;
}

export interface SystemPerformance {
  decisionLatency: number;
  accuracyRate: number;
  falsePositiveRate: number;
  cpuUsage: number;
  memoryUsage: number;
  threatDetectionRate: number;
}

export interface MetaLearningAnalysis {
  evolutionRate: number;
  emergingThreats: string[];
  adaptationTrends: Record<string, number>;
}

export interface DecisionMetrics {
  totalDecisions: number;
  autonomousDecisions: number;
  manualOverrides: number;
  averageConfidence: number;
  successRate: number;
  decisionsByType: Record<string, number>;
  decisionsByHour: Record<string, number>;
}

export interface AuditLog {
  id: string;
  action: string;
  component: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  message: string;
  timestamp: Date;
  userId?: string;
  metadata?: Record<string, any>;
}

export interface ThreatPattern {
  id: string;
  patternType: string;
  signature: string;
  confidence: number;
  adaptationLevel: number;
  detectionCount: number;
  lastSeen: Date;
  isActive: boolean;
  metadata?: Record<string, any>;
}

export interface DashboardData {
  timestamp: string;
  layerStatuses: LayerStatus[];
  recentDecisions: Decision[];
  systemPerformance: SystemPerformance;
  rlPerformance: RLPerformance;
}
