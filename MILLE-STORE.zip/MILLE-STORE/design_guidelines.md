# Mille Store - Mobile App Design Guidelines

## Design Approach
**Reference-Based E-commerce:** Drawing inspiration from modern beauty e-commerce apps (Sephora, Glossier) and Instagram's visual grid patterns. Focus on product photography prominence with clean, touch-optimized mobile interface.

## Core Design Principles
- **Mobile-First:** Optimized for one-handed navigation and thumb-friendly interactions
- **Visual Commerce:** Large product imagery drives engagement
- **Playful Sophistication:** Balance feminine aesthetics with professional credibility

---

## Typography
- **Primary Font:** 'Poppins' (Google Fonts) - Modern, rounded, friendly
- **Headings:** Poppins Bold (600-700) for brand name and section titles
- **Body Text:** Poppins Regular (400) for descriptions
- **Prices:** Poppins SemiBold (600) for emphasis
- **Sizes:** Brand name (32-36px), Category headers (20-24px), Product names (16-18px), Body (14-16px), Prices (18-20px)

---

## Layout System
**Spacing Units:** Tailwind spacing - primarily use 2, 3, 4, 6, 8, 12, 16
- Cards: p-4 for padding, gap-4 between elements
- Sections: py-8 to py-12 for vertical spacing
- Grid gaps: gap-4 for product grids

**Container:** Full-width mobile with px-4 horizontal padding for content breathing room

---

## Component Library

### Home Screen
- **Hero Section:** Full-viewport (100vh) branded splash featuring elegant "Mille Store" logotype with subtle pink gradient background treatment
- **Logo Placement:** Centered, with tagline "Cosméticos & Beleza" underneath
- **Navigation:** Fixed bottom tab bar (80px height) with 5 category icons and labels

### Category Navigation
- **Bottom Tab Bar:** Sticky navigation with icon + label for each category
- **Active State:** Pink underline indicator (3px thick) beneath active category
- **Icons:** Use Font Awesome icons (fa-cut for Cabelo, fa-palette for Maquiagem, fa-spray-can for Perfumes, fa-gem for Acessórios, fa-heart for Sex Shop)

### Product Grid
- **Layout:** 2-column grid (grid-cols-2) with gap-4
- **Card Structure:**
  - Square aspect ratio product image (1:1)
  - Product name (2 lines max, truncate with ellipsis)
  - Short description (1 line, lighter weight)
  - Price (bold, prominent)
  - Rounded corners (rounded-xl)
  - Subtle shadow (shadow-md)
  - White background with pink accent on hover/tap

### Admin Panel
- **Access:** Floating gear icon (bottom-right, above WhatsApp button)
- **Interface:** Full-screen overlay with dark semi-transparent backdrop
- **Form Fields:** Simple text inputs for editing JSON, styled with pink focus rings
- **Actions:** "Salvar" (Save) and "Cancelar" (Cancel) buttons

### WhatsApp Button
- **Position:** Fixed bottom-right, floating above content (z-index: 1000)
- **Style:** Circular button (64px diameter) with WhatsApp green (#25D366)
- **Icon:** WhatsApp logo (white)
- **Shadow:** Large shadow (shadow-2xl) for prominence

### Product Cards
- **Image Container:** Aspect ratio 1:1, object-fit: cover
- **Padding:** p-3 for card content
- **Interaction:** Tap to expand with product details (optional modal)
- **Price Display:** Bottom-right of card, pink background pill (rounded-full, px-3, py-1)

---

## Animations
- **Page Transitions:** Subtle slide-in from right (200ms) when switching categories
- **Card Interactions:** Scale transform (scale-105) on tap/hover with 150ms transition
- **Bottom Nav:** Bounce animation (150ms) when selecting category
- **WhatsApp Button:** Pulse effect (subtle, infinite loop)

---

## Images
**Product Images Required:**
- Minimum 10-12 placeholder product images across all categories
- Square format (500x500px minimum)
- High-quality cosmetics photography with clean backgrounds
- Categories should have distinct visual identities:
  - **Cabelo:** Hair products, shampoos, treatments
  - **Maquiagem:** Makeup palettes, lipsticks, brushes
  - **Perfumes:** Elegant perfume bottles
  - **Acessórios:** Jewelry, bags, beauty accessories
  - **Sex Shop:** Tasteful, discreet product imagery

**Hero Image:** Optional soft-focus beauty background (cosmetics/flowers) with overlay gradient, or solid pink gradient treatment

---

## Mobile Optimizations
- **Touch Targets:** Minimum 44x44px for all tappable elements
- **Scrolling:** Smooth scroll behavior, momentum scrolling enabled
- **Viewport:** `<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">`
- **Safe Areas:** Account for iOS notches with safe-area-inset padding
- **Performance:** Lazy-load product images, optimize with srcset

---

## Accessibility
- Sufficient color contrast for pink text on black/white backgrounds
- Semantic HTML structure (nav, main, article for products)
- Alt text for all product images
- Focus indicators (pink outline) for keyboard navigation