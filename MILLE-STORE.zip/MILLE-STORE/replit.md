# Mille Store - Mobile Cosmetics E-commerce App

## Overview

Mille Store is a mobile-first e-commerce application designed for selling cosmetics and beauty products. The app features a visually-driven product catalog organized into five categories: Hair Care (Cabelo), Makeup (Maquiagem), Perfumes, Accessories (Acessórios), and Adult Products (Sex Shop). The application emphasizes a playful yet sophisticated aesthetic with pink/rose color schemes inspired by modern beauty brands like Sephora and Glossier.

The app provides:
- A hero landing page with category exploration
- Product browsing organized by categories
- Shopping cart functionality with real-time stock validation
- Admin panel for product management (CRUD operations)
- WhatsApp integration for customer support
- Checkout flow with customer information collection

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript, using Vite as the build tool and development server.

**UI Component Library**: The app uses shadcn/ui components (based on Radix UI primitives) for a consistent, accessible interface. All UI components follow the "New York" style variant with custom theming.

**Styling System**: 
- Tailwind CSS for utility-first styling
- Custom design tokens defined in CSS variables for colors, spacing, and shadows
- Poppins font family from Google Fonts as the primary typeface
- Mobile-first responsive design approach optimized for touch interactions

**State Management**:
- React Context API for global cart state (`CartProvider`)
- TanStack Query (React Query) for server state management, API caching, and real-time data synchronization
- React Hook Form with Zod validation for form handling

**Routing**: Wouter (lightweight routing library) handles client-side navigation, though the app is primarily a single-page application with modal-based flows.

**Design Rationale**: The mobile-first architecture was chosen because the target audience primarily shops on mobile devices. The component-based approach using shadcn/ui provides consistency while allowing customization. React Query handles automatic background refetching (every 5 seconds for product data) to ensure cart items stay synchronized with current inventory levels.

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript.

**API Design**: RESTful API with JSON request/response format:
- `GET /api/products` - Retrieve all products
- `GET /api/products/:id` - Retrieve specific product
- `POST /api/products` - Create new product
- `PATCH /api/products/:id` - Update product
- `DELETE /api/products/:id` - Delete product
- `POST /api/orders` - Create new order

**Data Validation**: Zod schemas validate all incoming requests before processing, with automatic error message formatting via `zod-validation-error`.

**Development vs Production**:
- Development mode uses Vite middleware for hot module replacement
- Production mode serves pre-built static assets from the `dist/public` directory
- Both modes run the same Express API server

**Design Rationale**: Express was chosen for its simplicity and extensive ecosystem. The REST API design follows standard conventions for easy consumption. Separating dev/prod server configurations allows for optimal developer experience while maintaining production performance.

### Data Storage

**Current Implementation**: File-based JSON storage using Node.js `fs` module with two data files:
- `products.json` - Product catalog
- `orders.json` - Customer orders

**Schema Definition**: Drizzle ORM schemas are defined in `shared/schema.ts` using PostgreSQL-compatible types, preparing for future database migration.

**Data Models**:
- **Product**: id, name, description, price (decimal), category, imageUrl, quantity
- **Order**: id, customerName, customerPhone, customerAddress, paymentMethod, items (JSON string), totalAmount, createdAt, status

**Design Rationale**: File-based storage provides simplicity for initial development and deployment without external dependencies. However, the Drizzle schemas are already defined for PostgreSQL, indicating the architecture is prepared for migration to a proper database when scaling needs require it. The `quantity` field uses string type currently but would benefit from numeric type in a database implementation.

**Known Limitation**: File-based storage lacks transaction support and concurrent write safety. Multiple simultaneous writes could result in data loss or corruption. This is acceptable for low-traffic scenarios but would need database migration for production use.

### External Dependencies

**Database**: 
- Configured for PostgreSQL via Neon serverless driver (`@neondatabase/serverless`)
- Drizzle ORM (`drizzle-orm`) as the database toolkit
- Connection configured via `DATABASE_URL` environment variable
- Note: Currently using file-based storage, but infrastructure is ready for PostgreSQL

**Third-Party Services**:
- **WhatsApp Business API**: Direct link integration for customer support (phone number configurable in `whatsapp-button.tsx`)
- **Google Fonts**: Poppins font family loaded from Google Fonts CDN

**UI Component Libraries**:
- Radix UI primitives (@radix-ui/*) - 20+ component packages for accessible UI primitives
- React Icons (react-icons/fa) - FontAwesome icons for category navigation
- Embla Carousel (embla-carousel-react) - Touch-friendly carousel component
- CMDK (cmdk) - Command menu interface component

**Development Tools**:
- Replit-specific plugins (@replit/vite-plugin-*) for development experience enhancements
- TypeScript for type safety across the entire stack
- ESBuild for production bundling

**Design Rationale**: The dependency choices favor modern, actively-maintained packages with strong TypeScript support. Radix UI provides accessibility out-of-the-box while remaining unstyled for customization. The Neon serverless driver was chosen for its PostgreSQL compatibility with edge/serverless environments, though it's not currently being used.