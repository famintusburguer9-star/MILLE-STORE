# Mille Store - App de Cosméticos

Bem-vinda ao seu novo aplicativo da Mille Store! 🌸

## Como Usar o App

### 1. Acessar o Aplicativo
O aplicativo está pronto para uso! Quando você clicar em "Abrir no celular" ou compartilhar o link, ele funcionará perfeitamente em qualquer dispositivo móvel (Android/iOS).

### 2. Navegar pelas Categorias
- Na tela inicial, clique em "Explorar Produtos"
- Use o menu na parte inferior da tela para navegar entre as categorias:
  - 💇 Cabelo
  - 💄 Maquiagem
  - ✨ Perfumes
  - 💎 Acessórios
  - 💖 Sex Shop

### 3. WhatsApp
- O botão verde do WhatsApp fica fixo no canto inferior direito
- **IMPORTANTE**: Configure seu número de WhatsApp editando o arquivo:
  - Abra: `client/src/components/whatsapp-button.tsx`
  - Procure a linha: `const phoneNumber = "5511999999999";`
  - Substitua por seu número (formato: código do país + DDD + número)
  - Exemplo: `const phoneNumber = "5511987654321";`

### 4. Gerenciar Produtos (Painel Admin)

#### Como Adicionar Produtos:
1. Clique no ícone de engrenagem ⚙️ no topo da tela
2. Preencha o formulário "Novo Produto":
   - **Nome**: Nome do produto (ex: "Shampoo Hidratante Rosa")
   - **Descrição**: Breve descrição (ex: "Hidratação profunda com óleo de argan")
   - **Preço**: Apenas números (ex: 49.90)
   - **Categoria**: Escolha uma das 5 categorias
   - **URL da Imagem**: Link da foto do produto
3. Clique em "Criar Produto"

#### Como Editar Produtos:
1. Abra o painel admin (ícone ⚙️)
2. Role até encontrar o produto na lista
3. Clique em "Editar"
4. Faça as alterações necessárias
5. Clique em "Salvar"

#### Como Excluir Produtos:
1. Abra o painel admin (ícone ⚙️)
2. Encontre o produto que deseja remover
3. Clique no ícone de lixeira 🗑️
4. O produto será removido imediatamente

### 5. Editar Catálogo Manualmente (Avançado)

Se preferir editar todos os produtos de uma vez, você pode editar o arquivo `products.json` na raiz do projeto:

```json
[
  {
    "id": "uuid-gerado-automaticamente",
    "name": "Nome do Produto",
    "description": "Descrição breve",
    "price": "49.90",
    "category": "Cabelo",
    "imageUrl": "/caminho/da/imagem.png"
  }
]
```

**Categorias válidas:**
- "Cabelo"
- "Maquiagem"
- "Perfumes"
- "Acessórios"
- "Sex Shop"

### 6. Adicionar Imagens de Produtos

Você tem duas opções:

**Opção 1 - URLs da Internet:**
- Use links diretos de imagens hospedadas online
- Exemplo: `"https://seusite.com.br/imagem-produto.jpg"`

**Opção 2 - Imagens Locais:**
- Coloque as imagens na pasta `attached_assets/`
- Use o caminho: `"/attached_assets/nome-da-imagem.png"`

**Dica**: As imagens devem ser quadradas (500x500px ou similar) para melhor visualização.

## Design do App

O app usa um tema moderno com:
- 🎨 Cores: Rosa (#d946a6) e Preto
- 📱 100% responsivo para celular
- ✨ Animações suaves
- 🌙 Suporte a modo escuro (automático)

## Recursos Incluídos

- ✅ Tela inicial bonita com o logo da loja
- ✅ 5 categorias de produtos
- ✅ Cards de produtos com foto, nome, descrição e preço
- ✅ Painel de administração para editar produtos
- ✅ Botão de WhatsApp para contato direto
- ✅ Design moderno rosa e preto
- ✅ Totalmente responsivo para celular

## Publicar o App

Para tornar seu app acessível para clientes:

1. Clique no botão "Publicar" no Replit
2. Copie o link gerado (terminará em `.replit.app`)
3. Compartilhe esse link com seus clientes
4. Eles podem adicionar à tela inicial do celular para usar como app!

## Adicionar à Tela Inicial (App Mode)

Seus clientes podem "instalar" o app:

**No iPhone/iPad:**
1. Abra o link no Safari
2. Toque no ícone de compartilhar
3. Escolha "Adicionar à Tela de Início"
4. Pronto! O app aparecerá como um aplicativo normal

**No Android:**
1. Abra o link no Chrome
2. Toque nos 3 pontinhos (menu)
3. Escolha "Adicionar à tela inicial"
4. Confirme
5. Pronto! O app aparecerá como um aplicativo normal

## Suporte

Se precisar de ajuda ou tiver dúvidas sobre como usar o painel admin, as configurações estão todas no código e podem ser ajustadas conforme necessário.

Boa sorte com a Mille Store! 💖✨
