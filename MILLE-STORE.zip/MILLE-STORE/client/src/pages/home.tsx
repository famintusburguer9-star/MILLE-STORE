import { useState } from "react";
import { Sparkles, Scissors, Palette, Gem, Heart, Settings, ShoppingCart } from "lucide-react";
import { ProductGrid } from "@/components/product-grid";
import { AdminLogin } from "@/components/admin-login";
import { WhatsAppButton } from "@/components/whatsapp-button";
import { CategoryNav } from "@/components/category-nav";
import { HeroSection } from "@/components/hero-section";
import { CartModal } from "@/components/cart-modal";
import { CheckoutModal } from "@/components/checkout-modal";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/contexts/cart-context";
import type { Category } from "@shared/schema";

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<Category | null>(null);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const { getTotalItems } = useCart();

  const handleCheckout = () => {
    setShowCart(false);
    setShowCheckout(true);
  };

  const handleCheckoutSuccess = () => {
    setShowCheckout(false);
    setActiveCategory(null);
  };

  return (
    <div className="min-h-screen bg-background">
      {!activeCategory ? (
        <HeroSection onExplore={() => setActiveCategory("Cabelo")} />
      ) : (
        <>
          <header className="sticky top-0 z-40 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
            <div className="flex items-center justify-between px-4 py-3">
              <button
                onClick={() => setActiveCategory(null)}
                className="text-2xl font-bold bg-gradient-to-r from-primary to-pink-500 bg-clip-text text-transparent"
                data-testid="button-home"
              >
                Mille Store
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowCart(true)}
                  className="relative p-2 rounded-full hover-elevate active-elevate-2"
                  data-testid="button-cart"
                >
                  <ShoppingCart className="w-5 h-5 text-muted-foreground" />
                  {getTotalItems() > 0 && (
                    <Badge
                      className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                      data-testid="cart-badge"
                    >
                      {getTotalItems()}
                    </Badge>
                  )}
                </button>
                <button
                  onClick={() => setShowAdmin(true)}
                  className="p-2 rounded-full hover-elevate active-elevate-2"
                  data-testid="button-admin"
                >
                  <Settings className="w-5 h-5 text-muted-foreground" />
                </button>
              </div>
            </div>
          </header>

          <main className="pb-20">
            <ProductGrid category={activeCategory} />
          </main>

          <CategoryNav
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
          />
        </>
      )}

      <WhatsAppButton />
      
      {showAdmin && (
        <AdminLogin onClose={() => setShowAdmin(false)} />
      )}

      {showCart && (
        <CartModal onClose={() => setShowCart(false)} onCheckout={handleCheckout} />
      )}

      {showCheckout && (
        <CheckoutModal onClose={() => setShowCheckout(false)} onSuccess={handleCheckoutSuccess} />
      )}
    </div>
  );
}
