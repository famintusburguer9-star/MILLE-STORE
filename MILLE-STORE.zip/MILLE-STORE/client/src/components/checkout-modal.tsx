import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { X, CreditCard, Banknote, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useCart } from "@/contexts/cart-context";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const checkoutSchema = z.object({
  customerName: z.string().min(3, "Nome completo é obrigatório"),
  customerPhone: z.string().min(10, "Telefone é obrigatório"),
  customerAddress: z.string().min(10, "Endereço completo é obrigatório"),
  paymentMethod: z.enum(["Dinheiro", "Pix", "Cartão de Crédito", "Cartão de Débito"]),
});

type CheckoutForm = z.infer<typeof checkoutSchema>;

interface CheckoutModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

export function CheckoutModal({ onClose, onSuccess }: CheckoutModalProps) {
  const { items, getTotalPrice, clearCart } = useCart();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasStockIssue, setHasStockIssue] = useState(false);

  const { data: products, isLoading: isLoadingProducts, refetch: refetchProducts } = useQuery({
    queryKey: ["/api/products"],
  });

  useEffect(() => {
    if (products && Array.isArray(products)) {
      const stockIssue = items.some(item => {
        const freshProduct = products.find(p => p.id === item.product.id);
        if (!freshProduct) return true;
        return item.quantity > Number(freshProduct.quantity);
      });
      setHasStockIssue(stockIssue);
      
      if (stockIssue) {
        toast({
          title: "Estoque atualizado",
          description: "Alguns produtos tiveram seu estoque alterado. Verifique as quantidades no carrinho.",
          variant: "destructive",
        });
      }
    }
  }, [products, items, toast]);

  const form = useForm<CheckoutForm>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      customerName: "",
      customerPhone: "",
      customerAddress: "",
      paymentMethod: "Pix",
    },
  });

  const formattedTotal = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(getTotalPrice());

  const sendWhatsAppMessage = (orderData: CheckoutForm) => {
    const phoneNumber = "+556699765327";
    
    let message = `🛍️ *NOVO PEDIDO - MILLE STORE*\n\n`;
    message += `👤 *Cliente:* ${orderData.customerName}\n`;
    message += `📱 *Telefone:* ${orderData.customerPhone}\n`;
    message += `📍 *Endereço:* ${orderData.customerAddress}\n\n`;
    message += `🛒 *Itens do Pedido:*\n`;
    
    items.forEach((item, index) => {
      const effectivePrice = item.product.promotionalPrice || item.product.price;
      const itemTotal = Number(effectivePrice) * item.quantity;
      message += `${index + 1}. ${item.product.name}\n`;
      message += `   Qtd: ${item.quantity}x - ${new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL",
      }).format(itemTotal)}\n`;
    });
    
    message += `\n💰 *Valor Total:* ${formattedTotal}\n`;
    message += `💳 *Forma de Pagamento:* ${orderData.paymentMethod}\n`;
    
    const encodedMessage = encodeURIComponent(message);
    window.open(
      `https://wa.me/${phoneNumber}?text=${encodedMessage}`,
      "_blank",
      "noopener,noreferrer"
    );
  };

  const onSubmit = async (data: CheckoutForm) => {
    setIsSubmitting(true);
    try {
      const { data: freshProducts } = await refetchProducts();
      
      if (freshProducts && Array.isArray(freshProducts)) {
        const stockIssue = items.some(item => {
          const freshProduct = freshProducts.find((p: any) => p.id === item.product.id);
          if (!freshProduct) return true;
          return item.quantity > Number(freshProduct.quantity);
        });
        
        if (stockIssue) {
          toast({
            title: "Estoque insuficiente",
            description: "Alguns produtos no carrinho excedem o estoque disponível. Volte ao carrinho e ajuste as quantidades.",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }
      }

      await apiRequest("POST", "/api/orders", {
        ...data,
        items: JSON.stringify(items.map(item => {
          const effectivePrice = item.product.promotionalPrice || item.product.price;
          return {
            productId: item.product.id,
            productName: item.product.name,
            quantity: item.quantity,
            price: effectivePrice,
          };
        })),
        totalAmount: getTotalPrice().toString(),
        status: "pending",
      });

      clearCart();
      
      sendWhatsAppMessage(data);
      
      toast({
        title: "Pedido realizado!",
        description: "Seu pedido foi enviado com sucesso. Entraremos em contato em breve.",
      });
      onSuccess();
    } catch (error) {
      toast({
        title: "Erro ao finalizar pedido",
        description: "Não foi possível finalizar seu pedido. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const paymentIcons = {
    "Dinheiro": Banknote,
    "Pix": QrCode,
    "Cartão de Crédito": CreditCard,
    "Cartão de Débito": CreditCard,
  };

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
      <div className="fixed inset-x-0 top-0 bottom-0 bg-background">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <h2 className="text-xl font-bold text-foreground">
              Finalizar Compra
            </h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-checkout"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          <ScrollArea className="flex-1 px-4 py-4">
            <div className="space-y-4">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3">Resumo do Pedido</h3>
                  <div className="space-y-2">
                    {items.map((item) => {
                      const effectivePrice = item.product.promotionalPrice || item.product.price;
                      return (
                        <div key={item.product.id} className="flex justify-between text-sm">
                          <span className="text-muted-foreground">
                            {item.quantity}x {item.product.name}
                          </span>
                          <span className="font-medium">
                            {new Intl.NumberFormat("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            }).format(Number(effectivePrice) * item.quantity)}
                          </span>
                        </div>
                      );
                    })}
                    <Separator className="my-2" />
                    <div className="flex justify-between font-semibold text-base">
                      <span>Total:</span>
                      <span className="text-primary">{formattedTotal}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="customerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome Completo</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="João da Silva"
                            {...field}
                            data-testid="input-customer-name"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="customerPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Telefone</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="(11) 99999-9999"
                            {...field}
                            data-testid="input-customer-phone"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="customerAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Endereço Completo</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Rua, número, complemento, bairro, cidade - CEP"
                            {...field}
                            data-testid="input-customer-address"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="paymentMethod"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Forma de Pagamento</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-payment-method">
                              <SelectValue placeholder="Selecione a forma de pagamento" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Object.entries(paymentIcons).map(([method, Icon]) => (
                              <SelectItem key={method} value={method}>
                                <div className="flex items-center gap-2">
                                  <Icon className="w-4 h-4" />
                                  {method}
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  {hasStockIssue && (
                    <div className="p-3 bg-destructive/10 border border-destructive rounded-md">
                      <p className="text-sm text-destructive font-medium">
                        Alguns produtos excedem o estoque disponível. Volte ao carrinho para ajustar.
                      </p>
                    </div>
                  )}
                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={isSubmitting || hasStockIssue || isLoadingProducts}
                    data-testid="button-confirm-order"
                  >
                    {isSubmitting ? "Finalizando..." : hasStockIssue ? "Estoque Insuficiente" : "Confirmar Pedido"}
                  </Button>
                </form>
              </Form>
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}
