import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { useCart } from "@/contexts/cart-context";
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem, items } = useCart();
  const { toast } = useToast();
  
  const formattedPrice = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(Number(product.price));

  const hasPromotionalPrice = product.promotionalPrice && Number(product.promotionalPrice) > 0;
  const formattedPromotionalPrice = hasPromotionalPrice
    ? new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL",
      }).format(Number(product.promotionalPrice))
    : null;

  const isOutOfStock = Number(product.quantity) === 0;
  const currentQuantityInCart = items.find(item => item.product.id === product.id)?.quantity || 0;
  const availableStock = Number(product.quantity);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isOutOfStock) return;
    
    if (currentQuantityInCart >= availableStock) {
      toast({
        title: "Estoque insuficiente",
        description: `Você já adicionou todo o estoque disponível deste produto.`,
        variant: "destructive",
      });
      return;
    }
    
    addItem(product, 1);
    toast({
      title: "Produto adicionado!",
      description: `${product.name} foi adicionado ao carrinho.`,
    });
  };

  return (
    <Card
      className="overflow-hidden hover-elevate active-elevate-2 transition-all duration-200"
      data-testid={`card-product-${product.id}`}
    >
      <CardContent className="p-0">
        <div className="aspect-square bg-muted overflow-hidden">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>
        
        <div className="p-3 space-y-2">
          <h3
            className="font-semibold text-sm leading-tight line-clamp-2 text-foreground"
            data-testid={`text-product-name-${product.id}`}
          >
            {product.name}
          </h3>
          
          <p className="text-xs text-muted-foreground line-clamp-1">
            {product.description}
          </p>
          
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between">
              <div className="flex flex-col gap-1">
                {hasPromotionalPrice ? (
                  <>
                    <span className="text-xs text-muted-foreground line-through" data-testid={`text-original-price-${product.id}`}>
                      {formattedPrice}
                    </span>
                    <Badge
                      variant="secondary"
                      className="bg-primary/10 text-primary hover:bg-primary/20 font-semibold text-sm px-3 py-1"
                      data-testid={`text-product-price-${product.id}`}
                    >
                      {formattedPromotionalPrice}
                    </Badge>
                  </>
                ) : (
                  <Badge
                    variant="secondary"
                    className="bg-primary/10 text-primary hover:bg-primary/20 font-semibold text-sm px-3 py-1"
                    data-testid={`text-product-price-${product.id}`}
                  >
                    {formattedPrice}
                  </Badge>
                )}
              </div>
              <span className="text-xs text-muted-foreground" data-testid={`text-stock-${product.id}`}>
                {Number(product.quantity) > 0 ? `${product.quantity} disponíveis` : 'Esgotado'}
              </span>
            </div>
            <Button
              onClick={handleAddToCart}
              disabled={isOutOfStock}
              className="w-full"
              size="sm"
              data-testid={`button-add-to-cart-${product.id}`}
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              {isOutOfStock ? 'Esgotado' : 'Adicionar'}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
