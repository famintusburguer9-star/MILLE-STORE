import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function WhatsAppButton() {
  const handleWhatsAppClick = () => {
    const phoneNumber = "+556699765327";
    const message = encodeURIComponent(
      "Olá! Gostaria de saber mais sobre os produtos da Mille Store."
    );
    window.open(
      `https://wa.me/${phoneNumber}?text=${message}`,
      "_blank",
      "noopener,noreferrer"
    );
  };

  return (
    <Button
      onClick={handleWhatsAppClick}
      size="icon"
      className="fixed bottom-20 right-4 z-50 h-16 w-16 rounded-full shadow-2xl bg-[#25D366] border-2 border-white"
      data-testid="button-whatsapp"
    >
      <MessageCircle className="w-6 h-6 text-white" />
      <span className="sr-only">Contato WhatsApp</span>
    </Button>
  );
}
