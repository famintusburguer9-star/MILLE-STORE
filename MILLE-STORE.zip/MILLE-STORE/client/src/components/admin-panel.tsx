import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { X, Plus, Trash2, Save, Upload, Image as ImageIcon, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Product, Category, InsertProduct } from "@shared/schema";
import { categories, insertProductSchema } from "@shared/schema";

interface AdminPanelProps {
  onClose: () => void;
  onLogout: () => void;
}

export function AdminPanel({ onClose, onLogout }: AdminPanelProps) {
  const { toast } = useToast();
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const newProductFileInputRef = useRef<HTMLInputElement>(null);
  const editFileInputRef = useRef<HTMLInputElement>(null);

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/admin/logout", {});
      onLogout();
      toast({
        title: "Logout realizado",
        description: "Você saiu do painel administrativo.",
      });
    } catch (error) {
      toast({
        title: "Erro ao fazer logout",
        description: "Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleAuthError = () => {
    toast({
      title: "Sessão expirada",
      description: "Faça login novamente para continuar.",
      variant: "destructive",
    });
    onLogout();
  };

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const newProductForm = useForm<InsertProduct>({
    resolver: zodResolver(insertProductSchema),
    defaultValues: {
      name: "",
      description: "",
      price: "",
      promotionalPrice: undefined,
      category: "Cabelo",
      imageUrl: "",
      quantity: "0",
    },
  });

  const editForm = useForm<InsertProduct>({
    resolver: zodResolver(insertProductSchema),
    defaultValues: {
      name: "",
      description: "",
      price: "",
      promotionalPrice: undefined,
      category: "Cabelo",
      imageUrl: "",
      quantity: "0",
    },
  });

  const createMutation = useMutation({
    mutationFn: (product: InsertProduct) =>
      apiRequest("POST", "/api/products", product),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      newProductForm.reset();
      toast({
        title: "Produto criado!",
        description: "O produto foi adicionado com sucesso.",
      });
    },
    onError: (error: any) => {
      if (error.message?.includes("401") || error.status === 401) {
        handleAuthError();
      } else {
        toast({
          title: "Erro ao criar produto",
          description: "Não foi possível criar o produto. Tente novamente.",
          variant: "destructive",
        });
      }
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: InsertProduct }) =>
      apiRequest("PATCH", `/api/products/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setEditingProduct(null);
      editForm.reset();
      toast({
        title: "Produto atualizado!",
        description: "As alterações foram salvas.",
      });
    },
    onError: (error: any) => {
      if (error.message?.includes("401") || error.status === 401) {
        handleAuthError();
      } else {
        toast({
          title: "Erro ao atualizar produto",
          description: "Não foi possível atualizar o produto. Tente novamente.",
          variant: "destructive",
        });
      }
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/products/${id}`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Produto removido!",
        description: "O produto foi excluído.",
      });
    },
    onError: (error: any) => {
      if (error.message?.includes("401") || error.status === 401) {
        handleAuthError();
      } else {
        toast({
          title: "Erro ao deletar produto",
          description: "Não foi possível deletar o produto. Tente novamente.",
          variant: "destructive",
        });
      }
    },
  });

  const handleCreate = (data: InsertProduct) => {
    createMutation.mutate({
      ...data,
      quantity: String(Number(data.quantity) || 0),
    });
  };

  const handleUpdate = (data: InsertProduct) => {
    if (!editingProduct) return;
    updateMutation.mutate({ 
      id: editingProduct.id, 
      data: {
        ...data,
        quantity: String(Number(data.quantity) || 0),
      }
    });
  };

  const handleEditClick = (product: Product) => {
    setEditingProduct(product);
    editForm.reset({
      name: product.name,
      description: product.description,
      price: product.price,
      promotionalPrice: product.promotionalPrice,
      category: product.category,
      imageUrl: product.imageUrl,
      quantity: product.quantity,
    });
  };

  const handleCancelEdit = () => {
    setEditingProduct(null);
    editForm.reset();
  };

  const handleImageSelect = async (
    event: React.ChangeEvent<HTMLInputElement>,
    formSetter: (value: string) => void
  ) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: "Arquivo inválido",
        description: "Por favor, selecione uma imagem.",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      try {
        const base64String = reader.result as string;
        
        const response = await apiRequest("POST", "/api/admin/upload-image", {
          imageData: base64String
        });

        formSetter(response.imageUrl);
        toast({
          title: "Imagem carregada!",
          description: "A imagem foi enviada com sucesso.",
        });
      } catch (error) {
        toast({
          title: "Erro ao carregar imagem",
          description: "Não foi possível fazer upload da imagem.",
          variant: "destructive",
        });
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
      <div className="fixed inset-x-0 top-0 bottom-0 bg-background">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <h2 className="text-xl font-bold text-foreground">
              Gerenciar Produtos
            </h2>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                data-testid="button-logout"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                data-testid="button-close-admin"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <ScrollArea className="flex-1 px-4 py-4">
            <div className="space-y-6 pb-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Novo Produto</CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...newProductForm}>
                    <form
                      onSubmit={newProductForm.handleSubmit(handleCreate)}
                      className="space-y-4"
                    >
                      <FormField
                        control={newProductForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome do produto</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Ex: Shampoo Hidratante"
                                {...field}
                                data-testid="input-new-product-name"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={newProductForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Descrição</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Descrição do produto"
                                {...field}
                                data-testid="input-new-product-description"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={newProductForm.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preço (R$)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                step="0.01"
                                placeholder="49.90"
                                {...field}
                                data-testid="input-new-product-price"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={newProductForm.control}
                        name="promotionalPrice"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preço Promocional (R$) - Opcional</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                step="0.01"
                                placeholder="39.90"
                                {...field}
                                value={field.value || ""}
                                data-testid="input-new-product-promotional-price"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={newProductForm.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Categoria</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger data-testid="select-new-product-category">
                                  <SelectValue placeholder="Selecione uma categoria" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {categories.map((cat) => (
                                  <SelectItem key={cat} value={cat}>
                                    {cat}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={newProductForm.control}
                        name="imageUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Imagem do produto</FormLabel>
                            <div className="space-y-2">
                              <div className="flex gap-2">
                                <FormControl>
                                  <Input
                                    placeholder="Cole uma URL ou selecione da galeria"
                                    {...field}
                                    data-testid="input-new-product-image"
                                  />
                                </FormControl>
                                <Button
                                  type="button"
                                  variant="outline"
                                  onClick={() => newProductFileInputRef.current?.click()}
                                  data-testid="button-upload-new-image"
                                >
                                  <Upload className="w-4 h-4 mr-2" />
                                  Galeria
                                </Button>
                              </div>
                              {field.value && (
                                <div className="flex items-center gap-2 p-2 border rounded-md">
                                  <img 
                                    src={field.value} 
                                    alt="Preview" 
                                    className="w-12 h-12 rounded object-cover"
                                  />
                                  <span className="text-xs text-muted-foreground truncate flex-1">
                                    {field.value}
                                  </span>
                                </div>
                              )}
                            </div>
                            <input
                              ref={newProductFileInputRef}
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => handleImageSelect(e, field.onChange)}
                            />
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={newProductForm.control}
                        name="quantity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Quantidade em estoque</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                min="0"
                                placeholder="10"
                                {...field}
                                onChange={(e) => field.onChange(e.target.value)}
                                data-testid="input-new-product-quantity"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button
                        type="submit"
                        className="w-full"
                        disabled={createMutation.isPending}
                        data-testid="button-create-product"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        {createMutation.isPending ? "Criando..." : "Criar Produto"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>

              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-foreground">
                  Produtos ({products.length})
                </h3>
                {isLoading ? (
                  <p className="text-sm text-muted-foreground">Carregando...</p>
                ) : products.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    Nenhum produto cadastrado ainda.
                  </p>
                ) : (
                  products.map((product) => (
                    <Card key={product.id}>
                      <CardContent className="p-4">
                        {editingProduct?.id === product.id ? (
                          <Form {...editForm}>
                            <form
                              onSubmit={editForm.handleSubmit(handleUpdate)}
                              className="space-y-3"
                            >
                              <FormField
                                control={editForm.control}
                                name="name"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Input {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={editForm.control}
                                name="description"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Textarea {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={editForm.control}
                                name="price"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Input
                                        type="number"
                                        step="0.01"
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={editForm.control}
                                name="promotionalPrice"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Input
                                        type="number"
                                        step="0.01"
                                        placeholder="Preço Promocional (Opcional)"
                                        {...field}
                                        value={field.value || ""}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={editForm.control}
                                name="category"
                                render={({ field }) => (
                                  <FormItem>
                                    <Select
                                      onValueChange={field.onChange}
                                      defaultValue={field.value}
                                    >
                                      <FormControl>
                                        <SelectTrigger>
                                          <SelectValue />
                                        </SelectTrigger>
                                      </FormControl>
                                      <SelectContent>
                                        {categories.map((cat) => (
                                          <SelectItem key={cat} value={cat}>
                                            {cat}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={editForm.control}
                                name="imageUrl"
                                render={({ field }) => (
                                  <FormItem>
                                    <div className="space-y-2">
                                      <div className="flex gap-2">
                                        <FormControl>
                                          <Input 
                                            placeholder="Cole uma URL ou selecione da galeria"
                                            {...field} 
                                          />
                                        </FormControl>
                                        <Button
                                          type="button"
                                          variant="outline"
                                          size="sm"
                                          onClick={() => editFileInputRef.current?.click()}
                                        >
                                          <Upload className="w-4 h-4" />
                                        </Button>
                                      </div>
                                      {field.value && (
                                        <div className="flex items-center gap-2 p-2 border rounded-md">
                                          <img 
                                            src={field.value} 
                                            alt="Preview" 
                                            className="w-12 h-12 rounded object-cover"
                                          />
                                          <span className="text-xs text-muted-foreground truncate flex-1">
                                            {field.value}
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                    <input
                                      ref={editFileInputRef}
                                      type="file"
                                      accept="image/*"
                                      className="hidden"
                                      onChange={(e) => handleImageSelect(e, field.onChange)}
                                    />
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={editForm.control}
                                name="quantity"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormControl>
                                      <Input 
                                        type="number" 
                                        min="0"
                                        {...field}
                                        onChange={(e) => field.onChange(e.target.value)}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <div className="flex gap-2">
                                <Button
                                  type="submit"
                                  className="flex-1"
                                  disabled={updateMutation.isPending}
                                >
                                  <Save className="w-4 h-4 mr-2" />
                                  Salvar
                                </Button>
                                <Button
                                  type="button"
                                  variant="outline"
                                  onClick={handleCancelEdit}
                                  className="flex-1"
                                >
                                  Cancelar
                                </Button>
                              </div>
                            </form>
                          </Form>
                        ) : (
                          <div className="flex gap-3">
                            <img
                              src={product.imageUrl}
                              alt={product.name}
                              className="w-16 h-16 rounded-md object-cover"
                            />
                            <div className="flex-1 min-w-0">
                              <h4 className="font-semibold text-sm truncate">
                                {product.name}
                              </h4>
                              <p className="text-xs text-muted-foreground truncate">
                                {product.category} • Estoque: {product.quantity}
                              </p>
                              <p className="text-sm font-semibold text-primary">
                                R$ {Number(product.price).toFixed(2)}
                              </p>
                            </div>
                            <div className="flex flex-col gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEditClick(product)}
                                data-testid={`button-edit-${product.id}`}
                              >
                                Editar
                              </Button>
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => deleteMutation.mutate(product.id)}
                                disabled={deleteMutation.isPending}
                                data-testid={`button-delete-${product.id}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}
