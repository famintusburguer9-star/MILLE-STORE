import { X, Trash2, Plus, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useCart } from "@/contexts/cart-context";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";

interface CartModalProps {
  onClose: () => void;
  onCheckout: () => void;
}

export function CartModal({ onClose, onCheckout }: CartModalProps) {
  const { items, updateQuantity, removeItem, getTotalPrice, getTotalItems } = useCart();
  const { toast } = useToast();

  const { data: products } = useQuery({
    queryKey: ["/api/products"],
  });

  const hasStockIssue = items.some(item => {
    if (!products || !Array.isArray(products)) return false;
    const freshProduct = products.find(p => p.id === item.product.id);
    if (!freshProduct) return true;
    return item.quantity > Number(freshProduct.quantity);
  });

  const formattedTotal = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(getTotalPrice());
  
  const handleCheckoutClick = () => {
    const stockIssue = items.some(item => {
      if (!products || !Array.isArray(products)) return false;
      const freshProduct = products.find((p: any) => p.id === item.product.id);
      if (!freshProduct) return true;
      return item.quantity > Number(freshProduct.quantity);
    });
    
    if (stockIssue) {
      toast({
        title: "Estoque insuficiente",
        description: "Alguns produtos no carrinho excedem o estoque disponível. Ajuste as quantidades antes de continuar.",
        variant: "destructive",
      });
      return;
    }
    onCheckout();
  };

  if (items.length === 0) {
    return (
      <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
        <div className="fixed inset-x-0 top-0 bottom-0 bg-background">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <h2 className="text-xl font-bold text-foreground">
                Carrinho
              </h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                data-testid="button-close-cart"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="flex flex-col items-center justify-center flex-1 px-4">
              <div className="text-center space-y-3">
                <p className="text-lg font-semibold text-foreground">
                  Carrinho vazio
                </p>
                <p className="text-sm text-muted-foreground">
                  Adicione produtos para continuar comprando
                </p>
                <Button onClick={onClose} className="mt-4">
                  Continuar Comprando
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
      <div className="fixed inset-x-0 top-0 bottom-0 bg-background">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <h2 className="text-xl font-bold text-foreground">
              Carrinho ({getTotalItems()} {getTotalItems() === 1 ? 'item' : 'itens'})
            </h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-cart"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          <ScrollArea className="flex-1 px-4 py-4">
            <div className="space-y-3">
              {items.map((item) => {
                const effectivePrice = item.product.promotionalPrice || item.product.price;
                const itemTotal = Number(effectivePrice) * item.quantity;
                const formattedItemTotal = new Intl.NumberFormat("pt-BR", {
                  style: "currency",
                  currency: "BRL",
                }).format(itemTotal);

                return (
                  <Card key={item.product.id}>
                    <CardContent className="p-3">
                      <div className="flex gap-3">
                        <img
                          src={item.product.imageUrl}
                          alt={item.product.name}
                          className="w-20 h-20 rounded-md object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm truncate">
                            {item.product.name}
                          </h4>
                          <p className="text-xs text-muted-foreground">
                            {new Intl.NumberFormat("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            }).format(Number(effectivePrice))} cada
                          </p>
                          <p className="text-sm font-semibold text-primary mt-1">
                            {formattedItemTotal}
                          </p>
                          
                          <div className="flex items-center gap-2 mt-2">
                            <Button
                              size="icon"
                              variant="outline"
                              className="h-7 w-7"
                              onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                              data-testid={`button-decrease-${item.product.id}`}
                            >
                              <Minus className="w-3 h-3" />
                            </Button>
                            <span className="text-sm font-medium w-8 text-center" data-testid={`quantity-${item.product.id}`}>
                              {item.quantity}
                            </span>
                            <Button
                              size="icon"
                              variant="outline"
                              className="h-7 w-7"
                              onClick={() => {
                                const freshProduct = products && Array.isArray(products) 
                                  ? products.find((p: any) => p.id === item.product.id)
                                  : null;
                                const availableStock = freshProduct ? Number(freshProduct.quantity) : Number(item.product.quantity);
                                
                                if (item.quantity >= availableStock) {
                                  toast({
                                    title: "Estoque insuficiente",
                                    description: `Este produto tem apenas ${availableStock} unidades disponíveis.`,
                                    variant: "destructive",
                                  });
                                  return;
                                }
                                updateQuantity(item.product.id, item.quantity + 1);
                              }}
                              disabled={(() => {
                                const freshProduct = products && Array.isArray(products) 
                                  ? products.find((p: any) => p.id === item.product.id)
                                  : null;
                                const availableStock = freshProduct ? Number(freshProduct.quantity) : Number(item.product.quantity);
                                return item.quantity >= availableStock;
                              })()}
                              data-testid={`button-increase-${item.product.id}`}
                            >
                              <Plus className="w-3 h-3" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-7 w-7 ml-auto"
                              onClick={() => removeItem(item.product.id)}
                              data-testid={`button-remove-${item.product.id}`}
                            >
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </ScrollArea>

          <div className="border-t p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-lg font-semibold text-foreground">Total:</span>
              <span className="text-2xl font-bold text-primary" data-testid="cart-total">
                {formattedTotal}
              </span>
            </div>
            <Button
              onClick={handleCheckoutClick}
              className="w-full"
              size="lg"
              disabled={hasStockIssue}
              data-testid="button-checkout"
            >
              Finalizar Compra
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              className="w-full"
            >
              Continuar Comprando
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
