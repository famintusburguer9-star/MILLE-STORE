import { FaCut, FaPalette, FaSprayCan, FaGem, FaHeart } from "react-icons/fa";
import { cn } from "@/lib/utils";
import type { Category } from "@shared/schema";

interface CategoryNavProps {
  activeCategory: Category;
  onCategoryChange: (category: Category) => void;
}

const categoryConfig = [
  { name: "Cabelo" as Category, icon: FaCut, label: "Cabelo" },
  { name: "Maquiagem" as Category, icon: FaPalette, label: "Maquiagem" },
  { name: "Perfumes" as Category, icon: FaSprayCan, label: "Perfumes" },
  { name: "Acessórios" as Category, icon: FaGem, label: "Acessórios" },
  { name: "Sex Shop" as Category, icon: FaHeart, label: "Sex Shop" },
];

export function CategoryNav({ activeCategory, onCategoryChange }: CategoryNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 h-20 bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80 border-t shadow-lg">
      <div className="flex items-center justify-around h-full px-2 safe-area-inset-bottom">
        {categoryConfig.map(({ name, icon: Icon, label }) => {
          const isActive = activeCategory === name;
          return (
            <button
              key={name}
              onClick={() => onCategoryChange(name)}
              className={cn(
                "relative flex flex-col items-center gap-1 px-3 py-2 rounded-lg min-w-[60px] transition-all duration-200",
                "hover-elevate active-elevate-2",
                isActive && "bg-primary/10"
              )}
              data-testid={`button-category-${name.toLowerCase().replace(" ", "-")}`}
            >
              <Icon
                className={cn(
                  "w-5 h-5 transition-colors",
                  isActive ? "text-primary" : "text-muted-foreground"
                )}
              />
              <span
                className={cn(
                  "text-xs font-medium transition-colors",
                  isActive ? "text-primary" : "text-muted-foreground"
                )}
              >
                {label}
              </span>
              {isActive && (
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1/2 h-[3px] bg-primary rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
