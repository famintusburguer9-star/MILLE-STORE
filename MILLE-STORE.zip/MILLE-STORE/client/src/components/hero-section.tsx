import { Button } from "@/components/ui/button";
import { Sparkles, Scissors, Palette, Gem, Heart } from "lucide-react";
import { FaSprayCan } from "react-icons/fa";

interface HeroSectionProps {
  onExplore: () => void;
}

export function HeroSection({ onExplore }: HeroSectionProps) {
  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen px-4 overflow-hidden bg-gradient-to-br from-pink-50 via-purple-50 to-pink-100">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/50" />
      
      <div className="relative z-10 text-center space-y-6 max-w-md">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-primary">Cosméticos & Beleza</span>
        </div>

        <h1 className="text-5xl md:text-6xl font-bold tracking-tight">
          <span className="block bg-gradient-to-r from-primary via-pink-500 to-purple-600 bg-clip-text text-transparent">
            Mille Store
          </span>
        </h1>

        <p className="text-lg text-muted-foreground max-w-sm mx-auto">
          Sua beleza merece o melhor. Descubra produtos incríveis para cabelo, maquiagem, perfumes e muito mais.
        </p>

        <div className="flex flex-col gap-3 pt-4">
          <Button
            onClick={onExplore}
            size="lg"
            className="w-full text-base font-semibold"
            data-testid="button-explore"
          >
            Explorar Produtos
            <Sparkles className="w-5 h-5 ml-2" />
          </Button>
          
          <p className="text-sm text-muted-foreground">
            Mais de 100 produtos para você
          </p>
        </div>

        <div className="grid grid-cols-5 gap-4 pt-8">
          {[
            { icon: Scissors, label: "Cabelo", isReactIcon: false },
            { icon: Palette, label: "Makeup", isReactIcon: false },
            { icon: FaSprayCan, label: "Perfumes", isReactIcon: true },
            { icon: Gem, label: "Acessórios", isReactIcon: false },
            { icon: Heart, label: "Bem-estar", isReactIcon: false }
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className="flex flex-col items-center gap-1">
                <Icon className="w-6 h-6 text-primary" />
                <span className="text-xs text-muted-foreground">{item.label}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-300/20 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>
    </div>
  );
}
