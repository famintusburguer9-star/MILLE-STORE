import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Product } from "@shared/schema";

export interface CartItem {
  product: Product;
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  addItem: (product: Product, quantity?: number) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getTotalItems: () => number;
  getTotalPrice: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  
  const { data: products } = useQuery({
    queryKey: ["/api/products"],
    refetchInterval: 5000,
  });
  
  useEffect(() => {
    if (products && Array.isArray(products)) {
      setItems(current => 
        current.map(item => {
          const freshProduct = products.find((p: Product) => p.id === item.product.id);
          if (freshProduct) {
            const maxStock = Number(freshProduct.quantity);
            return {
              ...item,
              product: freshProduct,
              quantity: Math.min(item.quantity, maxStock),
            };
          }
          return item;
        }).filter(item => Number(item.product.quantity) > 0)
      );
    }
  }, [products]);

  const addItem = (product: Product, quantity: number = 1) => {
    setItems((current) => {
      const maxStock = Number(product.quantity);
      
      if (maxStock <= 0) {
        return current;
      }
      
      const existingIndex = current.findIndex((item) => item.product.id === product.id);
      
      if (existingIndex >= 0) {
        const newItems = [...current];
        const newQuantity = newItems[existingIndex].quantity + quantity;
        newItems[existingIndex].quantity = Math.min(newQuantity, maxStock);
        return newItems;
      }
      
      const clampedQuantity = Math.min(quantity, maxStock);
      return [...current, { product, quantity: clampedQuantity }];
    });
  };

  const removeItem = (productId: string) => {
    setItems((current) => current.filter((item) => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    setItems((current) =>
      current.map((item) => {
        if (item.product.id === productId) {
          const maxStock = Number(item.product.quantity);
          const clampedQuantity = Math.min(Math.max(1, quantity), maxStock);
          return { ...item, quantity: clampedQuantity };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setItems([]);
  };

  const getTotalItems = () => {
    return items.reduce((sum, item) => sum + item.quantity, 0);
  };

  const getTotalPrice = () => {
    return items.reduce((sum, item) => {
      const effectivePrice = item.product.promotionalPrice || item.product.price;
      return sum + Number(effectivePrice) * item.quantity;
    }, 0);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        getTotalItems,
        getTotalPrice,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
