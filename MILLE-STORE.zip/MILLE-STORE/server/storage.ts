import { type Product, type InsertProduct, type Order, type InsertOrder } from "@shared/schema";
import { randomUUID } from "crypto";
import { readFileSync, writeFileSync, existsSync } from "fs";
import { join } from "path";

const PRODUCTS_FILE = join(process.cwd(), "products.json");
const ORDERS_FILE = join(process.cwd(), "orders.json");

const defaultProducts: Product[] = [
  {
    id: randomUUID(),
    name: "Shampoo Nutritivo Rosa Gold",
    description: "Shampoo hidratante com óleo de argan",
    price: "45.90",
    promotionalPrice: null,
    category: "Cabelo",
    imageUrl: "/attached_assets/generated_images/shampoo_bottle_pink_gold.png",
    quantity: "15",
  },
  {
    id: randomUUID(),
    name: "Condicionador Reparador",
    description: "Condicionador profissional para cabelos danificados",
    price: "49.90",
    promotionalPrice: null,
    category: "Cabelo",
    imageUrl: "/attached_assets/generated_images/conditioner_bottle_rose_gold.png",
    quantity: "12",
  },
  {
    id: randomUUID(),
    name: "Paleta de Sombras Rose",
    description: "12 cores nude e rosadas para o dia a dia",
    price: "89.90",
    promotionalPrice: null,
    category: "Maquiagem",
    imageUrl: "/attached_assets/generated_images/pink_eyeshadow_makeup_palette.png",
    quantity: "8",
  },
  {
    id: randomUUID(),
    name: "Batom Matte Luxo",
    description: "Batom de longa duração acabamento matte",
    price: "39.90",
    promotionalPrice: null,
    category: "Maquiagem",
    imageUrl: "/attached_assets/generated_images/pink_lipstick_luxury_cosmetic.png",
    quantity: "20",
  },
  {
    id: randomUUID(),
    name: "Perfume Floral Elegance",
    description: "Fragrância floral sofisticada 50ml",
    price: "159.90",
    promotionalPrice: null,
    category: "Perfumes",
    imageUrl: "/attached_assets/generated_images/pink_perfume_bottle_elegant.png",
    quantity: "5",
  },
  {
    id: randomUUID(),
    name: "Perfume Rose Gold Premium",
    description: "Eau de parfum com notas de rosa e baunilha",
    price: "189.90",
    promotionalPrice: null,
    category: "Perfumes",
    imageUrl: "/attached_assets/generated_images/rose_gold_perfume_luxury.png",
    quantity: "7",
  },
  {
    id: randomUUID(),
    name: "Colar Delicado Dourado",
    description: "Colar folheado a ouro com pingente",
    price: "79.90",
    promotionalPrice: null,
    category: "Acessórios",
    imageUrl: "/attached_assets/generated_images/gold_necklace_elegant_jewelry.png",
    quantity: "10",
  },
  {
    id: randomUUID(),
    name: "Brincos Cristal Rosa",
    description: "Brincos elegantes com cristais rosados",
    price: "69.90",
    promotionalPrice: null,
    category: "Acessórios",
    imageUrl: "/attached_assets/generated_images/pink_crystal_earrings_jewelry.png",
    quantity: "14",
  },
  {
    id: randomUUID(),
    name: "Óleo Massagem Relaxante",
    description: "Óleo aromático para massagens sensuais",
    price: "54.90",
    promotionalPrice: null,
    category: "Sex Shop",
    imageUrl: "/attached_assets/generated_images/pink_massage_oil_bottle.png",
    quantity: "6",
  },
  {
    id: randomUUID(),
    name: "Vela Aromaterapia Romance",
    description: "Vela perfumada para momentos especiais",
    price: "44.90",
    promotionalPrice: null,
    category: "Sex Shop",
    imageUrl: "/attached_assets/generated_images/pink_aromatherapy_candle_luxury.png",
    quantity: "9",
  },
];

export interface IStorage {
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  getAllOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  decreaseProductStock(productId: string, quantity: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private products: Map<string, Product>;
  private orders: Map<string, Order>;

  constructor() {
    this.products = new Map();
    this.orders = new Map();
    this.loadProducts();
    this.loadOrders();
  }

  private loadProducts() {
    if (existsSync(PRODUCTS_FILE)) {
      try {
        const data = readFileSync(PRODUCTS_FILE, "utf-8");
        const products: Product[] = JSON.parse(data);
        products.forEach((product) => {
          this.products.set(product.id, product);
        });
        console.log(`Loaded ${products.length} products from JSON file`);
      } catch (error) {
        console.error("Error loading products from JSON:", error);
        this.initializeDefaultProducts();
      }
    } else {
      this.initializeDefaultProducts();
    }
  }

  private initializeDefaultProducts() {
    defaultProducts.forEach((product) => {
      this.products.set(product.id, product);
    });
    this.saveProducts();
    console.log(`Initialized ${defaultProducts.length} default products`);
  }

  private loadOrders() {
    if (existsSync(ORDERS_FILE)) {
      try {
        const data = readFileSync(ORDERS_FILE, "utf-8");
        const orders: Order[] = JSON.parse(data);
        orders.forEach((order) => {
          this.orders.set(order.id, order);
        });
        console.log(`Loaded ${orders.length} orders from JSON file`);
      } catch (error) {
        console.error("Error loading orders from JSON:", error);
      }
    }
  }

  private saveProducts() {
    try {
      const products = Array.from(this.products.values());
      writeFileSync(PRODUCTS_FILE, JSON.stringify(products, null, 2), "utf-8");
    } catch (error) {
      console.error("Error saving products to JSON:", error);
    }
  }

  private saveOrders() {
    try {
      const orders = Array.from(this.orders.values());
      writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), "utf-8");
    } catch (error) {
      console.error("Error saving orders to JSON:", error);
    }
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { 
      ...insertProduct, 
      id,
      promotionalPrice: insertProduct.promotionalPrice ?? null,
      quantity: insertProduct.quantity ?? "0"
    };
    this.products.set(id, product);
    this.saveProducts();
    return product;
  }

  async updateProduct(
    id: string,
    updateData: Partial<InsertProduct>
  ): Promise<Product | undefined> {
    const existing = this.products.get(id);
    if (!existing) return undefined;

    const updated: Product = { ...existing, ...updateData };
    this.products.set(id, updated);
    this.saveProducts();
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    const deleted = this.products.delete(id);
    if (deleted) {
      this.saveProducts();
    }
    return deleted;
  }

  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const items = JSON.parse(insertOrder.items);
    let recomputedTotal = 0;
    
    const validatedItems = [];
    for (const item of items) {
      const product = this.products.get(item.productId);
      if (!product) {
        throw new Error(`Product ${item.productId} not found`);
      }
      
      const effectivePrice = product.promotionalPrice || product.price;
      const currentPrice = Number(effectivePrice);
      const lineTotal = currentPrice * item.quantity;
      recomputedTotal += lineTotal;
      
      validatedItems.push({
        ...item,
        price: effectivePrice,
      });
      
      const success = await this.decreaseProductStock(item.productId, item.quantity);
      if (!success) {
        throw new Error(`Insufficient stock for product ${item.productId}`);
      }
    }
    
    const id = randomUUID();
    const createdAt = new Date().toISOString();
    const order: Order = { 
      ...insertOrder, 
      id, 
      createdAt,
      items: JSON.stringify(validatedItems),
      totalAmount: recomputedTotal.toString(),
      status: insertOrder.status ?? "pending",
    };
    
    this.orders.set(id, order);
    this.saveOrders();
    return order;
  }

  async decreaseProductStock(productId: string, quantity: number): Promise<boolean> {
    const product = this.products.get(productId);
    if (!product) return false;
    
    const currentStock = Number(product.quantity);
    if (currentStock < quantity) {
      return false;
    }
    
    const newStock = currentStock - quantity;
    
    const updated: Product = { ...product, quantity: newStock.toString() };
    this.products.set(productId, updated);
    this.saveProducts();
    return true;
  }
}

export const storage = new MemStorage();
